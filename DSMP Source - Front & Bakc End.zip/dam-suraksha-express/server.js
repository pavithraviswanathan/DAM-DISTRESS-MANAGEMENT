// MARK: Imports
const express = require('express')
const bodyParser= require('body-parser')
const MongoClient = require('mongodb').MongoClient

// MARK: Variable declaration
const MONGO_URL = 'mongodb://localhost:27017'
const DB_NAME = 'dam-suraksha-db'
const app = express()

// SRC: https://scotch.io/tutorials/use-expressjs-to-get-url-and-post-parameters
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true, parameterLimit:50000}));

// MARK: Route Declaration
const userRoute = require('./routes/User');
const complaintRoute = require('./routes/Complaint');
const mailRoute = require('./routes/Mail');
const auditRoute = require('./routes/Audit');
const alertRoute = require('./routes/Alert');
const imageRoute = require('./routes/Image');

// MARK: Route Definition
app.get('/', (req, res) => res.send('Hello World!'))
app.use('/user', userRoute)
app.use('/complaint', complaintRoute)
app.use('/mail', mailRoute)
app.use('/audit', auditRoute)
app.use('/alert', alertRoute)
app.use('/image', imageRoute)

MongoClient.connect(MONGO_URL, (err, client) => {
  if (err) return console.log(err)
  db = client.db(DB_NAME) // whatever your database name is
  app.listen(3000, () => {
    console.log('listening on 3000')
  })
})
// app.listen(3000, () => console.log('Example app listening on port 3000!'))