// Imports
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');

// Variable Declaration
var transporter = nodemailer.createTransport(smtpTransport({
  service: 'gmail',
  host: 'smtp.gmail.com',
  port: 465,
  secure: true,
  auth: {
    user: 'vrnarencse@gmail.com',
    pass: '****'
  }
}));

// var transporter = nodemailer.createTransport(smtpTransport({
//   service: 'gmail',
//   auth: {
//       user: 'vrnarencse@gmail.com',
//       pass: '****'
//   }
// }));

var mailOptions = {
  from: 'vrnarencse@gmail.com',
  to: 'snatchnaren@gmail.com',
  subject: 'Sending Email using Node.js[nodemailer]',
  text: 'That was easy!'
};

// export const sendMailPromise = (mailOptions) => new Promise((resolve, reject)=>{
//   transporter.sendMail(mailOptions, function(err, info){
//     if (err) {
//       console.log(err);
//       reject(err)
//       // console.log(err);
//     } else {
//       console.log(info);
//       //console.log('Email sent: ' + info.response);
//       resolve(info)
//     }
//   });
// });

exports.sendMail = (mailOptions, req, res, status) => 
  transporter.sendMail(mailOptions, function(err, info){
    if (err) {
      console.log(err);
      res.status(500).send(err)
      // reject(err)
      // console.log(err);
    } else {
      console.log(info);
      //console.log('Email sent: ' + info.response);
      // resolve(info)
      res.send({status})
    }
  });