var express = require('express')
var router = express.Router()
var ObjectID = require('mongodb').ObjectID; 
var sendMail = require('../utils/Mail').sendMail;
const asyncMiddleware = require('../utils/asyncMiddleware').asyncMiddleware;

const COLLECTION_NAME = 'DamUser'

// middleware that is specific to this router
router.use(function timeLog (req, res, next) {
  console.log('Request URL:', req.originalUrl, 'USER Time: ', Date.now())
  next()
})

// define the home page route
// Send all users
router.get('/', function (req, res) {
  db.collection(COLLECTION_NAME).find().toArray(function(err, results) {
    if(err || !results || !results.length) {
      console.log(err)
      res.status(406).send(err || 'NO USERS FOUND in DB')
      return;
    }
    console.log(results)
    let users = []
    for(let i = 0; i < results.length; ++i) {
      let user = results[0]
      //Deleting unwanted fields
      delete user.confirmPassword;
      delete user.password;
      users.push(user)
    }
    // res.json(results);
    res.send(users)
    // send HTML file populated with quotes here
  })
})

// Authenticate
router.post('/', function (req, res) {
  db.collection(COLLECTION_NAME).find(req.body).toArray(function(err, results) {
    console.log(results)
    console.log('size' + results.length)
    if(err || !results || !results.length) {
      console.log(err)
      res.status(406).send(err || 'DATA NOT FOUND in DB')
      return;
    }
    console.log(results)
    let user = results[0]
    //Deleting unwanted fields
    delete user.confirmPassword;
    delete user.password;
    if(user.activated) {
      res.send(results[0]);
    } else {
      res.send({activated: false})
    }
  })
})

// Activate
router.get('/activate/:userId', function (req, res) {
  db.collection(COLLECTION_NAME).update({_id: ObjectID(req.params.userId)}, 
    {$set: {activated: true}}, 
    function(err, results) {
      // console.log('size' + results.lenght)
      if(err) {
        console.log(err)
        res.status(406).send(err || 'DATA NOT FOUND in DB')
        return;
      }
      res.send({status: 'ACTIVATED'});
      // res.send('AUTHENTICATED')
      // send HTML file populated with quotes here
  })
})

// Send only the corresponding user who holding ID
router.get('/user/:id', function (req, res) {
  res.send('USER')
});

router.get('/pwdusers', function(req, res) {
  console.log('pwdUSers')
  db.collection(COLLECTION_NAME).find({userType: 'PWD'}).toArray(function(err, results) {
    console.log(results)
    console.log('size' + results.length)
    if(err || !results || !results.length) {
      console.log(err)
      res.status(406).send(err || 'DATA NOT FOUND in DB')
      return;
    }
    console.log(results)
    let users = []
    for(let i = 0; i < results.length; ++i) {
      let user = results[i]
      //Deleting unwanted fields
      delete user.confirmPassword;
      delete user.password;
      users.push(user)
    }
    //SEnding user list
    res.send(users);
  })
});

// Register an user
router.post('/register', asyncMiddleware(async function (req, res, next) {
  console.log('REGISTER')
  console.log(req.body)
  
  // Access mongo db
  await db.collection(COLLECTION_NAME).save(req.body, async(err, result) => {
    if (err) return console.log(err)

    // console.log(result.ops[0]._id)
    console.log('saved to database')
    const emailId = req.body.emailId
    await sendMail({
      from: 'snatchnaren@gmail.com',
      to: emailId,
      subject: 'Account activation',
      text: `Select the following link to activate your account\n\nhttp://localhost:8010/activate/${result.ops[0]._id}`
    }, req, res, 'ACCOUNT_REGISTERED')

    // res.send('REGISTERED')
  })
}));

module.exports = router