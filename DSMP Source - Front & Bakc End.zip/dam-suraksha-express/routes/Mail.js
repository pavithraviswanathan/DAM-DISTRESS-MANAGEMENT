// Imports
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var express = require('express')
var sendMail = require('../utils/Mail').sendMail;

// Variable Declaration
var router = express.Router()
const COLLECTION_NAME = 'Notification'

// var transporter = nodemailer.createTransport(smtpTransport({
//   service: 'gmail',
//   host: 'smtp.gmail.com',
//   port: 465,
//   secure: true,
//   auth: {
//     user: 'vrnarencse@gmail.com',
//     pass: '****'
//   }
// }));

// // var transporter = nodemailer.createTransport(smtpTransport({
// //   service: 'gmail',
// //   auth: {
// //       user: 'vrnarencse@gmail.com',
// //       pass: '****'
// //   }
// // }));

// var mailOptions = {
//   from: 'vrnarencse@gmail.com',
//   to: 'snatchnaren@gmail.com',
//   subject: 'Sending Email using Node.js[nodemailer]',
//   text: 'That was easy!'
// };

// const sendMailPromise = (mailOptions) => new Promise((resolve, reject)=>{
//   transporter.sendMail(mailOptions, function(err, info){
//     if (err) {
//       console.log(err);
//       reject(err)
//       // console.log(err);
//     } else {
//       console.log(info);
//       //console.log('Email sent: ' + info.response);
//       resolve(info)
//     }
//   });
// });

// middleware that is specific to this router
router.use(function timeLog (req, res, next) {
  console.log('Request URL:', req.originalUrl, 'Mail Time: ', Date.now())
  next()
})

// Send only the corresponding user who holding ID
router.post('/', async function (req, res, next) {
  try {
    console.log(`id: ${JSON.stringify(mailOptions)}`)
    //sendMailPromise(mailOptions).then(info=>{res.send(info)}).catch(err=>{res.status(500).send(err)})
    await sendMail(mailOptions, req, res)
    // await transporter.sendMail(mailOptions, function(err, info){
    //   if (err) {
    //     console.log(err);
    //     res.status(500).send(err)
    //     // reject(err)
    //     // console.log(err);
    //   } else {
    //     console.log(info);
    //     //console.log('Email sent: ' + info.response);
    //     // resolve(info)
    //     res.send(info)
    //   }
    // });
  } catch (e) {
    //this will eventually be handled by your error handling middleware
    next(e) 
  }
})

module.exports = router