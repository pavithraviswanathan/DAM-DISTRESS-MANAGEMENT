var sendMail = require('../utils/Mail').sendMail;
var express = require('express')
var router = express.Router()

const COLLECTION_NAME = 'Alert'

// middleware that is specific to this router
router.use(function timeLog (req, res, next) {
  console.log('Request URL:', req.originalUrl, 'Alert Time: ', Date.now())
  next()
})


// Create a new complaint
router.post('/add', function (req, res) {
  console.log('REGISTER a Audit')
  
  const audit = req.body
  console.log(audit)
  // Access mongo db
  db.collection(COLLECTION_NAME).save(req.body, (err, result) => {
    if (err) return console.log(err)
    // console.log(result)
    console.log('saved to database')
    // db.collection('DamUser').find({state: complaint.state, district: complaint.district}).toArray(async function(err, results) {
    //   console.log('size' + results.length)
    //   if(err || !results || !results.length || results.length == 0) {
    //     console.log(err)
    //     res.status(406).send(err || 'DATA NOT FOUND in DB')
    //     return;
    //   }
    //   // console.log(results)
    //   const emailId = results[0].emailId
    //   await sendMail({
    //     from: 'vrnarencse@gmail.com',
    //     to: emailId,
    //     subject: 'Complaint Alert',
    //     text: `${JSON.stringify(complaint)}`
    //   }, req, res, 'COMPLAINT_NOTIFICATION_PASSED')
    // });
    
    res.send(result.ops[0])
  })
})

router.post('/send', function (req, res) {
  console.log('alert a Audit')
  
  const audit = req.body
  console.log(audit)
  // Access mongo db
  db.collection(COLLECTION_NAME).find(req.body.dam).toArray(async(err, results) => {
    if (err) return console.log(err)
    // console.log(result)
    console.log('alert in to database')
    console.log('size' + results.length)
    if(err || !results || !results.length) {
      console.log(err)
      res.status(406).send(err || 'DATA NOT FOUND in DB')
      return;
    }
    console.log(results)
    for(let i = 0; i < results.length; ++i) {
      const emailId = results[i].user.emailId

      await sendMail({
        from: 'vrnarencse@gmail.com',
        to: emailId || 'snatchnaren@gmail.com',
        subject: 'Complaint Alert',
        text: `${req.body.alertContent}`
      }, req, res, 'ALERT_NOTIFICATION_PASSED')
    }
    // db.collection('DamUser').find({state: complaint.state, district: complaint.district}).toArray(async function(err, results) {
    //   console.log('size' + results.length)
    //   if(err || !results || !results.length || results.length == 0) {
    //     console.log(err)
    //     res.status(406).send(err || 'DATA NOT FOUND in DB')
    //     return;
    //   }
    //   // console.log(results)
      
    // });
    
    // res.send(result.ops[0])
  })
})

module.exports = router