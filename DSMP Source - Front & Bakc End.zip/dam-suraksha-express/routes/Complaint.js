var sendMail = require('../utils/Mail').sendMail;
var express = require('express')
var router = express.Router()

const COLLECTION_NAME = 'DamComplaint'

// middleware that is specific to this router
router.use(function timeLog (req, res, next) {
  console.log('Request URL:', req.originalUrl, 'COMPLAINT Time: ', Date.now())
  next()
})
// define the home page route
// Send all users
router.get('/', function (req, res) {
  res.send('COMPLAINTs')
})

// Send only the corresponding user who holding ID
router.get('/complaint/:id', function (req, res) {
  res.send('COMPLAINT')
})

// Collect particular complaint
router.post('/collect', function (req, res) {
  console.log('/collect')
  db.collection(COLLECTION_NAME).find(req.body).toArray(function(err, results) {
    console.log('size' + results.length)
    if(err || !results || !results.length) {
      console.log(err)
      res.status(406).send(err || 'DATA NOT FOUND in DB')
      return;
    }
    console.log(results)
    
    res.send(results);
    // res.send('AUTHENTICATED')
    // send HTML file populated with quotes here
  })
})

// Create a new complaint
router.post('/register', function (req, res) {
  console.log('REGISTER a complaint')
  
  const complaint = req.body
  console.log(complaint)
  // Access mongo db
  db.collection(COLLECTION_NAME).save(req.body, (err, result) => {
    if (err) return console.log(err)
    // console.log(result)
    console.log('saved to database')
    db.collection('DamUser').find({state: complaint.state, district: complaint.district}).toArray(async function(err, results) {
      console.log('size' + results.length)
      if(err || !results || !results.length || results.length == 0) {
        console.log(err)
        res.status(406).send(err || 'DATA NOT FOUND in DB')
        return;
      }
      // console.log(results)
      const emailId = results[0].emailId
      await sendMail({
        from: 'vrnarencse@gmail.com',
        to: emailId,
        subject: 'Complaint Alert',
        text: `${JSON.stringify(complaint)}`
      }, req, res, 'COMPLAINT_NOTIFICATION_PASSED')
    });
    
    // res.send('SAVED to DB')
  })
})

router.post('/updatecomplaint', function (req, res) {
  console.log('Update a complaint')
  
  const complaint = req.body
  console.log(complaint)
  // Access mongo db
  db.collection(COLLECTION_NAME).update({_id: req.body._id}, req.body, async(err, result) => {
    if (err) return console.log(err)
    // console.log(result)
    console.log('updated to database')
    // db.collection('DamUser').find({state: complaint.state, district: complaint.district}).toArray(async function(err, results) {
    //   console.log('size' + results.length)
    //   if(err || !results || !results.length || results.length == 0) {
    //     console.log(err)
    //     res.status(406).send(err || 'DATA NOT FOUND in DB')
    //     return;
    //   }
      // console.log(results)
      const emailId = req.body.addedBy.emailId
      await sendMail({
        from: 'vrnarencse@gmail.com',
        to: emailId,
        subject: 'Complaint Alert',
        text: `${JSON.stringify(complaint)}`
      }, req, res, 'COMPLAINT_NOTIFICATION_PASSED')
    // });
    
    // res.send('SAVED to DB')
  })
})

module.exports = router