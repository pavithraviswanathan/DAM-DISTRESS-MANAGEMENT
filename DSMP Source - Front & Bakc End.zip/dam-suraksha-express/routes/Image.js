var multer = require('multer');
var mongoose = require('mongoose');
var express = require('express')
var sendMail = require('../utils/Mail').sendMail;

// const imageFilter = function (req, file, cb) {
//   // accept image only
//   if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
//       return cb(new Error('Only image files are allowed!'), false);
//   }
//   cb(null, true);
// };


var upload = multer({ dest: 'uploads/'})
// var upload = multer({ dest: 'uploads/', fileFilter: imageFilter })
// var type = upload.single('file');
var type = upload.single('file');

// Variable Declaration
var router = express.Router()
const COLLECTION_NAME = 'SavedImage'

// middleware that is specific to this router
router.use(function timeLog (req, res, next) {
  console.log('Request URL:', req.originalUrl, 'IMAGE Time: ', Date.now())
  next()
})

router.post('/', type, (req, res, next) => {
    console.log(req.file)
    console.log(typeof req.file)
    // db.collection(COLLECTION_NAME).save({file: req.file, 'name': 'test'}, (err, results) => {
    //   console.log('size' + results.length)
    //   if(err || !results || !results.length) {
    //     console.log(err)
    //     res.status(406).send(err || 'DATA NOT FOUND in DB')
    //     return;
    //   }
    //   console.log(results)
      
    //   // res.send(results[0]);
    //   res.send('UPLOADED')
    //   // send HTML file populated with quotes here
    // })
});
// Send only the corresponding user who holding ID
// router.post('/', async function (req, res, next) {
//   try {
//     console.log(`id: ${JSON.stringify(mailOptions)}`)
//     //sendMailPromise(mailOptions).then(info=>{res.send(info)}).catch(err=>{res.status(500).send(err)})
//     await sendMail(mailOptions, req, res)
//     // await transporter.sendMail(mailOptions, function(err, info){
//     //   if (err) {
//     //     console.log(err);
//     //     res.status(500).send(err)
//     //     // reject(err)
//     //     // console.log(err);
//     //   } else {
//     //     console.log(info);
//     //     //console.log('Email sent: ' + info.response);
//     //     // resolve(info)
//     //     res.send(info)
//     //   }
//     // });
//   } catch (e) {
//     //this will eventually be handled by your error handling middleware
//     next(e) 
//   }
// })

module.exports = router