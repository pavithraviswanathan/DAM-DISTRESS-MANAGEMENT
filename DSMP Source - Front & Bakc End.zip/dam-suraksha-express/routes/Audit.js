var sendMail = require('../utils/Mail').sendMail;
var express = require('express')
var ObjectID = require('mongodb').ObjectID; 
var router = express.Router()

const COLLECTION_NAME = 'Audit'

// middleware that is specific to this router
router.use(function timeLog (req, res, next) {
  console.log('Request URL:', req.originalUrl, 'Audit Time: ', Date.now())
  next()
})

// Collect particular audit
router.post('/', function (req, res) {
  // req.body will be a user object
  console.log(req.body)
  db.collection(COLLECTION_NAME).find({user: req.body}).toArray(function(err, results) {
    console.log('size' + results.length)
    if(err || !results || !results.length) {
      console.log(err)
      res.status(406).send(err || 'DATA NOT FOUND in DB')
      return;
    }
    console.log(results)
    
    res.send(results);
    // res.send('AUTHENTICATED')
    // send HTML file populated with quotes here
  })
})

router.post('/complaint/:id', function (req, res) {
  // req.body will be a user object
  // console.log(req.body)
  const audit = req.body
  db.collection(COLLECTION_NAME).find({complaintId: audit.complaintId}).toArray(function(err, results) {
    console.log('size' + results.length)
    if(err || !results || !results.length) {
      console.log(err)
      res.status(406).send(err || 'DATA NOT FOUND in DB')
      return;
    }
    console.log(results)
    
    res.send(results[0]);
    // res.send('AUTHENTICATED')
    // send HTML file populated with quotes here
  })
})

// Create a new complaint
router.post('/register', function (req, res) {
  console.log('REGISTER a Audit')
  
  const audit = req.body
  // console.log(audit)
  // Access mongo db
  db.collection(COLLECTION_NAME).save(req.body, (err, result) => {
    if (err) return console.log(err)
    // console.log(result)
    console.log('saved to database')
    db.collection('DamComplaint').update({_id: ObjectID(audit.complaintId)},
      {$set: {
        status: 'AUDITED',
        auditedBy: audit.user.user
      }}, 
      function(err, results) {
        if(err) {
          console.log(err)
          res.status(406).send(err || 'DATA NOT FOUND in DB')
          return;
        }
        res.send({status: 'AUDITED'});
      }
    )
    // db.collection('DamUser').find({state: complaint.state, district: complaint.district}).toArray(async function(err, results) {
    //   console.log('size' + results.length)
    //   if(err || !results || !results.length || results.length == 0) {
    //     console.log(err)
    //     res.status(406).send(err || 'DATA NOT FOUND in DB')
    //     return;
    //   }
    //   // console.log(results)
    //   const emailId = results[0].emailId
    //   await sendMail({
    //     from: 'vrnarencse@gmail.com',
    //     to: emailId,
    //     subject: 'Complaint Alert',
    //     text: `${JSON.stringify(complaint)}`
    //   }, req, res, 'COMPLAINT_NOTIFICATION_PASSED')
    // });
    
    // res.send(result.ops[0])
  })
})

module.exports = router