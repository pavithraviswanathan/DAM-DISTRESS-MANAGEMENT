import { createStore, applyMiddleware, compose } from 'redux';
import ReduxThunk from 'redux-thunk'
import logger from 'redux-logger';

import Reducers from 'Reducer';

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

let store = createStore(
	Reducers, 
	composeEnhancers(applyMiddleware(ReduxThunk, logger))
)

export default store;