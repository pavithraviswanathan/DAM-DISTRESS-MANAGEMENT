import { axiosInstance } from 'Config/Server';

const SAMPLE_MAIL = {
  from: 'vrnarencse@gmail.com', // Remains constant
  to: 'snatchnaren@gmail.com', // Just udate to mail address
  subject: 'Sending Email using Node.js[nodemailer]', // Subject which needs to be included in mail
  text: 'That was easy!' // main content in the body
}
export const sendMail = mailObj => {
  console.log(mailObj)
	return dispatch => axiosInstance.post(`mail`, mailObj).then(function(response) {
    debugger
    return dispatch({
      type: 'SEND_MAIL_SUCCESS',
      mail: response.data
    })
	}).catch(function (error) {
    debugger
    console.log(error.config);
    return dispatch({
      type: 'SEND_MAIL_FAILURE',
    })
  });
}