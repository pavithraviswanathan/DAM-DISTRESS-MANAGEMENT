import { axiosInstance } from 'Config/Server';

export const saveUser = user => {
  console.log(user)
	return dispatch => axiosInstance.post('user/register', user).then(function(response) {
    return dispatch({
      type: 'ADD_USER_SUCCESS',
      user
    })
	}).catch(function (error) {
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      console.log(error.response.data);
      console.log(error.response.status);
      console.log(error.response.headers);
    } else if (error.request) {
      // The request was made but no response was received
      // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
      // http.ClientRequest in node.js
      console.log(error.request);
    } else {
      // Something happened in setting up the request that triggered an Error
      console.log('Error', error.message);
    }
    console.log(error.config);
    return dispatch({
      type: 'ADD_USER_FAILED',
    })
  });
}

export const authenticateUser = user => {
  return dispatch => axiosInstance.post('user', user).then(function(response) {
    return dispatch({
      type: 'USER_AUTHENTICATION_SUCCESS',
      user: response.data
    })
  }).catch((err)=>{
    return dispatch({
      type: 'USER_AUTHENTICATION_FAILED'
    })
  })
}

export const activateUser = emailId => {
  return dispatch => axiosInstance.get(`user/activate/${emailId}`).then(function(response) {
    return dispatch({
      type: 'USER_ACTIVATION_SUCCESS',
      user: response.data
    })
  }).catch((err)=>{
    return dispatch({
      type: 'USER_ACTIVATION_FAILED'
    })
  })
}

export const collectPwdUsers = () => {
  return dispatch => axiosInstance.get(`user/pwdusers`).then(function(response) {
    return dispatch({
      type: 'PWD_USER_COLLECTION_SUCCESS',
      pwdUsers: response.data
    })
  }).catch((err)=>{
    return dispatch({
      type: 'PWD_USER_COLLECTION_FAILED'
    })
  })
}


export const addAlert = (alert) => {
  return dispatch => axiosInstance.post(`alert/add`, alert).then(function(response) {
    return dispatch({
      type: 'ADD_ALERT_SUCCESS',
      pwdUsers: response.data
    })
  }).catch((err)=>{
    return dispatch({
      type: 'ADD_ALERT_FAILED'
    })
  })
}

export const sendAlert = (alert) => {
  return dispatch => axiosInstance.post(`alert/send`, alert).then(function(response) {
    return dispatch({
      type: 'SEND_ALERT_SUCCESS',
      alert: response.data
    })
  }).catch((err)=>{
    return dispatch({
      type: 'SEND_ALERT_FAILED'
    })
  })
}