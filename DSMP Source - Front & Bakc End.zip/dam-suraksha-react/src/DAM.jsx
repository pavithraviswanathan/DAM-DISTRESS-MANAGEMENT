import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Provider } from 'react-redux';
import { HashRouter, BrowserRouter, Route, Switch } from 'react-router-dom';

// Reducers
import Store from './Store';

// Layout
import Welcome from './layout/welcome/Welcome';
import Home from './layout/home/Home';
import Complaint from './layout/complaint/Complaint';
import Map from './layout/map/Map';
import About from './layout/about/About';
import Contact from './layout/contact/Contact';
import Audit from './layout/audit/Audit';
import Activate from './layout/activate/Activate';
import People from './layout/people/People';
import Alert from './layout/alert/Alert';
import Error404 from './layout/error404/Error404';

import './DAM.css';

class DAM extends Component {

  render() {
    /* REDUX */
    return (
      <Provider store={Store}>
				{/* ROUTER */}
				<BrowserRouter >
					<Switch>
						<Route exact path="/" component={Welcome} />
						<Route path="/home" component={Home} />
						<Route path="/complaint" component={Complaint} />
						<Route path="/audit" component={Audit} />
						<Route path="/map" component={Map} />
						<Route path="/people" component={People} />
						<Route path="/about" component={About} />
						<Route path="/alert" component={Alert} />
						<Route path="/contact" component={Contact} />
						<Route path="/activate/:emailId" component={Activate} />
						<Route component={Error404} />
					</Switch>
				</BrowserRouter>
			</Provider>
    )
  }
}

export default DAM;