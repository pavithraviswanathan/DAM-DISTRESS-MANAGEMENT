import React from "react";
import { compose, withProps } from "recompose";
import {
  withScriptjs,
  withGoogleMap,
  GoogleMap,
  Marker
} from "react-google-maps";

const GOOGLE_API_KEY = 'AIzaSyDWz8Hyej-P5YslfmjCKIR21w_sDkpKCSM'
const NEW_DELHI_GEO = {
  lat: 28.6926341,lng: 76.9512632
}
// { lat: -34.397, lng: 150.644 }
const MyMapComponent = compose(
  withProps({
    /**
     * Note: create and replace your own key in the Google console.
     * https://console.developers.google.com/apis/dashboard
     */
    googleMapURL:
      `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_API_KEY}&v=3.exp&libraries=geometry,drawing,places`,
    loadingElement: <div style={{ height: `100%` }} />,
    containerElement: <div style={{ height: 600, width: 600, border: '1px solid black', padding: 10 }} />,
    mapElement: <div style={{ height: `100%` }} />
  }),
  withScriptjs,
  withGoogleMap
)(props => (
  <GoogleMap defaultZoom={4} defaultCenter={NEW_DELHI_GEO}>
    {props.isMarkerShown && (
      <Marker position={NEW_DELHI_GEO} onClick={()=>props.onMarkerClick()}/>
    )}
  </GoogleMap>
));

 export default MyMapComponent;
