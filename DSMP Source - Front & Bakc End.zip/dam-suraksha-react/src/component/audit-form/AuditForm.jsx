import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import Switch from 'material-ui/Switch';
import Select from 'material-ui/Select';
import Dropzone from 'react-dropzone';
import Checkbox from 'material-ui/Checkbox';
import Button from 'material-ui/Button';
import Input, { InputLabel } from 'material-ui/Input';
import { MenuItem } from 'material-ui/Menu';
import { FormControl, FormHelperText, 
  FormGroup, FormControlLabel } from 'material-ui/Form';

var Dropbox = require('dropbox').Dropbox;
// const axios = require('axios');
const ACCESS_TOKEN = '****'
var dbx = new Dropbox({ accessToken: ACCESS_TOKEN });

import { convertToString } from 'Util/DateUtil';

import './AuditForm.css';

const ECONOMIC_DEVELOPMENT_EXTENDs = [
  {name: "Irrigation", value: "Irrigation"},
  {name: "Water Supply", value: "WATER_SUPPLY"},
  {name: "Aquaculture", value: "AQUA_CULTURE"},
  {name: "Recreation", value: "RECREATION"},
  {name: "Hydro power", value: "HYDRO_POWER"},
  {name: "Navigation", value: "NAVIGATION"},
  {name: "OTHERS", value: "OTHERS"},
]

const DAM_TYPEs = [
  {name: "Earthen Dam", value: "EARTHEN"},
  {name: "Composite Dam", value: "COMPOSITE"},
  {name: "Masonry Dam", value: "MASONRY"}
]

const SPILLWAY_TYPEs = [
  {name: "Straight Drop Spillway", value: "STRAIGHT_DROP"},
  {name: "Overflow Spillway", value: "OVERFLOW"},
  {name: "Chute/Trough Spillway", value: "CHUTE_TROUGH"},
  {name: "Side Channel Spillway", value: "SIDE_CHANNEL"},
  {name: "Shaft Spillway", value: "SHAFT"},
  {name: "Syphon Spillway", value: "SYPHON"}
]

class AuditForm extends Component {
  constructor(props) {
    super(props)

    this.state = {
      audit: {
        dropbox: null,
        monitoredBy: '',
        waterLevel: '',
        frlCapacity: '',
        mwlCapacity: '',
        nearDownstreamCity: '',
        cityDistance: '',
        economicDevelopmentExtend: '',
        damType: '',
        masonary: false,
        earthenDam: false,
        planElevation: false,
        crestElevation: '',
        crestLength: '',
        reservoirArea: '',
        freeBoardAllowance: false,
        existingFloodRouteRecord: false,
        lastYearFlow: '',
        emergencyDropDown: false,
        spillywayNumber: '',
        spillywayType: '',
        flood: false,
        piezometer: false, inclinometer: false, settlementPlate: false, pressureCell: false, 
        gaugeDrain: false, seismograph: false, plumbpob: false,
        rockType: '',
        foundationProfile: '',
        damLength: '', damBreadth: '', damRightMoment: '', damOvertuneMoment: '', 
        fs: '', safety: '',
        STABILITY_1: false, STABILITY_2: false, STABILITY_3: false, STABILITY_4: false, 
        STABILITY_5: false, STABILITY_6: false, STABILITY_7: false,
        lowGravityDam: false, largeDam: false,
        allowableCompressiveStress: '', eccentricity: '', verticalLoad: '', breadth: '', 
        p: '', pSafety: '', maxP: '', maxPSafety: '', minP: '', minPSafety: '',
        criticalGradient: '', designGradient: '', blanketAtDownstreatToe: '',
        topImperriousBlanket: '', measuredAboveTailWater: '', seepageFs: '', 
        seepageSafety: '',
        earthenDamStability: false,
        auditedDate: convertToString(new Date())
      }
    }
  }

  componentWillMount() {
    const { audit, viewType } = this.props
    if(viewType == 'VIEW') {
      this.setState({audit})
    }
  }

  handleAuditSubmit = () => {
    this.props.handleAuditSubmit(this.state.audit)
  }

  handleAuditCancel = () => {
    this.props.handleAuditCancel()
  }

  handleChange = (name, type) => event => {
    const { audit } = this.state
    audit[name] = type == 'checked' ? event.target.checked : event.target.value
    this.setState({ audit });
  };

  renderInstrumentationReport(userType) {
    const { audit } = this.state
    const { viewType } = this.props
    return (
      <div className="auditorInstrumentGroup">
        <h2>INSTRUMENTATION REPORT</h2>
        <div className="auditorInstruments">
          <FormControl>
          <FormControlLabel
            control={
              <Switch
                checked={audit['piezometer']}
                onChange={this.handleChange('piezometer', 'checked')}
                value="piezometer"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Piezometer"
          /> 
          </FormControl>
          <FormControlLabel
            control={
              <Switch
                checked={audit['inclinometer']}
                onChange={this.handleChange('inclinometer', 'checked')}
                value="inclinometer"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Inclinometer"
          /> 
          <FormControlLabel
            control={
              <Switch
                checked={audit['settlementPlate']}
                onChange={this.handleChange('settlementPlate', 'checked')}
                value="settlementPlate"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Settlement Plate"
          /> 
          <FormControlLabel
            control={
              <Switch
                checked={audit['pressureCell']}
                onChange={this.handleChange('pressureCell', 'checked')}
                value="pressureCell"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Pressure Cell"
          /> 
          <FormControlLabel
            control={
              <Switch
                checked={audit['gaugeDrain']}
                onChange={this.handleChange('gaugeDrain', 'checked')}
                value="gaugeDrain"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Gauge Drain"
          /> 
          {
            (userType == 'AUDITOR_1' || userType == 'AUDITOR_2') && <FormControlLabel
              control={
                <Switch
                  checked={audit['seismograph']}
                  onChange={this.handleChange('seismograph', 'checked')}
                  value="seismograph"
                  color="primary"
                  disabled={viewType == 'VIEW' ? true : false}
                />
              }
              label="Seismograph"
            /> 
          }
          {
            (userType == 'AUDITOR_1' || userType == 'AUDITOR_2') && <FormControlLabel
              control={
                <Switch
                  checked={audit['plumbpob']}
                  onChange={this.handleChange('plumbpob', 'checked')}
                  value="plumbpob"
                  color="primary"
                  disabled={viewType == 'VIEW' ? true : false}
                />
              }
              label="Plumbpob"
            /> 
          }
        </div>
      </div>
    )
  }

  handleFileChange = (acceptedFiles) =>
  {
      // console.log(acceptedFiles);
      const file = acceptedFiles[0]
      // var formData = new FormData();
      //           console.log( acceptedFiles[0])
      //           formData.append('name', acceptedFiles[0])
      // axios.post('http://localhost:3000/image', formData, {
      //             headers: {
      //               'accept': 'application/json',
      //               'Accept-Language': 'en-US,en;q=0.8',
      //               // 'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
      //               'Content-Type': formData.type
      //             }
      //             //formData.getHeaders(),
      //           }).then(result => {
      //             console.log(result.data);
      //           }).catch((err)=>{
      //             console.log('axios push')
      //             console.log(err)
      //           });

                dbx.filesUpload({path: '/' + file.name, contents: file})
        .then(function(response) {
          // var results = document.getElementById('results');
          // results.appendChild(document.createTextNode('File uploaded!'));
          console.log(response);
          console.log('file saved')
          this.setState({dropbox: response})
        })
        .catch(function(error) {
          console.error(error);
        });
  }

  renderAudit3Elements() {
    const { audit } = this.state
    const { viewType } = this.props
    return (
      <div className='audit3Container'>
        <h2>STABILITY AGAINST OVERTURNING</h2>
        <TextField
          id="damLengthId"
          label="Dam Length"
          value={audit['damLength']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('damLength')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="damBreadthhId"
          label="Dam Breadth"
          value={audit['damBreadth']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('damBreadth')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="damRightMomentId"
          label="Righting Moment of Dam"
          value={audit['damRightMoment']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('damRightMoment')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="damOvertuneMomentId"
          label="Overtuning Moment of Dam"
          value={audit['damOvertuneMoment']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('damOvertuneMoment')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="fsId"
          label="FS"
          value={audit['fs']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('fs')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="safetyId"
          label="Safety"
          value={audit['safety']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('safety')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <h2>STABILITY AGAINST SLIDING</h2>
        <FormControlLabel
          control={
            <Checkbox
              checked={audit['STABILITY_1']}
              onChange={this.handleChange('STABILITY_1', 'checked')}
              value="STABILITY_1"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Dam completed,No water in reservoir & tail water"
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={audit['STABILITY_2']}
              onChange={this.handleChange('STABILITY_2', 'checked')}
              value="STABILITY_2"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Dull reservoir elevation,normal uplift,normal dry weather"
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={audit['STABILITY_3']}
              onChange={this.handleChange('STABILITY_3', 'checked')}
              value="STABILITY_3"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Reservoir at maximum flood elevation ,all gates open ,normal uplift,silut,bailwater & 
          flood elevation"
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={audit['STABILITY_4']}
              onChange={this.handleChange('STABILITY_4', 'checked')}
              value="STABILITY_4"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Dam completed,No water in reservoir & tail water with earthquake"
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={audit['STABILITY_5']}
              onChange={this.handleChange('STABILITY_5', 'checked')}
              value="STABILITY_5"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Dull reservoir elevation ,normal uplift,normal dry weather with earthquake,no ice"
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={audit['STABILITY_6']}
              onChange={this.handleChange('STABILITY_6', 'checked')}
              value="STABILITY_6"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Reservoir at maximum flood elevation ,all gates open ,extreme uplift,silut,tailwater
          & flood elevation[dravis inperable] "
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={audit['STABILITY_7']}
              onChange={this.handleChange('STABILITY_7', 'checked')}
              value="STABILITY_7"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Reservoir at maximum flood elevation ,all gates open ,extreme uplift,silut,tailwater
          & flood elevation[dravis inperable] "
        />
        <FormControlLabel
          control={
            <Switch
              checked={audit['lowGravityDam']}
              onChange={this.handleChange('lowGravityDam', 'checked')}
              value="lowGravityDam"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Low gravity Dam"
        />
        <FormControlLabel
          control={
            <Switch
              checked={audit['largeDam']}
              onChange={this.handleChange('largeDam', 'checked')}
              value="largeDam"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Large Dam"
        />
        <h2>STABILITY AGAINST COMPRESSION</h2>
        <TextField
          id="allowableCompressiveStressId"
          label="Allowable Compressive Stress"
          value={audit['allowableCompressiveStress']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('allowableCompressiveStress')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="eccentricityId"
          label="Eccentricity"
          value={audit['eccentricity']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('eccentricity')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="verticalLoadId"
          label="Vertical Load"
          value={audit['verticalLoad']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('verticalLoad')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="breadthId"
          label="Breadth"
          value={audit['breadth']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('breadth')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="pId"
          label="P"
          value={audit['p']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('p')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="pSafetyId"
          label="P Safety"
          value={audit['pSafety']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('pSafety')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="maxPId"
          label="Maximum P"
          value={audit['maxP']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('maxP')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="maxPSafetyId"
          label="Maximum P Safety"
          value={audit['maxPSafety']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('maxPSafety')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="minPId"
          label="Minimum P"
          value={audit['minP']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('minP')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="minPSafetyId"
          label="Minimum P Safety"
          value={audit['minPSafety']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('minPSafety')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <h2>SEEPAGE ANALYSIS</h2>
        <TextField
          id="criticalGradientId"
          label="Critical Gradient"
          value={audit['criticalGradient']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('criticalGradient')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="designGradientId"
          label="Design Gradient"
          value={audit['designGradient']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('designGradient')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="blanketAtDownstreatToeId"
          label="The thickness of top imperrious blanket at Downstream toe(db in kg/m3)"
          value={audit['blanketAtDownstreatToe']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('blanketAtDownstreatToe')}
          disabled={viewType == 'VIEW' ? true : false}
          fullWidth
        />
        <TextField
          id="topImperriousBlanketId"
          label="Estimated Saturated unit weight of material in top imperrious blanket"
          value={audit['topImperriousBlanket']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('topImperriousBlanket')}
          disabled={viewType == 'VIEW' ? true : false}
          fullWidth
        />
        <TextField
          id="measuredAboveTailWaterId"
          label="Uplift head of downstream toe of dam measured above tail water(H)		"
          value={audit['measuredAboveTailWater']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('measuredAboveTailWater')}
          fullWidth
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="seepageFsId"
          label="FS"
          value={audit['seepageFs']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('seepageFs')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="seepageSafetyId"
          label="Safety"
          value={audit['seepageSafety']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('seepageSafety')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <FormControlLabel
          control={
            <Switch
              checked={audit['earthenDamStability']}
              onChange={this.handleChange('earthenDamStability', 'checked')}
              value="earthenDamStability"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="STABILITY ANALYSIS OF EARTHEN DAM"
        />
      </div>
    )
  }

  renderAudit2Elements = () => {
    const { audit } = this.state
    const { viewType } = this.props
    return (
      <div className='audit2Container'>
        <h2>FEATURE</h2>
        <FormControlLabel
          control={
            <Switch
              checked={audit['planElevation']}
              onChange={this.handleChange('planElevation', 'checked')}
              value="planElevation"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Plan, elevation Section of dams "
        />
        <TextField
          id="crestElevationId"
          label="Crest Elevation"
          value={audit['crestElevation']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('crestElevation')}
          disabled={viewType == 'VIEW' ? true : false}
        /> 
        <TextField
          id="crestLengthId"
          label="Crest Length"
          value={audit['crestLength']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('crestLength')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="reservoirAreaId"
          label="Reservoir Area"
          value={audit['reservoirArea']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('reservoirArea')}
          disabled={viewType == 'VIEW' ? true : false}
        /> 
        <FormControlLabel
          control={
            <Switch
              checked={audit['freeBoardAllowance']}
              onChange={this.handleChange('freeBoardAllowance', 'checked')}
              value="freeBoardAllowance"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Free Board Allowance"
        />
        <FormControlLabel
          control={
            <Switch
              checked={audit['existingFloodRouteRecord']}
              onChange={this.handleChange('existingFloodRouteRecord', 'checked')}
              value="existingFloodRouteRecord"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Existing Record of flood routing"
        />
        <h2>Highest Peak Flow</h2>
        <TextField
          id="lastYearFlowId"
          label="From Last Year"
          value={audit['lastYearFlow']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('lastYearFlow')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <FormControlLabel
          control={
            <Switch
              checked={audit['emergencyDropDown']}
              onChange={this.handleChange('emergencyDropDown', 'checked')}
              value="emergencyDropDown"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Emergency Drop Down"
        />
        <h2>Spillway</h2>
        <TextField
          id="spillywayNumberId"
          label="Spillyway Number"
          value={audit['spillywayNumber']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('spillywayNumber')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <FormControl disabled={viewType == 'VIEW' ? true : false}>
          <InputLabel htmlFor="spillywayTypeSelector">Spillway Type</InputLabel>
          <Select
            style={{width: 200}}
            value={audit['spillywayType']}
            onChange={this.handleChange('spillywayType')}
            inputProps={{
              name: 'spillywayType',
              id: 'spillywayTypeSelector',
            }}
          >
            {SPILLWAY_TYPEs && SPILLWAY_TYPEs.map((spillywayType, index) => 
              <MenuItem value={spillywayType.value} key={index}>
                {spillywayType.name}
              </MenuItem>
            )}
          </Select>
        </FormControl>
        <FormControlLabel
          control={
            <Switch
              checked={audit['flood']}
              onChange={this.handleChange('flood', 'checked')}
              value="flood"
              color="primary"
              disabled={viewType == 'VIEW' ? true : false}
            />
          }
          label="Flood"
        />
        <h2>GEOLOGY & FOUNDATION</h2>
        <TextField
          id="rockTypeId"
          label="Rock Type"
          value={audit['rockType']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('rockType')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <TextField
          id="foundationProfileId"
          label="Foundation Profile"
          value={audit['foundationProfile']}
          className={'auditTxtFld'}
          style={{margin: '10px'}}
          onChange={this.handleChange('foundationProfile')}
          disabled={viewType == 'VIEW' ? true : false}
        />
        <h2>Draw of Works</h2>
        <div className='switchGroup'>
          <span>Status of pump & motor</span>
          <FormControlLabel
            control={
              <Switch
                checked={audit['flood']}
                onChange={this.handleChange('flood', 'checked')}
                value="flood"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Safe"
          />
        </div>
        <h2>If any Other Problem</h2>
        <input type='file' name='file' onChange={ (e) => this.handleFileChange(e.target.files) }/>
        {/* <Dropzone
            accept="image/jpeg, image/png"
            disabled={viewType == 'VIEW' ? true : false}
            onDrop={(acceptedFiles, rejected) => { 
              // SRC: https://github.com/react-dropzone/react-dropzone
              // https://react-dropzone.js.org/
              // acceptedFiles.forEach(file => {
                const file = acceptedFiles[0]
                dbx.filesUpload({path: '/' + file.name, contents: file})
                .then(function(response) {
                  // var results = document.getElementById('results');
                  // results.appendChild(document.createTextNode('File uploaded!'));
                  console.log(response);
                  console.log('file saved')
                  this.setState({dropbox: response})
                })
                .catch(function(error) {
                  console.error(error);
                });
                // const reader = new FileReader();
                // reader.onload = () => {
                //     const fileAsBinaryString = reader.result;
                //     // do whatever you want with the file content
                // };
                // reader.onabort = () => console.log('file reading was aborted');
                // reader.onerror = () => console.log('file reading has failed');
        
                // reader.readAsBinaryString(file);
            // });
              // this.setState({ accepted, rejected }); 
            }}
          >
            <p>Try dropping some files here, or click to select files to upload.</p>
            <p>Only *.jpeg and *.png images will be accepted</p>
          </Dropzone> */}
      </div>
    )
  }

  renderAudit1Elements() {
    return (
      <div className="audit1Container">
        
      </div>
    )
  }
  
  render() {
    const { userType, viewType } = this.props
    const { audit } = this.state
    return (
      <div className='auditContainer'>
        <TextField
            id="monitoredById"
            label="Monitored By"
            value={audit['monitoredBy']}
            className={'auditTxtFld'}
            style={{margin: '10px'}}
            onChange={this.handleChange('monitoredBy')}
            disabled={viewType == 'VIEW' ? true : false}
          />
          <TextField
            id="waterLevelId"
            label="Water Level(ft)"
            value={audit['waterLevel']}
            className={'auditTxtFld'}
            style={{margin: '10px'}}
            onChange={this.handleChange('waterLevel')}
            disabled={viewType == 'VIEW' ? true : false}
          />
          <div className="auditGroup">
            <TextField
              id="frlCapacityId"
              label="FRL Capacity(Million cu.m)"
              value={audit['frlCapacity']}
              className={'auditTxtFld'}
              style={{margin: '10px'}}
              onChange={this.handleChange('frlCapacity')}
              disabled={viewType == 'VIEW' ? true : false}
            />
            <TextField
              id="mwlCapacityId"
              label="MWL Capacity(Million cu.m)"
              value={audit['mwlCapacity']}
              className={'auditTxtFld'}
              style={{margin: '10px'}}
              onChange={this.handleChange('mwlCapacity')}
              disabled={viewType == 'VIEW' ? true : false}
            />
            <TextField
              id="nearDownstreamCityId"
              label="Nearest Downstream City"
              value={audit['nearDownstreamCity']}
              className={'auditTxtFld'}
              style={{margin: '10px'}}
              onChange={this.handleChange('nearDownstreamCity')}
              disabled={viewType == 'VIEW' ? true : false}
            />
             <TextField
              id="cityDistanceId"
              label="Distance between dam and city"
              value={audit['cityDistance']}
              className={'auditTxtFld'}
              style={{margin: '10px'}}
              onChange={this.handleChange('cityDistance')}
              disabled={viewType == 'VIEW' ? true : false}
            />
            <FormControl style={{margin: '10px'}} disabled={viewType == 'VIEW' ? true : false}>
              <InputLabel htmlFor="districtSelector">Economic Development Extend</InputLabel>
              <Select
                style={{width: 250}}
                value={audit['economicDevelopmentExtend']}
                onChange={this.handleChange('economicDevelopmentExtend')}
                inputProps={{
                  name: 'economicDevelopmentExtend',
                  id: 'economicDevelopmentExtendSelector',
                }}
              >
                {ECONOMIC_DEVELOPMENT_EXTENDs && ECONOMIC_DEVELOPMENT_EXTENDs.map((extend, index) => 
                  <MenuItem value={extend.value} key={index}>
                    {extend.name}
                  </MenuItem>
                )}
              </Select>
            </FormControl>
            <FormControl style={{margin: '10px'}} disabled={viewType == 'VIEW' ? true : false}>
              <InputLabel htmlFor="districtSelector">DAM Type</InputLabel>
              <Select
                style={{width: 250}}
                value={audit['damType']}
                onChange={this.handleChange('damType')}
                inputProps={{
                  name: 'damType',
                  id: 'damTypeSelector',
                }}
              >
                {DAM_TYPEs && DAM_TYPEs.map((damType, index) => 
                  <MenuItem value={damType.value} key={index}>
                    {damType.name}
                  </MenuItem>
                )}
              </Select>
            </FormControl>
          </div>
          {
            (userType == 'AUDITOR_2' || userType == 'AUDITOR_3') &&<FormControlLabel
            control={
              <Switch
                checked={audit['masonary']}
                onChange={this.handleChange('masonary', 'checked')}
                value="masonary"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Masonry/Composite"
            />
          } 
          {
            (userType == 'AUDITOR_2' || userType == 'AUDITOR_3') &&<FormControlLabel
            control={
              <Switch
                checked={audit['earthenDam']}
                onChange={this.handleChange('earthenDam', 'checked')}
                value="earthenDam"
                color="primary"
                disabled={viewType == 'VIEW' ? true : false}
              />
            }
            label="Earthen Dam"
            /> 
          }
          {this.renderInstrumentationReport(userType)}
          {
            (userType == 'AUDITOR_2' || userType == 'AUDITOR_3') && 
            this.renderAudit2Elements()
          }
          { userType == 'AUDITOR_3' && this.renderAudit3Elements() }
          <div className='auditBtnWrapper'>
            {viewType == 'ADD' ? <Button 
              variant="raised" 
              color="primary"
              style={{margin: '0 10px'}} 
              onClick={this.handleAuditSubmit}>
              Register Audit
        </Button> : null }
            <Button 
              variant="raised" 
              color="secondary"
              style={{margin: '0 10px'}} 
              onClick={this.handleAuditCancel}>
              Cancel
            </Button>
          </div>
      </div>
    )
  }
}

export default AuditForm