import React, { Component } from 'react';
import Input, { InputLabel } from 'material-ui/Input';
import { MenuItem } from 'material-ui/Menu';
import { FormControl, FormHelperText } from 'material-ui/Form';
import Select from 'material-ui/Select';

import { getStateList, getDistrictList, getDamList } from 'Util/CountryDataUtil';
import { getDamDetail } from 'Util/DamDetail';
import { convertToString } from 'Util/DateUtil';

const STATEs = getStateList();

class DamSelector extends Component {

  constructor(props) {
    super(props);
  }

  handleChange = event => {
    const eventValue = event.target.value;
    const eventName = event.target.name
    const { state } = this.props
    if(eventName == 'state' && eventValue != '') {
      const districts = getDistrictList(eventValue)
      this.props.onChangeState(eventValue, districts)
    } else if(eventName == 'district' && eventValue != '') {
      const dams = getDamList(eventValue, state)
      this.props.onChangeDistrict(eventValue, dams)
    } else if(eventName == 'dam' && eventValue != '') {
      const damDetail = getDamDetail(eventValue)
      this.props.onChangeDam(eventValue, damDetail)
    }
  };

  render() {
    const { state, district, dam, districts, dams, viewType } = this.props
    return (
      <div>
        <div className='damSelector'>
          <FormControl disabled={viewType == 'VIEW' ? true : false}>
            <InputLabel htmlFor="stateSelector">State</InputLabel>
            <Select
              style={{width: 200}}
              value={state}
              onChange={this.handleChange}
              inputProps={{
                name: 'state',
                id: 'stateSelector',
              }}
            >
              {STATEs && STATEs.map((stateName, index) => 
                  <MenuItem value={stateName} key={index}>
                    {stateName}
                  </MenuItem>
              )}
            </Select>
            <FormHelperText>Select a state</FormHelperText>
          </FormControl>
          <FormControl disabled={viewType == 'VIEW' ? true : false}>
            <InputLabel htmlFor="districtSelector">District</InputLabel>
            <Select
              style={{width: 200}}
              value={district}
              onChange={this.handleChange}
              inputProps={{
                name: 'district',
                id: 'districtSelector',
              }}
            >
              {districts && districts.map((districtName, index) => 
                <MenuItem value={districtName} key={index}>
                  {districtName}
                </MenuItem>
              )}
            </Select>
            <FormHelperText>Select a district</FormHelperText>
          </FormControl>
          <FormControl disabled={viewType == 'VIEW' ? true : false}>
            <InputLabel htmlFor="damSelector">Dam</InputLabel>
            <Select
              style={{width: 200}}
              value={dam}
              onChange={this.handleChange}
              inputProps={{
                name: 'dam',
                id: 'damSelector',
              }}
            >
              {dams && dams.map((damName, index) => 
                <MenuItem value={damName} key={index}>
                  {damName}
                </MenuItem>
              )}
            </Select>
            <FormHelperText>Select a dam</FormHelperText>
          </FormControl>
        </div>
      </div>
    )
  }
}

export default DamSelector;