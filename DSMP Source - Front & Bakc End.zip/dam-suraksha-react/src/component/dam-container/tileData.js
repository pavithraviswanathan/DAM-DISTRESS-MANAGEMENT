import React from 'react';
import { Link } from 'react-router-dom'
import { ListItem, ListItemIcon, ListItemText } from 'material-ui/List';
import HomeIcon from 'material-ui-icons/Home';
import StoreIcon from 'material-ui-icons/Store';
import LaptopIcon from 'material-ui-icons/Laptop';
import PersonIcon from 'material-ui-icons/Person';
import AlertIcon from 'material-ui-icons/Warning';

const DRAWER_OPTIONS = [
	{
		label: 'Home',
    icon: <HomeIcon />,
		to: '/home',
		requiresAuditor: false,
	},
	{
		label: 'Dam',
		icon: <StoreIcon />,
		to: '/complaint',
		requiresAuditor: false,
	},
	{
		label: 'People',
		icon: <PersonIcon />,
		to: '/people',
		requiresAuditor: false,
	},
	{
		label: 'Audit',
    icon: <LaptopIcon />,
		to: '/audit',
		requiresAuditor: true,
	},
	{
		label: 'Alert',
    icon: <AlertIcon />,
		to: '/alert',
		requiresAuditor: false,
	},
]

export const damDrawerListItems = (userType) => {
	return (
  <React.Fragment>
		{
			DRAWER_OPTIONS.map((option, index)=>
				{
					let auditorVerified = true
					if(option.requiresAuditor) {
						// IF userType is not present then considered it as STANDARD user
						 if(!userType || userType == 'STANDARD') {
							auditorVerified = false
						 }
					}
					if(auditorVerified) {
						return (
							<ListItem button 
								key={index}
								component={ props => 
									<Link to={option.to ? option.to : '/home'}  
										style={{ textDecoration: 'none' }}
										{...props} />
								}
							>
								<ListItemIcon>
										{option.icon}
								</ListItemIcon>
								<ListItemText primary={option.label} />
							</ListItem>
						)
					}
					return null;
				}
			)
		}
  </React.Fragment>
)};