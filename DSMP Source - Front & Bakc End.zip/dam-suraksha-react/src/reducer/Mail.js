const initialState = {
}

const Mail = (state = initialState, action) => {
  switch (action.type) {
		case 'SEND_MAIL_SUCCESS':
			return {
				...state,
				...{
					status: 'SEND_MAIL_SUCCESS',
					mail: action.mail
				}
			}
		case 'SEND_MAIL_FAILURE':
			return {...state, ...action}
		default:
      return {...state, ...action}
	}
}

export default Mail