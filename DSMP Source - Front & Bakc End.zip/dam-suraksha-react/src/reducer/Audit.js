const initialState = {
}

const Audit = (state = initialState, action) => {
  switch (action.type) {
		case 'ADD_AUDIT_SUCCESS':
			return {
				...state,
				...{
					type: 'ADD_AUDIT_SUCCESS',
					audit: action.audit
				}
			}
		case 'ADD_AUDIT_FAILED':
			return {...state, ...action}
		case 'COLLECT_AUDIT_SUCCESS':
			return {...state, ...action}
		case 'COLLECT_AUDIT_FAILED':
      return {...state, ...action}
    case 'GET_AUDIT_SUCCESS':
			return {...state, ...action}
		case 'GET_AUDIT_FAILED':
			return {...state, ...action}
		default:
      return {...state, ...action}
	}
}

export default Audit