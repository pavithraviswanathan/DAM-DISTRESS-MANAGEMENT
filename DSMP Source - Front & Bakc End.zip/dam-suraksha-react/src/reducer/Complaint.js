const initialState = {
}

const Complaint = (state = initialState, action) => {
  switch (action.type) {
		case 'ADD_COMPLAINT_SUCCESS':
			return {
				...state,
				...{
					type: action.type,
					complaint: action.complaint
				}
			}
    case 'ADD_COMPLAINT_FAILED':
      return {...state, ...action}
    case 'COLLECT_COMPLAINT_SUCCESS':
      return {...state, ...action}
    case 'COLLECT_COMPLAINT_FAILURE':
      return {...state, ...action}
		default:
      return {...state, ...action}
	}
}

export default Complaint