import { combineReducers } from 'redux';
import User from './User';
import Complaint from './Complaint';
import Mail from './Mail';
import Audit from './Audit';

/**
 * NEW: https://medium.com/@nate_wang/a-new-approach-for-managing-redux-actions-91c26ce8b5da
 */
const Reducers = combineReducers({
  User,
  Complaint,
  Mail,
  Audit
})
   
export default Reducers