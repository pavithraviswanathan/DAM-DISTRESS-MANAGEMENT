const initialState = {
	loggedUser: null
}

const User = (state = initialState, action) => {
  switch (action.type) {
		case 'ADD_USER_SUCCESS':
			return {
				...state,
				...{
					status: 'ADD_USER_SUCCESS',
					user: action.user
				}
			}
		case 'USER_AUTHENTICATION_SUCCESS':
			return {...state, ...action}
		case 'USER_ACTIVATION_SUCCESS':
			return {...state, ...action}
		case 'USER_ACTIVATION_FAILED':
			return {...state, ...action}
		case 'PWD_USER_COLLECTION_SUCCESS':
			return {...state, ...action}
		case 'PWD_USER_COLLECTION_FAILED':
			return {...state, ...action}
		case 'ADD_ALERT_SUCCESS':
			return {...state, ...action}
		case 'ADD_ALERT_FAILED':
			return {...state, ...action}
		default:
      return {...state, ...action}
	}
}

export default User