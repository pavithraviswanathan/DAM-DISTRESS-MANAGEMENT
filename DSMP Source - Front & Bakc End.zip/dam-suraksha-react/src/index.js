import React from 'react';
import ReactDOM from 'react-dom';
import DAM from './DAM';

ReactDOM.render(
  <DAM />,
  document.getElementById('root')
);