import { connect } from 'react-redux';

// const DecisionRoute = ({ trueComponent, falseComponent, decisionFunc, ...rest }) => {
//   return (
//     <Route
//       {...rest}

//       render={
//         decisionFunc()
//           ? trueComponent
//           : falseComponent
//       }
//     />
//   )
// }



// export default DecisionRoute;