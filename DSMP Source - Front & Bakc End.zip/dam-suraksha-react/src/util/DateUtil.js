import Moment from 'moment';

const DATE_FORMAT = "MM/DD/YYYY"

export function convertToString(date) {
  if(Moment.isDate(date)) {
    return Moment(date).format(DATE_FORMAT).toString();
  } else {
    return "Invalid Date";
  }
}