export const getDamDetail = (damName) => {

	let z1,z2,z3,z4,z5,z6, damInfo = {};
	if(damName == 'SELECT DAM') {
		z1="";
		z2="";
		z3="";
		z4="";
		z5="";
		z6="";
	}

	if(damName == 'Adwa Dam') {
		z1="Adwa";
		z2="Earthen";
		z3="1978";
		z4="Irrigation";
		z5="20.48m";
		z6="7906m";
	}
  

 	if(damName == 'Afzalgarh Dam') {
		z1="afzalgarh";
		z2="Earthen";
		z3="1978";
		z4="Irrigation";
		z5="20.48m";
		z6="7906m";
	}
  

	if(damName == 'Ahraura Dam') {
		z1="GARAI";
		z2="Earthen";
		z3="1955";
		z4="Irrigation";
		z5="22.87m";
		z6="1219.5m";
		
	}


	if(damName == 'Arjun Dam') {
		z1="ARJUN River";
		z2="Earthen";
		z3="1957";
		z4="Irrigation";
		z5="25.88m";
		z6="5200m";
	}


	if(damName == 'Aunjhar Dam') {
		z1="Aunjhar";
		z2="Gravity & Masonry";
		z3="1930";
		z4="Irrigation";
		z5="17.6m";
		z6="1056m";
		
	}


	if(damName == 'Bachara Dam') {
		z1="Bachara Dam";
		z2="Earthen";
		z3="1980";
		z4="Irrigation";
		z5="15m";
		z6="660m";
		
	}
		


	if(damName == 'Baghel Khand Dam') {
		z1="Jamunahwa";
		z2="Earthen";
		z3="1957";
		z4="Irrigation";
		z5="14.6m";
		z6="3200m";
		
	}


	if(damName == 'Baghla Dam') {
		z1="Baghla";
		z2="Earthen";
		z3="1987";
		z4="Irrigation";
		z5="14.6m";
		z6="3220m";
		
	}


	if(damName == 'Balui Bandh') {
		z1="local";
		z2="Earthen";
		z3="1988";
		z4="Irrigation";
		z5="16.1m";
		z6="789m";
		
	}
		

	if(damName == 'Balui Dam') {
		z1="local";
		z2="Earthen";
		z3="1998";
		z4="Irrigation";
		z5="14.1m";
		z6="2900m";
		
	}


	if(damName == 'Banjari Kalan Dam') {
		z1="local";
		z2="Earthen";
		z3="1997";
		z4="Irrigation";
		z5="14.1m";
		z6="1470m";
		
	}


	if(damName == 'Barwa Dam') {
		z1="Barwa Nalla";
		z2="Earthen";
		z3="1967";
		z4="Irrigation";
		z5="19m";
		z6="3815m";
		
	}


	if(damName == 'Barwa Sagar Dam') {
		z1="Barwa Nalla";
		z2="Earthen";
		z3="1997";
		z4="Irrigation";
		z5="21.03m";
		z6="1067m";
		
	}


	if(damName == 'Barwar Dam') {
		z1="BORA NALA";
		z2="Earthen";
		z3="1923";
		z4="Irrigation";
		z5="20.04m";
		z6="2233m";
		
	}

	if(damName == 'Barwatola Dam') {
		z1="local";
		z2="Earthen";
		z3="1957";
		z4="Irrigation";
		z5="16.77m";
		z6="1050m";
		
	}


	if(damName == 'Bhagwan Pur Dam') {
		z1="local";
		z2="Earthen";
		z3="1965";
		z4="Irrigation";
		z5="11.28m";
		z6="4400m";
		
	}


	if(damName == 'Bhainsora Dam') {
		z1="Marhwa Nala";
		z2="Earthen";
		z3="1926";
		z4="Irrigation";
		z5="11.26m";
		z6="1850.61m";
		
	}


	if(damName == 'Bhonka Dam') {
		z1="Bhonka";
		z2="Earthen";
		z3="1951";
		z4="Irrigation";
		z5="15.3m";
		z6="2012m";
		
	}


	if(damName == 'Chandra Prabha Dam') {
		z1="Chandra Prabha";
		z2="Earthen";
		z3="1966";
		z4="Irrigation";
		z5="22.25m";
		z6="1600m";
		
	}


	if(damName == 'Chandrawal Dam') {
		z1="Chandrawal";
		z2="Earthen";
		z3="1973";
		z4="Irrigation";
		z5="10m";
		z6="5765m";
		
	}


	if(damName == 'Chittaurgarh Dam') {
		z1="local";
		z2="Earthen";
		z3="1985";
		z4="Irrigation";
		z5="15.3m";
		z6="11000m";
		
	}


	if(damName == 'Deori Dam') {
		z1="local";
		z2="Earthen";
		z3="1978";
		z4="Irrigation";
		z5="21m";
		z6="930m";
		
	}


	if(damName == 'Dhandhraul Dam') {
		z1="Ghaggar";
		z2="Earthen";
		z3="1917";
		z4="Irrigation";
		z5="21m";
		z6="7305m";
		
	}


	if(damName == 'Dhenkwan Dam') {
		z1="local";
		z2="Earthen";
		z3="1985";
		z4="Irrigation";
		z5="20.85m";
		z6="1700m";
		
	}


	if(damName == 'Dongia Dam') {
		z1="GARAI";
		z2="Earthen";
		z3="1918";
		z4="Irrigation";
		z5="15.3m";
		z6="2012m";
		
	}

	if(damName == 'Dongri Dam') {
		z1="PAHUJ";
		z2="Earthen";
		z3="1986";
		z4="Irrigation";
		z5="15.3m";
		z6="2760m";
		
	}
		
		
	if(damName == 'Ganeshpur Dam') {
		z1="local";
		z2="Earthen";
		z3="1976";
		z4="Irrigation";
		z5="15.6m";
		z6="2766m";
		
	}


	if(damName == 'Garhwa Dam') {
		z1="GARWA";
		z2="Earthen";
		z3="1975";
		z4="Irrigation";
		z5="13m";
		z6="980m";
		
	}


	if(damName == 'Ghooga Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1876";
		z4="Irrigation";
		z5="16m";
		z6="520m";
		
	}


	if(damName == 'Ghori Dam') {
		z1="local";
		z2="Earthen";
		z3="1915";
		z4="Irrigation";
		z5="13.87m";
		z6="1584m";
		
	}


	if(damName == 'Girgity Dam') {
		z1="local";
		z2="Earthen";
		z3="1966";
		z4="Irrigation";
		z5="15.18m";
		z6="4800m";
		
	}


	if(damName == 'Gointha Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1992";
		z4="Irrigation";
		z5="13.55m";
		z6="500m";
		
	}

	if(damName == 'Govind Sagar Dam') {
		z1="Shahzad River";
		z2="Earthen";
		z3="1953";
		z4="Irrigation";
		z5="18.29m";
		z6="3606m";
		
	}

	if(damName == 'Gularia Dam') {
		z1="GULARIA STREAM";
		z2="Earthen";
		z3="1966";
		z4="Irrigation";
		z5="12.4m";
		z6="3200m";
		
	}


	if(damName == 'Gunta Dam') {
		z1="GUNTA NALA (YAMUNA)";
		z2="Earthen";
		z3="2003";
		z4="Irrigation";
		z5="29.5m";
		z6="5200m";
		
	}


	if(damName == 'Hinauti Dam') {
		z1="COL NALA";
		z2="Earthen";
		z3="1964";
		z4="Irrigation";
		z5="10.67m";
		z6="995m";
		
	}


	if(damName == 'Jaiwanti Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1928";
		z4="Irrigation";
		z5="15m";
		z6="3352m";
		
	}


	if(damName == 'Jamini Dam') {
		z1="Jamini";
		z2="Earthen";
		z3="1973";
		z4="Irrigation";
		z5="26.22m";
		z6="6400m";
		
	}


	if(damName == 'Jirgo Dam') {
		z1="Jirgo";
		z2="Earthen";
		z3="1958";
		z4="Irrigation";
		z5="29.88m";
		z6="6740m";
		
	}


	if(damName == 'Jogendra Dam') {
		z1="Jogendra";
		z2="Earthern";
		z3="1970";
		z4="Irrigation";
		z5="10.04m";
		z6="1313m";
		
	}


	if(damName == 'Kabrai Dam') {
		z1="local";
		z2="Earthern";
		z3="1955";
		z4="Irrigation";
		z5="18.24m";
		z6="2300.2m";
		
	}

	if(damName == 'Kachnoda Dam') {
		z1="";
		z2="Earthern";
		z3="2012";
		z4="Irrigation";
		z5="18.9";
		z6="4100";
		
	}


	if(damName == 'Kargara Dam') {
		z1="LOCAL";
		z2="Earthern";
		z3="1978";
		z4="Irrigation";
		z5="16.84m";
		z6="1410m";
		
	}


	if(damName == 'Keolari Dam') {
		z1="local";
		z2="Earthern";
		z3="1966";
		z4="Irrigation";
		z5="11.73m";
		z6="2836.58m";
		
	}


	if(damName == 'Khairman Dam') {
		z1="HENGA NALA";
		z2="Earthern";
		z3="1958";
		z4="Irrigation";
		z5="10.6m";
		z6="3020m";
		
	}


	if(damName == 'Khandeha Dam') {
		z1="DASRATH NALA";
		z2="Earthern";
		z3="1929";
		z4="Irrigation";
		z5="19.9m";
		z6="1200m";
		
	}


	if(damName == 'Khapatia Dam') {
		z1="BORERA";
		z2="Earthern";
		z3="1916";
		z4="Irrigation";
		z5="16m";
		z6="806m";
		
	}


	if(damName == 'Khirihata Dam') {
		z1="LOCAL";
		z2="Earthern";
		z3="1992";
		z4="Irrigation";
		z5="10.72m";
		z6="178m";
		
	}

	if(damName == 'Kohar Gaddi Dam') {
		z1="";
		z2="Earthern";
		z3="1930";
		z4="Irrigation";
		z5="10.5m";
		z6="2820m";
		
	}


	if(damName == 'Kota Dam') {
		z1="LOCAL";
		z2="Earthern";
		z3="1960";
		z4="Irrigation";
		z5="14.63m";
		z6="549m";
		
	}


	if(damName == 'Kotra Khambha Dam') {
		z1="";
		z2="Earthern";
		z3="1915";
		z4="Irrigation";
		z5="18m";
		z6="806m";
		
	}


	if(damName == 'Kuba Khurd Dam') {
		z1="LOCAL";
		z2="Earthern";
		z3="1988";
		z4="Irrigation";
		z5="10.33m";
		z6="1675m";
		
	}


	if(damName == 'Lachura Dam') {
		z1="LOCAL";
		z2="Earthen / Gravity & Masonry";
		z3="1910";
		z4="Irrigation";
		z5="14.94m";
		z6="542.3m";
		
	}


	if(damName == 'Lower Khajuri Dam') {
		z1="Kuardari Nalla";
		z2="Earthen / Gravity & Masonry";
		z3="1949";
		z4="Irrigation";
		z5="18m";
		z6="640m";
		
	}



	if(damName == 'Majhgawan Dam') {
		z1="GUNCHI NALA";
		z2="Earthen";
		z3="1917";
		z4="Irrigation";
		z5="19.43m";
		z6="1402m";
		
	}


	if(damName == 'Matatila Dam') {
		z1="Betwa";
		z2="Earthen";
		z3="1958";
		z4="Irrigation";
		z5="45.72m";
		z6="6300m";
		
	}


	if(damName == 'Maudaha (Swami Brahmanand ) Dam') {
		z1="Betwa";
		z2="Earthen";
		z3="2003";
		z4="Irrigation";
		z5="32.6m";
		z6="3480m";
		
	}


	if(damName == 'Meja Dam') {
		z1="Belan";
		z2="Earthen";
		z3="1987";
		z4="Irrigation";
		z5="40m";
		z6="2000m";
		
	}


	if(damName == 'Moosakhand Dam') {
		z1="KARMNASA";
		z2="Earthen";
		z3="1967";
		z4="Irrigation";
		z5="33.53m";
		z6="2987m";
		
	}

	if(damName == 'Muirpur Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1992";
		z4="Irrigation";
		z5="15.3m";
		z6="581m";
		
	}


	if(damName == 'Murtia Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1977";
		z4="Irrigation";
		z5="18.26m";
		z6="1135m";
		
	}


	if(damName == 'Nagwa Dam') {
		z1="KARMANASA RIVER";
		z2="Earthen";
		z3="1950";
		z4="Irrigation";
		z5="20.31m";
		z6="2810.19m";
		
	}


	if(damName == 'Nanauti Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1963";
		z4="Irrigation";
		z5="13.71m";
		z6="1400m";
		
	}


	if(damName == 'Narson Dam') {
		z1="NARSON";
		z2="Earthen";
		z3="1988";
		z4="Irrigation";
		z5="14.33m";
		z6="2340m";
		
	}


	if(damName == 'Naugarh Dam') {
		z1="KARMNASA";
		z2="Earthen";
		z3="1956";
		z4="Irrigation";
		z5="18.9m";
		z6="5975m";
		
	}


	if(damName == 'Obra Dam') {
		z1="RIHAND";
		z2="Earthen / Gravity & Masonry";
		z3="1970";
		z4="Hydroelectric,Irrigation";
		z5="29.33m";
		z6="2000m";
		
	}


	if(damName == 'Ohen Dam') {
		z1="RIHAND";
		z2="Earthen / Gravity & Masonry";
		z3="1961";
		z4="Irrigation";
		z5="24.08m";
		z6="2527m";
		
	}


	if(damName == 'Pachwara Lake Dam') {
		z1="LOCAL";
		z2="Earthen / Gravity & Masonry";
		z3="1694";
		z4="Irrigation";
		z5="13.72m";
		z6="208m";
		
	}


	if(damName == 'Pahari Dam') {
		z1="LOCAL NALLA";
		z2="Earthen / Gravity & Masonry";
		z3="1912";
		z4="Irrigation";
		z5="10m";
		z6="580.95m";
		
	}


	if(damName == 'Pahuj Dam') {
		z1="PAHUJ";
		z2="Earthen / Gravity & Masonry";
		z3="1912";
		z4="Irrigation";
		z5="10.67m";
		z6="2040m";
		
	}

		
	if(damName == 'Patharai Dam') {
		z1="PATHARI AND SUKHNAI (TRIBUTARY OF DHASAN)";
		z2="Earthen";
		z3="2002";
		z4="Irrigation";
		z5="18m";
		z6="3800m";
		
	}



	if(damName == 'Pili Dam') {
		z1="Pili";
		z2="Earthen";
		z3="1968";
		z4="Irrigation";
		z5="19m";
		z6="1540m";
		
	}


	if(damName == 'Ragura Dam') {
		z1="Local";
		z2="Gravity & Masonry";
		z3="1976";
		z4="Irrigation";
		z5="12.05m";
		z6="1189m";
		
	}


	if(damName == 'Raipura Dam') {
		z1="local";
		z2="Earthen";
		z3="1930";
		z4="Irrigation";
		z5="13m";
		z6="3509m";
		
	}


	if(damName == 'Rajghat Dam') {
		z1="betwa";
		z2="Earthen / Gravity & Masonry";
		z3="1930";
		z4="Hydroelectric,Irrigation,Drinking / Water Supply";
		z5="43.5m";
		z6="11200m";
	}


	if(damName == 'Rajkhar Dam') {
		z1="LOCAL STREAM";
		z2="Earthen";
		z3="1957";
		z4="Irrigation";
		z5="14.94m";
		z6="970m";
	}


	if(damName == 'Rampur Dam') {
		z1="GOINGHAWA NALA	";
		z2="Earthen";
		z3="1958";
		z4="Irrigation";
		z5="10.5m";
		z6="3820m";
	}


	if(damName == 'Rampur Kalyangarh Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1925";
		z4="Irrigation";
		z5="13m";
		z6="1000m";
		
	}


	if(damName == 'Rampur Pindaria Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1974";
		z4="Irrigation";
		z5="10.3m";
		z6="1260m";
		
	}


	if(damName == 'Rihand Dam') {
		z1="Rihand";
		z2="Gravity & Masonry";
		z3="1962";
		z4="Hydroelectric,Irrigation";
		z5="91.46m";
		z6="932m";
		
	}

	if(damName == 'Rohini Dam') {
		z1="ROHINI";
		z2="Earthen";
		z3="1983";
		z4="Irrigation";
		z5="17.82m";
		z6="1647m";
		
	}

	if(damName == 'Sajnam Dam') {
		z1="Mahrauni";
		z2="Earthen";
		z3="1990";
		z4="Irrigation";
		z5="22.34m";
		z6="4524m";
		
	}


	if(damName == 'Saktesh Garh Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1989";
		z4="Irrigation";
		z5="15.66m";
		z6="880m";
		
	}


	if(damName == 'Salarpur Dam') {
		z1="KARDIA";
		z2="Earthen";
		z3="1960";
		z4="Irrigation";
		z5="11m";
		z6="2975m";
		
	}


	if(damName == 'Saprar Dam') {
		z1="";
		z2="Earthen";
		z3="1952";
		z4="Irrigation";
		z5="16.76m";
		z6="3000m";
		
	}

	if(damName == 'Sarai Garh Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1970";
		z4="Irrigation";
		z5="10.82m";
		z6="735m";
		
	}

	if(damName == 'Sarda Sagar Dam') {
		z1="Sharda";
		z2="Earthen";
		z3="1962";
		z4="Irrigation";
		z5="16.15m";
		z6="2220m";
		
	}


	if(damName == 'Semri Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1989";
		z4="Irrigation";
		z5="14.8m";
		z6="666m";
		
	}


	if(damName == 'Shahjad Dam') {
		z1="local";
		z2="Earthen";
		z3="1992";
		z4="Irrigation";
		z5="18m";
		z6="4160m";
		
	}


	if(damName == 'Siori Lake Dam') {
		z1="Siori";
		z2="Earthen";
		z3="1911";
		z4="Irrigation";
		z5="13.94m";
		z6="2306m";
		
	}


	if(damName == 'Sirsi Dam') {
		z1="Bakhar Nala";
		z2="Earthen";
		z3="1958";
		z4="Irrigation";
		z5="21.34m";
		z6="3808m";
		
	}


	if(damName == 'Sukhra Dam') {
		z1="SUKHARA NALA";
		z2="Earthen";
		z3="1909";
		z4="Irrigation";
		z5="12.2m";
		z6="1158m";
		
	}

	if(damName == 'Suswar Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1987";
		z4="Irrigation";
		z5="14.03m";
		z6="1400m";
		
	}


	if(damName == 'Upper Khajuri Dam') {
		z1="Chandauli and Shibati";
		z2="Earthen";
		z3="1958";
		z4="Irrigation";
		z5="24.88m";
		z6="2313m";
		
	}

	if(damName == 'Urmil Dam') {
		z1="Urmil";
		z2="Earthen";
		z3="1998";
		z4="Irrigation";
		z5="25.56m";
		z6="4799m";
		
	}

	if(damName == 'Vijaipur Dam') {
		z1="LOCAL";
		z2="Earthen";
		z3="1983";
		z4="Irrigation";
		z5="14.3m";
		z6="570m";
		
	}
	
	if(damName == 'Gadigaltar Dam') {
		z1="Undri Nadi";
		z2="Earthen";
		z3="1990";
		z4="Irrigation";
		z5="873m";
		z6="23.19m";
	}
	
  if(damName == 'Gagan Dam') {
		z1="Local";
		z2="Earthen";
		z3="1959";
		z4="Irrigation";
		z5="880m";
		z6="18.28m";
	}
	
	if(damName == 'Gambhir (PHE) Dam') {
		z1="Gambhir";
		z2="Earthen / Gravity & Masonry";
		z3="1991";
		z4="Irrigation";
		z5="1230m";
		z6="32m";
	}
	
	if(damName == 'Gandhi Sagar Dam') {
	z1="CHAMBAL";
	z2="Gravity & Masonry";
	z3="1960";
	z4="Gravity & Masonry";
	z5="62.17m";
	z6="514m";
	}
	
	if(damName == 'Gandhwal Dam') {
	z1="Local";
	z2="Earthen";
	z3="1987";
	z4="Irrigation";
	z5="17.75m";
	z6="425m";
	}
	
	if(damName == 'Ganeshpura Dam') {
	z1="Local";
	z2="Earthen";
	z3="2003";
	z4="Irrigation";
	z5="16.4m";
	z6="536m";
	}
	if(damName == 'Gangajali Dam') {
	z1="Local";
	z2="Earthen";
	z3="1981";
	z4="Irrigation";
	z5="13.78m";
	z6="250m";
	}
	
	if(damName == 'Gangulpara Dam') {
	z1="Ghisiri";
	z2="Earthen";
	z3="1960";
	z4="Irrigation";
	z5="19.51m";
	z6="3009m";
	}
	
	if(damName == 'Garethia Dam') {
	z1="-";
	z2="Earthen";
	z3="1991";
	z4="Irrigation";
	z5="14.9m";
	z6="2438.42m";
	}
	
	
	if(damName == 'Gawala Dam') {
	z1="Karondiya Nadi";
	z2="Earthen";
	z3="1979";
	z4="Irrigation";
	z5="11.68m";
	z6="168m";
	}
	
	if(damName == 'Geolari Dam') {
	z1="Kalidahar Nadi";
	z2="Earthen";
	z3="1966";
	z4="Irrigation";
	z5="579m";
	z6="19.44m";
	}
	
	
	if(damName == 'Ghatera Dam') {
	z1="-";
	z2="Earthen";
	z3="1956";
	z4="Irrigation";
	z5="14.6m";
	z6="1560m";
	}
	
	
	if(damName == 'Ghoghatpur Dam') {
	z1="Local";
	z2="Earthen";
	z3="2003";
	z4="Irrigation";
	z5="435m";
	z6="20.3m";
	}
	
	if(damName == 'Ghoora Dam') {
	z1="Local";
	z2="Earthen";
	z3="not known";
	z4="Irrigation";
	z5="10.97m";
	z6="854m";
	}
	
	if(damName == 'Ghorapachhar Dam') {
	z1="Ghorapachar Nalla";
	z2="Earthen";
	z3="1986";
	z4="Irrigation";
	z5="23.42m";
	z6="1841m";
	}
	
	
	if(damName == 'Godaghat Dam') {
	z1="Local";
	z2="Earthen";
	z3="1930";
	z4="Irrigation";
	z5="18.4m";
	z6="1740m";
	}
	
	if(damName == 'Golai Dam') {
	z1="Local";
	z2="Earthen";
	z3="1979";
	z4="Irrigation";
	z5="11m";
	z6="823m";
	}
	
	
	if(damName == 'Gonda Dam') {
	z1="Local";
	z2="Earthen";
	z3="1979";
	z4="Irrigation";
	z5="11m";
	z6="823m";
	}
	
	if(damName == 'Gondhidhana Dam') {
	z1="Local";
	z2="Earthen";
	z3="1974";
	z4="Irrigation";
	z5="14.08m";
	z6="681m";
	}
	
	if(damName == 'Gondigoulla Dam') {
	z1="Selgaon Nala";
	z2="Earthen";
	z3="1982";
	z4="Irrigation";
	z5="15m";
	z6="629m";
	}
	
	if(damName == 'Gopalpura (MP) Dam') {
	z1="Local";
	z2="Earthen";
	z3="1954";
	z4="Irrigation";
	z5="18.9m";
	z6="792.48m";
	}
	
	if(damName == 'Gopinathpur Dam') {
	z1="Local";
	z2="Earthen";
	z3="2004";
	z4="Irrigation";
	z5="10.9m";
	z6="750m";
	}
	
	if(damName == 'Goverdhanpura Dam') {
	z1="Junapani";
	z2="Earthen";
	z3="1982";
	z4="Irrigation";
	z5="17.63m";
	z6="283m";
	}
	
	
	if(damName == 'Govindgarh Dam') {
	z1="Bihar Nadi";
	z2="Earthen";
	z3="1970";
	z4="Irrigation";
	z5="21.34m";
	z6="5230m";
	}
	
	
	if(damName == 'Govindpura Dam') {
	z1="Local";
	z2="Earthen";
	z3="1992";
	z4="Irrigation";
	z5="16.43m";
	z6="526m";
	}
	
	
	if(damName == 'Guda Dam') {
	z1="Local";
	z2="Earthen";
	z3="1983";
	z4="Irrigation";
	z5="10.54m";
	z6="570m";
	}
	
	if(damName == 'Guddikheda Dam') {
	z1="Local";
	z2="Earthen";
	z3="1984";
	z4="Irrigation";
	z5="12.45m";
	z6="960m";
	}
	
	if(damName == 'Gudgaon Dam') {
	z1="Local";
	z2="Earthen";
	z3="1976";
	z4="Irrigation";
	z5="12.86m";
	z6="570m";
}
	
	if(damName == 'Gujramal Dam') {
	z1="Local";
	z2="Earthen";
	z3="1982";
	z4="Irrigation";
	z5="10.44m";
	z6="701m";
}
	
	if(damName == 'Gulabpura Dam') {
		z1="Anas";
		z2="Earthen";
		z3="1982";
		z4="Irrigation";
		z5="18.35m";
		z6="790m";
	}
	
	if(damName == 'Guradia Roopchand Dam') {
		z1="Ashta";
		z2="Earthen";
		z3="1984";
		z4="Irrigation";
		z5="10.97m";
		z6="1050m";
	}
	damInfo.RESERVOIR = z1;
	damInfo.TYPE_OF_DAM = z2;
	damInfo.YEAR_OF_COMPLETION = z3; 
	damInfo.PURPOSE = z4;
	damInfo.HEIGHT = z5;
	damInfo.LENGTH = z6;
	return damInfo;
}




