export const getStateList = () => {
  // console.log(Object.keys(COUNTRY_DAM_DATA))
  return Object.keys(COUNTRY_DAM_DATA)
}

export const getDistrictList = (stateName) => {
  const stateObj = COUNTRY_DAM_DATA[stateName]
  if(stateObj && stateObj.DISTRICT) {
    return Object.keys(stateObj.DISTRICT)
  }
  return [];
}

export const getDamList = (districtName, stateName) => {
  const districtObj = COUNTRY_DAM_DATA[stateName] ? 
    COUNTRY_DAM_DATA[stateName].DISTRICT : null
  if(districtObj && districtObj[districtName]) {
    return districtObj[districtName].DAMS
  }
  return []
}
export const getCountryData = () => {
  return COUNTRY_DATA;
}

const COUNTRY_DAM_DATA = {
  "Andhra Pradesh": {
    "DISTRICT": {
      "Anantapur": {
        "DAMS": [ "Ahobilam /Penna Ahobilam (Dr. K.S.P.A.B.R.)Dam",
          "Bhairavanithippa Dam", "Bukkapatnam Dam","Chagallu Barrage Dam",
          "Chinnarayaswamy Gudi /Chennaraya Dam","Dharmavaram Dam",
          "Gooty Tank","Haresamudram Big Dam","Kanelal Tank",
          "Madakasira Dam","Marala Dam","Matchukota Balancing Reservoir",
          "Midpennar Stage-I/Mid-Pennar Dam","Panthulu Cheruvu Dam",
          "Pedaballi Dam","Nagasamudram Dam","Pendekallu","Rayalacheruvu Dam",
          "Sreerangarayani Cheruvu Dam","Upper Pennar Dam","Y.T.Cheruvu Dam",
          "Yogivemana Dam"]
      },
      "Chittoor": {
        "DAMS": ["Arniar Dam","Bahuda Dam","Kalangi Dam","Kalyani Dam","Krishnapuram (Chittor)Dam","Mallimadugu Dam","Paya Cheruvu Dam","Pedda Rayala Cheruvu Dam","Pedda Tippa Samudram Dam"," Peddabadava, Tulasikrishan Dam","Peddayetivanka, Annupal Dam"," Pedderu Dam","Peruru Sadasivakona Dam","Sankarayalapeta Dam","Siddalagandi Dam","Vyasasamudram Dam"]
      },
      "East Godavari": {
        "DAMS":["Bhupathipalem Dam","Maddigedda Dam","Musurumilli /Musurmilli Dam","Pampa Dam","Polavaram Dam","Surampalem Dam","Yeleru Dam"]
      },
      "Guntur": {
        "DAMS": ["Buggavagu Dam"]
      },
      "Krishna": {
        "DAMS": ["Akkapalem Dam","Thammileru Dam"]
      },
      "Kurnool": {
        "DAMS": ["Alaganoor Dam","Gajuladinne (Sanjeevaiah Sagar) Dam","Gorakallu Dam","Jalakanur Dam","Nagurur Dam","Paleru ,Owk Dam","Sri Tenneti Viswanatham Pedderu Dam","Varadaraja Swamy Gudi Dam","Velugodu Dam","Zurreru Dam"]
      },
      "Prakasam": {
        "DAMS":["Cumbum Dam","Gandicheruvu (Dist-Prakasam) Dam","Gundlakamma Dam","Gundlamotu Dam","Kakarla Dam","Mopadu Dam","Muraripalli / Mararipalli Dam","Pittakayagulla Dam","Rallapadu Dam","Ramathirtham Dam","Seethai Cheru, Seethaipally Dam","Thippayapalem Dam","Turimella Reservoir Dam","Veligonda Dam"]
      },
      "Srikakulam": {
         "DAMS": ["Hiramandalam Dam","Kalinga Dal Dam ","Madduvalasa Dam","Narayanapuram Dam"]
      },
      "SriPotti Sri Ramulu Nellore": {
        "DAMS":["Ananthasagarm Dam","Gandipalem /Pcr Gandipalem Dam","Kampasamudram New Dam","Kandaleru /Kandaleru Dam","Kanigiri Dam","Nakkalagandi Dam","Nellore Dam","Somasila Dam"]
      },
      "Vishakhapatnam": {
        "DAMS":["Ghambiramgedda Dam","Guntawada Main Dam","Jajigedda Dam","Konam Dam","N.T.R. , Thatiparthi(V), Madugula (M) Dam","Raiwada Dam","Sri Tenneti Viswanatham Pedderu Dam","Tajangi , Tajangi(V) Dam","Thandava(Sri Raja Sagi Suryanarayana Raju (Srssr)","Urakagedda , Sankaram (V), Madugula(M) Dam","Varaha Dam"]
      },
      "Vizianagaram": {
        "DAMS": ["Jhanjhavathi / Janjavathi Dam","Kumili Dam","Peddagedda Dam","Thatipudi Dam","Vanaka Badigedda Dam","Vengalaraya Sagar Dam","Vottigadda Dam"]
      },
      "West Godavari": {
        "DAMS": ["Jalleru Dam","Kovvadakalva Dam","Yerrakalva Dam"]
      },
      "Cudappah": {
        "DAMS": []
      }
    }
  },
  "Arunachal Pradesh": {
    "DISTRICT": {
      "Papum Pare": {
        "DAMS": ["Ranganadi Dam"]
      },
      "Lower Subansiri": {
        "DAMS": ["Subansiri Lower HE (Nhpc) Dam"]
      },
    }
  },
  "Assam": {
    "DISTRICT": {
    "Karbi Anglong": {
        "DAMS": ["Karbi Langpi Dam"]
      },
      "Dima Hasao": {
        "DAMS": ["Umrong Dam"]
      },
    }
  },
  "Bihar": {
    "DISTRICT": {
      "Araria": {
        "DAMS":[]
      },
      "Arwal": {
        "DAMS":[]
      },
      "Aurangabad": {
        "DAMS":[]
      },
      "Banka": {
        "DAMS": ["Badua Dam","Belharna Dam","Bilasi Dam","Chandan Dam","Orhni Dam"]
      },
      "Begusarai": {
        "DAMS":[]
      },
      "Bhagalpur": {
        "DAMS":[]
      },
      "Bhojpur": {
        "DAMS":[]
      },
      "Buxar": {
        "DAMS":[]
      },
      "Darbhanga": {
        "DAMS":[]
      },
      "East Champaran": {
        "DAMS":[]
      },
      "Gaya": {
        "DAMS":[]
      },
      "Gopalganj": {
        "DAMS":[]
      },
      "Jamui": {
        "DAMS": ["Ajan Dam","Amrity Dam","Barnar Dam","Kailash Ghati Dam","Nagi Dam","Nakti (Bihar) Dam","Srikhandi Dam","Upper Kiul Dam"]
      },
      "Jehanabad": {
        "DAMS":[]
      },
      "Kaimur": {
        "DAMS": ["Durgawati Dam","Kohira Dam"]
      },
      "Katihar": {
        "DAMS":[]
      },
      "Khagaria": {
        "DAMS":[]
      },
      "Kishanganj": {
        "DAMS":[]
      },
      "Lakhisarai": {
        "DAMS": ["Baskund Dam","Morwy Dam"]
      },
      "Madhepura": {
        "DAMS":[]
      },
      "Madhubani": {
        "DAMS":[]
      },
      "Munger": {
        "DAMS": ["Gaighat Dam","Jalkund Dam","Khargpur Lake Dam","Sindhwarni Dam"]
      },
      
      "Muzaffarpur": {
        "DAMS":[]
      },
      "Nalanda": {
        "DAMS":[]
      },
      "Nawada": {
        "DAMS": ["Job Dam","Kolmahadeo Dam","Phulwaria Dam"]
      },
      "Patna": {
        "DAMS":[]
      },
      "Purnia": {
        "DAMS":[]
      },
      "Rohtas": {
        "DAMS":[]
      },
      "Saharsa": {
        "DAMS":[]
      },
      
      "Samastipur": {
        "DAMS":[]
      },
      "Saran": {
        "DAMS":[]
      },
      "Sheikhpura": {
        "DAMS":[]
      },
      "Sheohar": {
        "DAMS":[]
      },
      "Sitamarhi": {
        "DAMS":[]
      },
      "Siwan": {
        "DAMS":[]
      },
      "Supaul": {
        "DAMS":[]
      },
      
      "Vaishali": {
        "DAMS":[]
      },
      "West Champaran": {
        "DAMS":[]
      }
    }
   
  },"Chhattisgarh": {
    "DISTRICT": {"Bastar": {
        "DAMS":[]
      },
      "Bijapur": {
        "DAMS":[]
      },
      "Bilaspur": {
        "DAMS": ["Agariya Dam","Amachuwa Dam","Champi Dam","Chourasiya Dam","Dhanras Dam","Dhawanpur Dam","Fulwari Dam","Gagnai Dam","Gangpur Dam","Ghongha Dam","Kharung Dam","Kopra Dam","Malhaniya Dam","Maniyari Dam","Sawatpur Dam","Semraha Dam","Sonkachhar Dam","Tulutolia Dam"]
      },
      "Dantewada": {
        "DAMS":[]
      },
      "Dhamtari": {
        "DAMS":[]
      },
      "Durg": {
        "DAMS": ["Bhortola Dam","Bordi Dam","Chikhali Dam","Darritola Dam","Gondli Dam","Gunderdehi Dam","Khapri Dam","Kharkhara Dam","Salap Dam","Tandula Dam","Usaritola Dam"]
      },
      "Jashpur": {
        "DAMS":[]
      },
      "Janjgir-Champa": {
        "DAMS":[]
      },
      "Korba": {
        "DAMS": ["Amakhokhra Dam","Gursia Dam","Junwani Dam","Kehra Dam","Kothari Dam","Kunkuna Dam","Minimata (Hasdeo) Bango Dam","Murwadand Dam","Sadamar Tank","Saila Dam","Salihabhata Dam","Salihapara Dam"]
      },
      "Koriya": {
        "DAMS": ["Badesathi Dam","Badra Dam","Banjaridand Dam","Bardar Dam","Barkela Dam","Barpara Dam","Belbehra Dam","Chanti Dam","Charcha Dam","Charpara Dam","Ganeshpur Dam","Gej Dam","Gobari Dam","Jagatpur Dam","Jhumka Dam","Kachhod Dam","Kadna Dam","Kalidaraha Dam","Kartama Dam","Khadgawan Dam","Khanda Dam","Kusmaha Dam","Lai Dam","Lanchi Dam","Maharajpur Dam","Masarra Dam","Morga Dam","Murma Dam","Pachni Dam","Pathargawan Dam","Rajoli Dam","Rajpuri Dam","Sawla Dam","Silphoda Dam","Sonhat Dam","Tamdand Dam","Tanjara Dam","Tartora Dam"]
      },
      "Kanker": {
        "DAMS": ["Binjali Dam","P.V. Pakhanjore Dam"]
      },
      "Kabeerdham": {
        "DAMS": ["Beherakhar (Banjar ) Dam","Belhari Dam","Bhoramdeo Dam","Chaker Dam","Chhirpani Dam","Hathlewa Dam","Kranti Dam","Rengakhar Dam","Rochand Dam","Saroda Dam","Sutiapat Dam","Udka Dam"]
      },
      "Mahasamund": {
        "DAMS": ["Amakoni Dam","Deogaon Dam","Kalidaraha Dam","Keshwa Dam","Khallari Dam","Kodar Dam","Singhora Dam","Thakurdiya Dam"]
      },
      "Narayanpur": {
        "DAMS":[]
      },
      "Raigarh": {
        "DAMS": ["Auramimunda Dam","Chhota Palgi Dam","Katangi Dam","Kathripali Dam","Kedarnalla Dam","Kelo Dam","Khamhar Pakut Dam","Kinkari Dam","Kokanitarai Dam","Kopar Dam","Kotarimal Dam","Kumharta Dam","Lohakhan I Dam","Nagoi Dam","Pelam Dam","Putta Dam","Sakarsundari Dam","Salkha Dam","Sistringa Dam","Tumdih Dam"]
      },
      "Rajnandgaon": {
        "DAMS": ["Amgaon Dam","Aondhi Dam","Ayabhandha Dam","Bhagwantola Dam","Churiyapat Dam","Deokatta Dam","Dhara Dam","Gatatola Dam","Khursipar Dam","Kohkatta Dam","Koliyari Dam","Manki Dam","Masooljob Dam","Matia Motinalla Dam","Nawagaon Dam","Paniyajob Dam","Piparia Dam","Piparia Subsidiary Dam","Purena Dam","Ruse Dam","Uperwah Dam"]
      },
      "Raipur": {
        "DAMS": ["Adpather Dam","Ballar Dam","Dhupkot Dam","Diona Dam","Ganiyari Dam","Ghughwa Dam","Ghumarapadar Dam","Kanesar Dam","Kosmi Dam","Kumhari Dam","Maroda Dam","Pairi Dam","Pindrawan Dam","Piperchedi Dam","Thelka Dam","Torenga Dam","Toulidih Dam"]
      },
      "Surajpur": {
        "DAMS":[]
      },
      "Surgura": {
        "DAMS": ["Ajabnagar Dam","Amhar Dam","Badauli Dam","Badrika Ashram Dam","Banki Dam","Bankipur Dam","Barnai Dam","Barota Dam","Batra Dam","Bhopali Dam","Barnai Dam","Bhulsi Dam","Bhursatoli Dam","Chamat Dam","Chandra Nagar Dam","Chhota Palgi Dam","Chiniya Dam","Dandgaon Dam","Darki Dam","Dhab Dam","Dhamni No. I Dam","Doura Dam","Fatehpur Dam","Ghoghra Dam","Ghunghutta Dam","Jagannathpur Dam","Jamdih Dam","Jhalpi Dam","Jhingo Dam","Keoti Dam","Khaliba Dam","Kharjir (Khajuri) Dam","Khunal (Khunsi) T Dam","Koinari Dam","Koushalpur Dam","Kunwarpur Dam","Lanchi Dam","Longit Dam","Luti Dam","Narkola Dam","Nawadhi Dam","Nawkerra Dam","Pachawal Dam","Palgi Dam","Pandridand Dam","Parasrampur Dam","Pasla Dam","Pirha Dam","Pondi Dam","Pradodah Dam","Putta Dam","Ramanujganj Dam","Ramchandrapur Dam","Rikhi Dam","Sagasoti Dam","Saliyadih Dam","Shivepur Dam","Sividog Dam","Styanagar Dam","Trikunda Dam","Turga Dam","Uliya Dam"]
      },
      "UttarBastarKanker": {
        "DAMS": ["Amabeda Dam","Dudhawa Dam","Gouri Dam","Khairkheda Dam","Manikpur Dam","Mankeshwari Dam","Mayana Dam","PV-133 Dam","Palachur Dam","Paralkot Dam","Risewada Dam","Sonpur Dam"]
      },
    }
  },"Goa": {
    "DISTRICT": {
      "Chapora": {
        "DAMS":[]
      },
      "Dabolim": {
        "DAMS":[]
      },
      "Madgaon": {
        "DAMS":[]
      },
      "Marmugao (Marmagao)": {
        "DAMS":[]
      },
      "North Goa": {
        "DAMS": ["Anjunam Dam"]
      },
      "South Goa": {
        "DAMS": ["M.I. Dam","Salaulim Dam"]
      },
      "Panaji Port": {
        "DAMS":[]
      },
      "Panjim": {
        "DAMS":[]
      },
      "Pellet Plant Jetty/Shiroda": {
        "DAMS":[]
      },
      "Talpona": {
        "DAMS":[]
      },
      "Vasco da Gama": {
        "DAMS":[]
      },
    }
  },"Gujarat": {
    "DISTRICT": {
      "Ahmadabad": {
        "DAMS": ["Khambhada Dam","Utavali (Gunda) Dam"]
      },
      "Amreli district": {
        "DAMS": ["Abhalwad Dam","Ambani Khodiar Dam","Bharad Dam","Dhameli Dam","Dhatarwadi-I Dam","Dhatarwadi-II Dam","Dhrufania Dam","Ghelo(I) Dam","Hamapur Dam","Ingorala Dam","Jaljivadi Dam","Krushnagadh Dam","Lakhapadar Dam","Lalaka Dam","Likhala Ddam","Mevasa Dam","Mobhness Dam","Mota Ankadia Dam","Mota Bandharia Dam","Mota-Zinzuda Dam","Munjiasar Dam","Nal Dam","Navali Dam","Nilwada Dam","Piparala Dam","Raidy Dam","Ratada Dam","Ravana Dam","Sankroli Dam","Sarakhadia Dam","Senjal Dam","Shetrunji Khodiar Dam","Sukhpur Dam","Surajwadi Dam","Thebi Dam","Vadi (mangarwal) Dam","Vadia Dam","Vansiali Dam","Zar Dam","shell Dedumaal Dam"]
      },
      "Anand": {
        "DAMS":[]
      },
      "Aravalli": {
        "DAMS":[]
      },
      "Banas Kantha": {
        "DAMS": ["Dantiwada Dam","Diwaniya Dunger Dam","Hathidra Dam","Kapasiya Dam","Maneknath Dam","Pith Gajipur Dam","Sipu Dam","Solsandha Dam","Umri Dam","Vagdokyari Dam","Zanzarwa Dam"]
      },
      "Bharuch": {
        "DAMS": ["Baldeva Dam","Daria Dam","Dholi Dam","Pigut Dam","Vali Dam"]
      },
      "Bhavnagar": {
        "DAMS": ["Adpur Dam","Ambala Dam","Badi-Padva Dam","Bagad Dam","Bhaguda Dam","Bhandaria Dam","Bhimdad Dam","Chonda Dam","Chorwadala Dam","Ekalia Dam","Gaurishankar Lake Dam","Gautameshwar Lake Dam","Goma Dam","Hamipara Dam","Hanol Dam","Jesar Dam","Kalubhar Dam","Kaniyad Dam","Karmadiya Dam","Khari Dam","Kharo Dam","Khodiyar Dam","Kotia Dam","Lakhanka Dam","Limbali Dam","Malan Dam","Malapara Dam","Mamasi Dam","Mota-Chhaida Dam","Moti-Kundol Dam","Nagdhaniba Dam","Odarka Dam","Panchavada Dam","Pipardi Dam","Rajawal Dam","Ramdhani Dam","Ranghola Dam","Rojki Dam","Sanala Dam","Sandhida Dam","Shetrunji Dam","Thoralia Mi Dam","Toda Dam","Turkha Dam","Vadal Dam","Vaghvadarada Dam"]
      },
      "Dahod": {
        "DAMS": ["Aamli Chharchhoda Dam","Andhariparpata Dam","Dabahada Dam","Edalwada Dam","Jalai Dhuleta Dam","Kabutri Dam","Kali Dam","Kaliakota Dam","Kharedi Dam","Machhanala Dam","Muvalia Dam","Nandhelao Dam","Patadungri Dam","Rathvana Muvada Dam","Samariya Dam","Singor Dam","Surjumi Dam","Umaria Dam","Wanklaeswar-Bhey Dam"]
      },
      "Dang": {
        "DAMS":[]
      },
      "Gandhinagar": {
        "DAMS":[]
      },
      "Jamnagar": {
        "DAMS": ["Aji IV Dam","Balamdi Dam","Bamathia- I Dam","Bamathiya- II Dam","Dabasang Dam","Daiminisar Dam","Dangra Dam","Demi III Dam","Fulzar I Dam","Fulzar II Dam","Gadhada- Rasaji Dam","Gadhki Dam","Gebanshapir Dam","Ghee Dam","Hansthal Dam","Jagadi Dam","Jambuda - Bandhara Dam","Khadkhambhali Dam","Kotadia Dam","Ladoi Dam","Laloi Dam","Machhaliwad Dam","Muval Dam","Panch Devda Dam","Puna Dam","Rangmati Dam","Ruparel Dam","Sani Dam","Sapada Dam","Sasoi Dam","Shihan Dam","Sogthi Dam","Sonmati Dam","Uma Sagar Dam","Umarala Dam","Und I Dam","Und II(Gunatit Sarover) Dam","Vadisang Dam","Vartu II Dam","Vartu- I Dam","Veardi I Dam","Venu Dam","Veradi -II Dam","Vijarkhi Dam","Zakashiya Dam"]
      },
      "Junagadh": {
        "DAMS": ["Ambajal Dam","Ambakui Dam","Amirpur Dam","Baliyawad Dam","Dhrafad Dam","Farera Dam","Galath Dam","Hiran-I Dam","Hiran-II Dam","Jhanjhesari Dam","Khilawad M.I. Dam","Lachhadi Dam","Machhundri Dam","Madhuvanti Dam","Megal Tr Dam","Mota Gujariya Dam","Ozat -II Dam","Pichhavi Dam","Prempara Dam","Raval II Dam","Rupen Dam","Shingoda Dam","Uben Dam","Vrajmi Dam"]
      },
      "Kutch": {
        "DAMS": ["Adhochhani Dam"," Adhoi- I Dam","Angianawa Dam","Badi-Padva Dam","Baladhor Dam","Balapar Budadro Dam","Bambhanka Dam","Bandhara Dam","Bandi Dam","Baranda Dam","Baukha Dam","Bela Dam","Berachiya Dam","Bhadreshwar Dam","Bharapar Dam","Bharudia Dam","Bhuj Dam","Bhuki Dam","Burkhan Dam","Butta Dam","Chang Dam","Chavadka Dam","Darsadi Dam","Dedarani Dam","Dedhia Dam","Devalia Dam","Devsar Dam","Dhaneti Dam","Dhareshi Dam","Dhavada Dam","Dhunai Dam","Don Dam","Facharia Dam","Fakirwadi Dam","Faradi Dam","Fatehgadh Dam","Fulra Dam","Gajansagar Dam","Gajod Dam","Godhatad Dam","Goyala Dam","Gugariyana Dam","Halara Dam","Hatadi Dam","Jadawas Dam","Jaday Dam","Jadsa Dam","Jangadiya Dam","Jatavada-II Dam","Jetawada dam","Junachay Dam","Kadoli Dam","Kaila Dam","Kakarwa Dam","Kalaghogha Dam","Kalyanpar Dam","Kankawati Dam","Karuda-Dabhunda Dam","Kaswati Dam","Kharadia Dam","Kharod Dam","Kharua Dam","Khedoi Dam","Khengar Sagar Dam","Khodasar Dam","Khokhra Dam","Koriyani Dam","Kuapadhar Dam","Kunaria Dam","Ler Dam","Lilpar-II Dam","Lilpur-I Dam","Lodrani Dam","Loriya Dam","Lotiya Dam","Ludva Dam","Mamuara Dam","Manjal- Reladia Dam","Mankuwa Dam","Mapar Dam","Mathal Dam","Mauvana Dam","Mevasa Dam","Mitti Dam","Morchbana Dam","Mudhan Dam","Naniber Dam","Nara Dam","Nirona Dam","Phot Dam","Piyoni Dam","Rajada Dam","Rakhadi Dam","Rata Dam","Ratia Dam","Ratnal  Dam","Rudramata Dam","Samaghogho Dam","Sanandharo Dam","Sanava Dam","Sanosara Dam","Sargualla Dam","Shiney Dam","Shivlakha Dam","Surkhan Dam","Tappar Dam","Tara-Manjal Dam","Tharawada Dam","Umrapar Dam","Vamaka Dam","Vasatava Dam","Vavor Dam","Vayor Dam","Vengadi Dam","Vigodi Dam","Vijaysagar Dam","Virani Dam","Wandh Dam","Wandh-Mandvi Dam","Zalu Dam"]
      },
      "Kheda": {
        "DAMS": ["Debhari Dam","Jetholi Dam","Khata Dam","Koya Dam","Raniporda Dam","Savli Dam","Vagas Dam"]
      },
      "Mahesana": {
        "DAMS": ["Chimnabai-Lake Dam","Mukteshwar Dam","Thol Dam","Valam Dam"]
      },
      "Narmada": {
        "DAMS": ["Amalwant Dam","Chopadavav Dam","Daria Dam","Dhaniyawala Dam","Dholi Dam","Harwant Dam","Jamli Dam","Jogpura Dam","Kakdiamba Dam","Karjan Dam","Lafni Dam","Rami Dam","Sardar Sarovar Saddle Dam","Sardar Sarover Gujarat Dam","Singla Dam","Sukhi Dam","Targol Dam","Vali Dam","sardar sarover saddle dam"]
      },
      "Navsari": {
        "DAMS": ["Jhuj Dam","Kelia Dam"]
      },
      "Patan": {
        "DAMS": ["Khokhala Dam"]
      },
      "Panch Mahals": {
        "DAMS": ["Bhadar II Dam","Dalvada Dam","Demali Dam","Deo Dam","Dhamnod Dam","Dhamod Dam","Dhansarvav Dam","Dhariya Dam","Dhingalwada Dam","Dodfavanta Dam","Goyasundal Dam","Guneli Dam","Hadaf Dam","Jesola Kamalpur Dam","Kadana Dam","Kakari Mahudi Dam","Kaliakuva Dam","Kamalpurrnaka Dam","Karad Dam","Lafni Dam","Limdi Doli Dam","Moralnaka Dam","Moti Kharsoli Dam","Moyalapad Dam","Panam Dam","Samal Kuav Dam","Talvada Dam","Vadatalav Dam","Vakdi Ajnava Dam","Vardhari Dam","Zinzari Dam"]
      },
      "Porbandar": {
        "DAMS": ["Advana Dam","Fodaraness Dam","Kalindri Dam","Khambhala Dam","Sorthi Dam"]
      },
      "Rajkot": {
        "DAMS": ["Adhia Dam","Aji I Dam","Aji II Dam","Aji III Dam","Alan Sagar Dam","Ambaradi Dam","Anandapar Dam","Anandpar Dam","Anida Dam","Arrni Dam","Bangawadi Dam","Bedi Dam","Bhadar II Dam","Bhadar(S) Dam","Chhaparvadi-II Dam","Chhaparwadi-Lunivav Dam","Dadar Dam","Demi I Dam","Demi II Dam","Devedhari Dam","Dhari Dam","Domda M.I Dam","Faddanbeti Dam","Ghela Somnath/ Ghelo(S) Dam","Ghodadharoi Dam","Gokhalana Dam","Gondali Dam","Hathasani Dam","Ishwariya Dam","Jalida Dam","Karmal Dam","Karnuki Dam","Khodapipar Dam","Khorana Dam","Kothariya Dam","Kuvadwa Dam","Lalpari Dam","Machhu I Dam","Machhu II Dam","Machhu III Dam","Madhavipur Dam","Malgadh Dam","Mesaria Dam","Moj Dam","Motisar Dam","Nagarpiplalia Dam","Nyari II Dam","Nyari- I Dam","Patiyali Dam","Phophal I Dam","Rajavadala Dam","Raningpar Dam","Reshamadi Galol Dam","Revania Dam","Sartanpar Dam","Savdi Dam","Sod Vadar Dam","Thanagalol Dam","Thikariyala Dam","Vachappari Dam","Vadali Dam","Vadekhan Dam","Vanala Dam","Vanthali Dam","Vekari Dam","Venu II Dam","Veri Dam"]
      },
      "Sabar Kantha": {
        "DAMS": ["Bhanmer Dam","Bodi Dam","Borsi Dam","Guhai Dam","Harnav II Dam","Hathmati Dam","Karol(Baugh) Dam","Khata Dam","Kojan Dam","Kundol Dam","Lakhia Dam","Lank Dam","Limla Dam","Mazam Dam","Meshwa Saddle Dam","Meshwo Dam","Mota Kanthariya Dam","Motakotada Dam","Navabhetali Dam","Sabarmati Dam","Vagadi Dam","Vaidy Dam","Virpur Dam","Watrak Dam"]
      },
      "Surendranagar": {
        "DAMS": ["Bamanbore Dam","Bhogavo-II (Wadhowan) Dam","Brahmani-I Dam","Brahmani-II Dam","Chachka Dam","Chandrabhaga Dam","Falku Dam","Godechi Dam","Kankavati Dam","Limdi Bhogavo I (Thorali) Dam","Limdi-Bhogavo II Dam","Mevasa Dam","Moldi Dam","Morsal Dam","Mulbavla Dam","Nanamatra Dam","Nayka(W- Bhogavo I) Dam","Ranipat Dam","Saburi Dam","Sukhbhadar Dam","Trivni-Tranga Dam"]
      },
      "Surat": {
        "DAMS": ["Isar Dam","Kevadi Dam","Lakhigam Dam","Ver II Dam"]
      },
      "Tapi": {
        "DAMS": ["Baldeva Dam","Chopadavav Dam","Doswada Dam","Isar Dam","Ukai Dam"]
      },
      "Vadodara": {
        "DAMS": ["Ajwa Dam","Amalwant Dam","Dhaniyawala Dam","Dhanora Dam","Dundelav Dam","Harwant Dam","Jamli Dam","Jogpura Dam","Pratappura Dam","Rami Dam","Singla Dam","Sukhi Dam","Targol Dam","Wadhwan Jojwa Dam"]
      },
      "Valsad": {
        "DAMS": ["Kuntala Dam","Sidhumber Dam"]
      },
    }
  },"Haryana": {
    "DISTRICT": {
      "Panchkula": {
        "DAMS": ["kaushalya Dam"]
      },
    }
  },
  "Himachal Pradesh": {
    "DISTRICT": {
      "Bilaspur": {
        "DAMS": ["Bhakra Dam","Kol Dam"]
      },
      "Chamba": {
        "DAMS": ["Baira Siul Dam","Chamera I Dam","Chamera II Dam","Chamera III Dam"]
      },
      "Kangra": {
        "DAMS": ["Pong Dam"]
      },
      "Kinnaru": {
        "DAMS": ["Karchham-Wangtoo Dam","Nathpa Jhakri (Sjvnl) Dam"]
      },
      "Kullu": {
        "DAMS": ["Malana I Dam","Parbati - III Dam","Parbati II Dam"]
      },
      "Mandi": {
        "DAMS": ["Bassi Dam"]
      },
    }
  },
  "Jammu and Kashmir": {
    "DISTRICT": {
      "Ramban": {
        "DAMS":[]
      },
      "Kishtwar": {
        "DAMS":[]
      },
      "Bandipore": {
        "DAMS":[]
      },
      "Badgam": {
        "DAMS":[]
      },
      "Kathua": {
        "DAMS":[]
      },
      "Baramula": {
        "DAMS":[]
      },
      "Leh": {
        "DAMS":[]
      },
      "Reasi": {
        "DAMS":[]
      }
    }
  },
  "Jharkhand": {
    "DISTRICT": {
      "Bokaro": {
        "DAMS":[]
      },
      "Chatra": {
        "DAMS":[]
      },
      "Deoghar": {
        "DAMS":[]
      },
      "Dhanbad": {
        "DAMS":[]
      },
      "Dumka": {
        "DAMS":[]
      },
      "Garhwa": {
        "DAMS":[]
      },
      "Giridih": {
        "DAMS":[]
      },
      "Godda": {
        "DAMS":[]
      },
      "Gumla": {
        "DAMS":[]
      },
      "Hazaribagh": {
        "DAMS":[]
      },
      "Khunti": {
        "DAMS":[]
      },
      "Kodarma": {
        "DAMS":[]
      },
      "Lohardaga": {
        "DAMS":[]
      },
      "Pakur": {
        "DAMS":[]
      },
      "Palamu": {
        "DAMS":[]
      },
      "Purbi Singhbhum": {
        "DAMS":[]
      },
      "Pashchimi Singhbhum": {
        "DAMS":[]
      },
      "Ramgarh": {
        "DAMS":[]
      },
      "Ranchi": {
        "DAMS":[]
      },
      "Saraikela-kharsawan": {
        "DAMS":[]
      },
      "Simdega": {
        "DAMS":[]
      },
    }
  },
  "Karnataka": {
    "DISTRICT": {
      "Bagalkot": {
        "DAMS":[]
      },
      "Belgaum": {
        "DAMS":[]
      },
      "Bellary": {
        "DAMS":[]
      },
      "Bidar": {
        "DAMS":[]
      },
      "Bijapur": {
        "DAMS":[]
      },
      "Chamarajanagar": {
        "DAMS":[]
      },
       "Chikmagalur": {
        "DAMS":[]
      },
      "Chikkaballapura": {
        "DAMS":[]
      },
      "Chitradurga": {
        "DAMS":[]
      },
      "Davanagere": {
        "DAMS":[]
      },
      "Dharwad": {
        "DAMS":[]
      },
      "Gadag": {
        "DAMS":[]
      },
      "Gulbarga": {
        "DAMS":[]
      },
      "Hassan": {
        "DAMS":[]
      },
      "Haveri": {
        "DAMS":[]
      },
      "Kodagu": {
        "DAMS":[]
      },
      "Kolar": {
        "DAMS":[]
      },
      "Koppal": {
        "DAMS":[]
      },
      "Mandya": {
        "DAMS":[]
      },
      "Mysore": {
        "DAMS":[]
      },
      "Raichur": {
        "DAMS":[]
      },
      "Shimoga": {
        "DAMS":[]
      },
      "Tumkur": {
        "DAMS":[]
      },
      "Udupi": {
        "DAMS":[]
      },
      "Uttara Kannada": {
        "DAMS":[]
      },
      "Ramanagara": {
        "DAMS":[]
      },
      "Yadgir": {
        "DAMS":[]
      },
    }
  },

  "Kerala": {
    "DISTRICT": {
      "Idukki": {
        "DAMS":[]
      },
      "Kottayam": {
        "DAMS":[]
      },
      "Kozhikode": {
        "DAMS":[]
      },
      "Palakkad": {
        "DAMS":[]
      },
      "Pathanamthitta": {
        "DAMS":[]
      },
      "Thrissur": {
        "DAMS":[]
      },
      "Thiruvananthapuram": {
        "DAMS":[]
      },
      "Vandiperiyar": {
        "DAMS":[]
      },
      "Wayanad": {
        "DAMS":[]
      },
    }
  },
  "Madhya Pradesh": {
    "DISTRICT": {
      "Alirajpur": {
        "DAMS":[]
      },
      "Anuppur": {
        "DAMS":[]
      },
      "Ashoknagar": {
        "DAMS":[]
      },
      "Balaghat": {
        "DAMS":[]
      },
      "Barwani": {
        "DAMS":[]
      },
      "Betul": {
        "DAMS":[]
      },
      "Bhilai": {
        "DAMS":[]
      },
      "Bhind": {
        "DAMS":[]
      },
      "Bhopal": {
        "DAMS":[]
      },
      "Chhatarpur": {
        "DAMS":[]
      },
      "Chhindwara": {
        "DAMS":[]
      },
      "Damoh": {
        "DAMS":[]
      },
      "Dindori": {
        "DAMS":[]
      },
      "Dhar": {
        "DAMS":[]
      },
      "East Nimar": {
        "DAMS":[]
      },
      "Guna": {
        "DAMS":[]
      },
      "Gwalior": {
        "DAMS":[]
      },
      "Hoshangabad": {
        "DAMS":[]
      },
      "Indore": {
        "DAMS":[]
      },
      "Jabalpur": {
        "DAMS":[]
      },
      "Jhabua": {
        "DAMS":[]
      },
      "Katni": {
        "DAMS":[]
      },
      "Mandla": {
        "DAMS":[]
      },
      "Mandsaur": {
        "DAMS":[]
      },
      "Narsinghpur": {
        "DAMS":[]
      },
      "Panna": {
        "DAMS":[]
      },
      "Raisen": {
        "DAMS":[]
      },
      "Ratlam": {
        "DAMS":[]
      },
      "Rajgarh": {
        "DAMS":[]
      },
      "Rewa": {
        "DAMS":[]
      },
      "Sidhi": {
        "DAMS":[]
      },
      "Satna": {
        "DAMS":[]
      },
      "Sehore": {
        "DAMS":[]
      },
      "Seoni": {
        "DAMS":[]
      },
      "Shahdol": {
        "DAMS":[]
      },
      "Shivpuri": {
        "DAMS":[]
      },
      "Singrauli": {
        "DAMS":[]
      },
      "Sheopur": {
        "DAMS":[]
      },
      "Tikamgarh": {
        "DAMS":[]
      },
      "Umaria": {
        "DAMS":[]
      },
      "Ujjain": {
        "DAMS":[]
      },
      "Vidisha": {
        "DAMS":[]
      },
      "West Nimar": {
        "DAMS":[]
      },
    }
  },
  "Maharashtra": {
    "DISTRICT": {
      "Ahmadnagar": {
        "DAMS":[]
      },
      "Bhandara": {
        "DAMS":[]
      },
      "Bid": {
        "DAMS":[]
      },
      "Buldana": {
        "DAMS":[]
      },
      "Chandrapur": {
        "DAMS":[]
      },
      "Dhule": {
        "DAMS":[]
      },
      "Gadchiroli": {
        "DAMS":[]
      },
      "Gondiya": {
        "DAMS":[]
      },
      "Hingoli": {
        "DAMS":[]
      },
      "Jalna": {
        "DAMS":[]
      },
      "Jalgaon": {
        "DAMS":[]
      },
      "Kolhapur": {
        "DAMS":[]
      },
      "Latur": {
        "DAMS":[]
      },
      "Mumbai (Suburban)": {
        "DAMS":[]
      },
      "Nanded": {
        "DAMS":[]
      },
      "Nandurbar": {
        "DAMS":[]
      },
      "Nashik": {
        "DAMS":[]
      },
      "Nagpur": {
        "DAMS":[]
      },
      "Osmanabad": {
        "DAMS":[]
      },
      "Parbhani": {
        "DAMS":[]
      },
      "Pune": {
        "DAMS":[]
      },
      "Ratnagiri": {
        "DAMS":[]
      },
      "Raigarh": {
        "DAMS":[]
      },
      "Sangli": {
        "DAMS":[]
      },
      "Satara": {
        "DAMS":[]
      },
      "Solapur": {
        "DAMS":[]
      },
      "Sindhudurg": {
        "DAMS":[]
      },
      "Thane": {
        "DAMS":[]
      },
      "Wardha": {
        "DAMS":[]
      },
      "Washim": {
        "DAMS":[]
      },
      "Yavatmal": {
        "DAMS":[]
      },
    }
  },
  "Manipur": {
    "DISTRICT": {
      "Churachandpur": {
        "DAMS":[]
      },
      "Senapati": {
        "DAMS":[]
      },
      "Tamenglong": {
        "DAMS":[]
      },
    }
  },
  "Meghalaya": {
    "DISTRICT": {
      "East Khasi Hills": {
        "DAMS":[]
      },
      "Jaintia Hills": {
        "DAMS":[]
      },
      "Ri Bhoi": {
        "DAMS":[]
      },
      "West Khasi Hills": {
        "DAMS":[]
      },
    }
  },
  "Mizoram": {
    "DISTRICT": []
  },
  "Nagaland": {
    "DISTRICT": {
      "Dimapur": {
        "DAMS":[]
      },
      "Kiphire": {
        "DAMS":[]
      },
      "Kohima": {
        "DAMS":[]
      },
      "Longleng": {
        "DAMS":[]
      },
      "Mokokchung": {
        "DAMS":[]
      },
      "Mon": {
        "DAMS":[]
      },
      "Peren": {
        "DAMS":[]
      },
      "Phek": {
        "DAMS":[]
      },
      "Tuensang": {
        "DAMS":[]
      },
      "Wokha": {
        "DAMS":[]
      },
      "Zunheboto": {
        "DAMS":[]
      },
    }
  },
  "Orissa": {
    "DISTRICT": {
      "Anugul": {
        "DAMS":[]
      },
      "Bargarh": {
        "DAMS":[]
      },
      "Balangir": {
        "DAMS":[]
      },
      "Baudh": {
        "DAMS":[]
      },
      "Baleshwar": {
        "DAMS":[]
      },
      "Cuttack": {
        "DAMS":[]
      },
      "Kandhamal": {
        "DAMS":[]
      },
      "Debagarh": {
        "DAMS":[]
      },
      "Dhenkanal": {
        "DAMS":[]
      },
      "Ganjam": {
        "DAMS":[]
      },
      "Gajapati": {
        "DAMS":[]
      },
      "Jajapur": {
        "DAMS":[]
      },
      "Jeypore": {
        "DAMS":[]
      },
      "Jharsuguda": {
        "DAMS":[]
      },
      "Koraput": {
        "DAMS":[]
      },
      "Khordha": {
        "DAMS":[]
      },
      "Kalahandi": {
        "DAMS":[]
      },
      "Kendujhar": {
        "DAMS":[]
      },
      "Malkangiri": {
        "DAMS":[]
      },
      "Mayurbhanj": {
        "DAMS":[]
      },
      "Nabarangapur": {
        "DAMS":[]
      },
      "Nayagarh": {
        "DAMS":[]
      },
      "Nuapada": {
        "DAMS":[]
      },
      "Paradip Garh": {
        "DAMS":[]
      },
      "Puri": {
        "DAMS":[]
      },
      "Rayagada": {
        "DAMS":[]
      },
      "Rourkela": {
        "DAMS":[]
      },
      "Sambalpur": {
        "DAMS":[]
      },
      "Sundargarh": {
        "DAMS":[]
      },
      "Subarnapur": {
        "DAMS":[]
      },
    }
  },
  "Puducherry": {
    "DISTRICT": []
  },
  "Punjab": {
    "DISTRICT": {
      "Gurdaspur": {
        "DAMS":[]
      },
      "Hoshiarpur": {
        "DAMS":[]
      },
      "Kathua": {
        "DAMS":[]
      },
      "Sahibzada Ajit Singh Nagar": {
        "DAMS":[]
      },
    }
  },
   "Rajasthan": {
    "DISTRICT": {
      "Alwar": {
        "DAMS":[]
      },
      "Ajmer": {
        "DAMS":[]
      },
      "Bundi": {
        "DAMS":[]
      },
      "Baran": {
        "DAMS":[]
      },
      "Basni": {
        "DAMS":[]
      },
      "Banswara": {
        "DAMS":[]
      },
      "Bharatpur": {
        "DAMS":[]
      },
      "Bhilwara": {
        "DAMS": ["Anwasa Dam","Arwar Dam","Atawara Dam","Baradpura/ Baradapura Dam",
        "Chandrabhaga Dam","Deoriya Dam","Domti Kokra Dam","Govta Dam","Jetpura Dam",
        "Jhadol Dam","Kanyakheri Dam","Khari Dam","Kothari Stage I Dam",
        "Ladki/ Larki Dam","Mandal Dam","Meja Dam","Motipura Dam","Nagdi Dam",
        "Nahar Sagar Dam","Navratan Sagar Dam","Pachanpura Dam","Patan (Deosagar) Dam",
        "Patiyal Dam","Sareri/ Sareru Dam","Shakargarh Dam","Shiv-Sagar Dam",
        "Sushil Sagar/ Soshila Sagar Dam","Titora Dam","Umed/Umed/ Umaid Sagar (Bhilwara) Dam"]
      },
      "Bhiwadi": {
        "DAMS":[]
      },
      "Bikaner": {
        "DAMS":[]
      },
      "Bongaigaon": {
        "DAMS":[]
      },
      "Boranada, Jodhpur": {
        "DAMS":[]
      },
      "Chittaurgarh": {
        "DAMS":[]
      },
      "Dausa": {
        "DAMS":[]
      },
      "Dungarpur": {
        "DAMS":[]
      },
      "Dhaulpur": {
        "DAMS":[]
      },
      "Fazilka": {
        "DAMS":[]
      },
      "Ganganagar": {
        "DAMS":[]
      },
      "Jhalawa": {
        "DAMS":[]
      },
      "Jaipur": {
        "DAMS":[]
      },
      
                                       "Jalor": {
        "DAMS":[]
      },
      "Jodhpur": {
        "DAMS":[]
      },
      "Jodhpur-Bhagat Ki Kothi": {
        "DAMS":[]
      },
      "Jodhpur-Thar": {
        "DAMS":[]
      },
      "Karauli": {
        "DAMS":[]
      },
      "Kardhan": {
        "DAMS":[]
      },
      "Kota": {
        "DAMS":[]
      },
      "Munabao Rail Station": {
        "DAMS":[]
      },
      "Nagaur": {
        "DAMS":[]
      },
      "Pali": {
        "DAMS":[]
      },
      "Pratapgarh": {
        "DAMS":[]
      },
      "Rajsamand": {
        "DAMS":[]
      },
      "Sawai Madhopur": {
        "DAMS":[]
      },
      "Sirohi": {
        "DAMS":[]
      },
      "Shahdol": {
        "DAMS":[]
      },
      "Shimoga": {
        "DAMS":[]
      },
      "Sikar": {
        "DAMS":[]
      },
      "Tonk": {
        "DAMS":[]
      },
      "Udaipur": {
        "DAMS":[]
      },
    }
  },
  "Sikkim": {
    "DISTRICT": {
      "Chamurci": {
        "DAMS":[]
      },
      "East": {
        "DAMS":[]
      },
      "Gangtok": {
        "DAMS":[]
      },
      "North": {
        "DAMS":[]
      },
      "West": {
        "DAMS":[]
      },
    }
  },
  "Tamil Nadu": {
    "DISTRICT": {
      "Ariyalur": {
        "DAMS":[]
      },
      "Chittor": {
        "DAMS":[]
      },
      "Chennai": {
        "DAMS":[]
      },
      "Coimbatore": {
        "DAMS":[]
      },
      "Cuddalore": {
        "DAMS":[]
      },
      "Dharmapuri": {
        "DAMS":[]
      },
      "Dindigul": {
        "DAMS":[]
      },
      "Erode": {
        "DAMS":[]
      },
      "idukki": {
        "DAMS":[]
      },
      "Kancheepuram": {
        "DAMS":[]
      },
      "Kozhikode": {
        "DAMS":[]
      },
      "Kanniyakumari": {
        "DAMS":[]
      },
      "Karur": {
        "DAMS":[]
      },
      "Krishnagiri": {
        "DAMS":[]
      },
      "Madurai": {
        "DAMS":[]
      },
      "Mandapam": {
        "DAMS":[]
      },
      "Nagapattinam": {
        "DAMS":[]
      },
      "Nilgiris": {
        "DAMS":[]
      },
      "Namakkal": {
        "DAMS":[]
      },
      "Perambalur": {
        "DAMS":[]
      },
      "Pudukkottai": {
        "DAMS":[]
      },
      "Ramanathapuram": {
        "DAMS":[]
      },
      "Salem": {
        "DAMS":[]
      },
      "Sivaganga": {
        "DAMS":[]
      },
      "Thanjavur": {
        "DAMS":[]
      },
      "Thiruvallur": {
        "DAMS":[]
      },
      "Tirupur": {
        "DAMS":[]
      },
       "Tiruchirapalli": {
        "DAMS":[]
      },
      "Theni": {
        "DAMS":[]
      },
      "Tirunelveli": {
        "DAMS":[]
      },
      "Thanjavur": {
        "DAMS":[]
      },
      "Thoothukudi": {
        "DAMS":[]
      },
      "Thiruvallur": {
        "DAMS":[]
      },
      "Tiruvannamalai": {
        "DAMS":[]
      },
      "Vellore": {
        "DAMS":[]
      },
      "Viluppuram": {
        "DAMS":[]
      },
      "Virudhunagar": {
        "DAMS":[]
      },
    }
  },
  "Telangana": {
    "DISTRICT": {
      "Adilabad": {
        "DAMS":[]
      },
      "Karimnagar": {
        "DAMS":[]
      },
      "Khammam": {
        "DAMS":[]
      },
      "Mahbubnagar": {
        "DAMS":[]
      },
      "Nalgonda": {
        "DAMS":[]
      },
      "Nizamabad": {
        "DAMS":[]
      },
    }
  },
  "Tripura": {
    "DISTRICT": {
      "Agartala": {
        "DAMS":[]
      },
      "Dhalaighat": {
        "DAMS":[]
      },
      "Kailashahar": {
        "DAMS":[]
      },
      "Kamalpur": {
        "DAMS":[]
      },
      "Kanchanpur": {
        "DAMS":[]
      },
      "Kel Sahar Subdivision": {
        "DAMS":[]
      },
      "Khowai": {
        "DAMS":[]
      },
      "Khowaighat": {
        "DAMS":[]
      },
      "South tripura": {
        "DAMS":[]
      },
      "Mahurighat": {
        "DAMS":[]
      },
      "Old Raghna Bazar": {
        "DAMS":[]
      },
      "Sabroom": {
        "DAMS":[]
      },
      "Srimantapur": {
        "DAMS":[]
      },
    }
  },
  "Uttar Pradesh": {
    "DISTRICT": {
      "Allahabad": {
        "DAMS":[]
      },
      "Balrampur": {
        "DAMS":[]
      },
      "Bijnor": {
        "DAMS":[]
      },
      "Chitrakoot": {
        "DAMS":[]
      },
      "Chandauli": {
        "DAMS":[]
      },
      "Ghazipur": {
        "DAMS":[]
      },
      "Garhwal": {
        "DAMS":[]
      },
      "Hamirpur": {
        "DAMS":[]
      },
      "Jhansi": {
        "DAMS":[]
      },
      "Lalitpur": {
        "DAMS":[]
      },
      "Mahoba": {
        "DAMS":[]
      },
      "Mirzapur": {
        "DAMS":[]
      },
      "Pilibhit": {
        "DAMS":[]
      },
      "Shrawasti": {
        "DAMS":[]
      },
      "Sonbhadra": {
        "DAMS":[]
      },
    }
  },
  "Uttarakhand": {
    "DISTRICT": {
      "Almora": {
        "DAMS":[]
      },
      "Badrinath": {
        "DAMS":[]
      },
      "Bangla": {
        "DAMS":[]
      },
      "Barkot": {
        "DAMS":[]
      },
      "Bazpur": {
        "DAMS":[]
      },
      "Chamoli": {
        "DAMS":[]
      },
      "Chopra": {
        "DAMS":[]
      },
      "Dehradun": {
        "DAMS":[]
      },
      "Dwarahat": {
        "DAMS":[]
      },
      "Garhwal": {
        "DAMS":[]
      },
      "Haldwani": {
        "DAMS":[]
      },
      "Hardwar": {
        "DAMS":[]
      },
      "Haridwar": {
        "DAMS":[]
      },
      "Jamal": {
        "DAMS":[]
      },
      "Jwalapur": {
        "DAMS":[]
      },
      "Kalsi": {
        "DAMS":[]
      },
      "Kashipur": {
        "DAMS":[]
      },
      "Mall": {
        "DAMS":[]
      },
       "Mussoorie": {
        "DAMS":[]
      },
      "Nahar": {
        "DAMS":[]
      },
      "Nainital": {
        "DAMS":[]
      },
      "Pantnagar": {
        "DAMS":[]
      },
      "Pauri": {
        "DAMS":[]
      },
      "Pithoragarh": {
        "DAMS":[]
      },
      "Rameshwar": {
        "DAMS":[]
      },
      "Rishikesh": {
        "DAMS":[]
      },
      "Rohni": {
        "DAMS":[]
      },
      "Roorkee": {
        "DAMS":[]
      },
      "Sama": {
        "DAMS":[]
      },
      "Saur": {
        "DAMS":[]
      },
      "Tehri Garhwal": {
        "DAMS":[]
      },
      "Udham Singh Nagar": {
        "DAMS":[]
      },
      "Uttarkashi": {
        "DAMS":[]
      },
    }
  },
  "West Bengal": {
    "DISTRICT": {
      "Alipurduar": {
        "DAMS":[]
      },
      "Bankura": {
        "DAMS":[]
      },
      "Barddhaman": {
        "DAMS":[]
      },
      "Birbhum": {
        "DAMS":[]
      },
      "Cooch Behar": {
        "DAMS":[]
      },
      "Bankura": {
        "DAMS":[]
      },
      "Dakshin Dinajpur": {
        "DAMS":[]
      },
      "Darjeeling": {
        "DAMS":[]
      },
      "Hooghly": {
        "DAMS":[]
      },
      "Howrah": {
        "DAMS":[]
      },
       "Jalpaiguri": {
        "DAMS":[]
      },
      "Kolkata": {
        "DAMS":[]
      },
      "Maldah": {
        "DAMS":[]
      },
      "Murshidabad": {
        "DAMS":[]
      },
      "Nadia": {
        "DAMS":[]
      },
      "North 24 Parganas": {
        "DAMS":[]
      },
      "Paschim Medinipur": {
        "DAMS":[]
      },
      "Purba Medinipur": {
        "DAMS":[]
      },
      "Puruliya": {
        "DAMS":[]
      },
      "South 24 Parganas": {
        "DAMS":[]
      },
      "Uttar Dinajpur": {
        "DAMS":[]
      },
    }
  },
};