import React, { Component } from 'react';
import AddIcon from 'material-ui-icons/Add';
import Button from 'material-ui/Button';
import ReactTable from 'react-table';
import Modal from "react-responsive-modal";
import { connect } from 'react-redux';

import DamContainer from 'Component/dam-container/DamContainer';
import DamSelector from 'Component/dam-selector/DamSelector';
import AuditForm from 'Component/audit-form/AuditForm';

import { saveAudit, collectAudits } from 'Action/Audit';

import { getStateList, getDistrictList, getDamList } from 'Util/CountryDataUtil';

import './Audit.css';
import "react-table/react-table.css";


class Audit extends Component {

  constructor(props) {
    super(props)

    this.state = {
      newAuditModal: false,
      state: '',
      districts: [],
      district: '',
      dams: [],
      dam: '',
      damDetail: null,
      audit: null,
      audits: [],
      auditFormType: 'ADD'
    }
  }

  componentWillReceiveProps(nextProps) {
    const { type, audits } = nextProps.audit
    if(type == 'ADD_AUDIT_SUCCESS') {
      alert('Complaint added to DB')
      this.setState({newAuditModal: false})
      this.refreshAudits()
    }
    if(type == 'COLLECT_AUDIT_SUCCESS') {
      this.setState({audits})
    }
  }

  componentWillMount() {
    this.refreshAudits()
  }

  refreshAudits() {
    const { collectAudits, user } = this.props
    collectAudits(user)
  }

  createAudit = (audit) => {
    const { saveAudit, user } = this.props
    const { dam, state, district } = this.state
    audit.user = user
    audit.dam = dam
    audit.state = state
    audit.district = district
    saveAudit(audit)
  }

  handleFabModal = () => {
    this.setState({newAuditModal: !this.state.newAuditModal, auditFormType: 'ADD'})
  }

  handleViewAuditBtnClick = (audit) => {
    this.setState({
      audit, 
      dam: audit.dam, state: audit.state, district: audit.district, 
      auditFormType: 'VIEW', newAuditModal: true
    })
    setTimeout(()=>{
      // this.updateDamSelector()
      this.getDistrictList(audit.state)
      this.getDamList(audit.district)
      // this.handleViewAuditBtnClick()
    }, 1000)
  }

  getDistrictList(stateName) {
    const districts = getDistrictList(stateName)
    this.setState({districts})
  }

  getDamList(districtName, stateOpt) {
    const { state } = this.state
    const dams = getDamList(districtName, state)
    this.setState({dams})
  }

  renderModal = () => {
    const { 
      newAuditModal, state, districts, district, dams, dam,
      audit, auditFormType
    } = this.state
    const { user: { userType } } = this.props
    // const userType = 'AUDITOR_3'
    return (
      <Modal
        open={newAuditModal}
        onClose={this.handleFabModal}
        little
        classNames={{
          overlay: 'addAuditOverlay',
          modal: "addAuditModal",
          transitionEnter: 'transition-enter',
          transitionEnterActive: 'transition-enter-active',
          transitionExit: 'transition-exit-active',
          transitionExitActive: 'transition-exit-active',
        }}
        animationDuration={1000}
      >
        <div className='addAuditContainer'>
          <DamSelector 
            viewType={auditFormType}
            state={state}
            district={district}
            districts={districts}
            dam={dam}
            dams={dams}
            onChangeState={(state, districts)=>this.setState({state, districts})}
            onChangeDistrict={(district, dams)=> this.setState({district, dams})}
            onChangeDam={(dam, damDetail)=>this.setState({dam, damDetail})}
            onSubmit={()=>console.log('TODO')}
          />
          <AuditForm 
            audit={audit}
            viewType={auditFormType}
            userType={userType}
            handleAuditSubmit={this.createAudit.bind(this)} 
            handleAuditCancel={this.handleFabModal.bind(this)} />
        </div>
      </Modal>
    )
  }

  render() {
    const { audits } = this.state

    const tableColumn = [{
      Header: 'ID',
      accessor: '_id'
    }, {
      Header: 'Dam name',
      accessor: 'description'
    }, {
      Header: 'District',
      accessor: 'district'
    }, {
      Header: 'State',
      accessor: 'state', // Custom value accessors!
      Cell: props => <span>{props.value != null ? props.value : '-'}</span> // Custom cell components!
    }, {
      Header: 'Audited Date',
      accessor: 'auditedDate',
      Cell: props => <span>{props.value != null ? props.value : '-'}</span> // Custom cell components!
    }, {
      Header: 'Audited By',
      accessor: 'user',
      Cell: props => <span>{props.value != null && props.value.name ? props.value.name : '-'}</span> // Custom cell components!
    }, {
      Header: 'Action',
      Cell: ({ row, original }) => <Button variant="raised" onClick={(e) => {
        this.handleViewAuditBtnClick(original)}}>View</Button>
    }]

    return (
      <DamContainer className="auditContainer">
        <ReactTable
          data={audits}
          columns={tableColumn}
          defaultPageSize={15}
          className="-striped -highlight"
        />
        <Button variant="fab" style={styles.fabIcon} color={'secondary'} onClick={this.handleFabModal}>
          <AddIcon />
        </Button>
        {this.renderModal()}
      </DamContainer>
    )
  }
}

const styles = {
  fabIcon: {
    position: 'absolute',
    bottom: 50,
    right: 20
  }
}

const mapStateToProps = state => {
  return {
    user: state.User.user,
    audit: state.Audit
  }
}

const mapDispatchToProps = dispatch => {
  return {
    saveAudit: audit => {
      dispatch(saveAudit(audit))
    },
    collectAudits: (user) => {
      dispatch(collectAudits(user))
    }
  }
}

const AuditWrapper = connect(
  mapStateToProps,
  mapDispatchToProps
)(Audit)

export default AuditWrapper