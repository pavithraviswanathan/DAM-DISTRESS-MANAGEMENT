import React, { Component } from 'react'

export default class Error404 extends Component {
  render() {
    return (
      <div>
        Error404
      </div>
    )
  }
}
