import React, { Component } from 'react';
import AddIcon from 'material-ui-icons/Add';
import Button from 'material-ui/Button';
import Modal from "react-responsive-modal";
import Input, { InputLabel } from 'material-ui/Input';
import TextField from 'material-ui/TextField';
import { MenuItem } from 'material-ui/Menu';
import { FormControl, FormHelperText, 
  FormGroup, FormControlLabel } from 'material-ui/Form';
import Select from 'material-ui/Select';
import { connect } from 'react-redux';
import ReactTable from 'react-table';

import { saveUser, collectPwdUsers } from 'Action/User';
import DamContainer from 'Component/dam-container/DamContainer';
import { getStateList, getDistrictList, getDamList } from 'Util/CountryDataUtil';

import './People.css';

const STATEs = getStateList();

const tableColumn = [{
  Header: 'ID',
  accessor: '_id'
}, {
  Header: 'Email ID',
  accessor: 'emailId'
},{
  Header: 'State',
  accessor: 'state'
}, {
  Header: 'District',
  accessor: 'district', 
}, {
  Header: 'Mobile',
  accessor: 'mobile', 
}]

class People extends Component {
  constructor(props) {
    super(props)

    this.state = {
      modalFlag: false,
      state: '',
      district: '',
      register: {
        emailId: '',
        password: '',
        confirmPassword: '',
        mobile: '',
        error: '',
        userType: 'PWD',
        activated: false
      },
      pwdUsers: []
    }
  }

  componentWillReceiveProps(nextProps) {
    const { user: { type, pwdUsers } } = nextProps
    if(type == 'USER_AUTHENTICATION_SUCCESS') {
      alert('PWD officer is included into DB')
      this.refreshTable()
      this.setState({modalFlag: false})
    } else if(type=='PWD_USER_COLLECTION_SUCCESS') {
      this.setState({pwdUsers})
    }
  }

  componentWillMount() {
    this.refreshTable()
  }

  refreshTable() {
    this.props.collectPwdUsers()
  }

  handleState = (event) => {
    const districts = getDistrictList(event.target.value)
    this.setState({districts, state: event.target.value})
  }

  handleDistrict = (event) => {
    this.setState({district: event.target.value})
  }

  handleModal = () => {
    this.setState({modalFlag: !this.state.modalFlag})
  }

  handleChange = (name, type) => event => {
    const stateObje = this.state[type]
    stateObje[name] = event.target.value
    this.setState({
      [type]: stateObje,
    });
  };

  handleRegister() {
    const { state, district, register, register: { 
      emailId, password, confirmPassword, mobile, error }} = this.state
    if(state== '' || district == '') {
      register['error'] = 'STATE and DISTRICT are required fields'
      this.setState({register})
      return;
    }
    if(password !== confirmPassword) {
      register['error'] = 'PASSWORD MISMATCH'
      this.setState({register})
      return;
    }
    let newUser = Object.assign({}, this.state.register)
    newUser.state = state
    newUser.district = district
    delete newUser.confirmPassword;
    delete newUser.error;
    this.props.saveUser(newUser)
    console.log('uncomment save user to save in mongodb')
  }

  renderRegistrationContainer() {
    const { register } = this.state

    return (
      <React.Fragment>
        <TextField
          id="registerEmailId"
          label="Email ID"
          value={register['emailId']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('emailId', 'register')}
        />
        <TextField
          id="registerPassword"
          label="Password"
          type="password"
          value={register['password']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('password', 'register')}
        />
        <TextField
          id="registerConfirmPassword"
          label="Confirm Password"
          type="password"
          value={register['confirmPassword']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('confirmPassword', 'register')}
        />
        <TextField
          id="registerMobile"
          label="Mobile"
          value={register['mobile']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('mobile', 'register')}
        />
        <div className='btnWrapper'>
          <Button variant="raised" color="primary" style={{margin: 10}}
            onClick={this.handleRegister.bind(this)}>
              Register
          </Button>
          <Button variant="raised" color="secondary" style={{margin: 10}}
            onClick={this.handleModal.bind(this)}>
              Cancel
          </Button>
        </div>
      </React.Fragment>
    )
  }

  renderModal() {
    const { modalFlag, state, districts, district, register: { error } } = this.state
    
    return (
      <Modal
          open={modalFlag}
          onClose={this.handleModal}
          little
          classNames={{
            transitionEnter: 'transition-enter',
            transitionEnterActive: 'transition-enter-active',
            transitionExit: 'transition-exit-active',
            transitionExitActive: 'transition-exit-active',
          }}
          animationDuration={1000}
        >
          <div className='addNewPeopleContainer'>
          <h2>Create a PWD account</h2>
          {
            error != '' && <span className='error'>{error}</span>
          }
          <div className='selectorGroup'>
            <FormControl>
              <InputLabel htmlFor="stateSelector">State</InputLabel>
              <Select
                style={{width: 200}}
                value={state}
                onChange={this.handleState}
                inputProps={{
                  name: 'state',
                  id: 'stateSelector',
                }}
              >
                {STATEs && STATEs.map((stateName, index) => 
                    <MenuItem value={stateName} key={index}>
                      {stateName}
                    </MenuItem>
                )}
              </Select>
              <FormHelperText>Select a state</FormHelperText>
            </FormControl>
            <FormControl>
              <InputLabel htmlFor="districtSelector">District</InputLabel>
              <Select
                style={{width: 200}}
                value={district}
                onChange={this.handleDistrict}
                inputProps={{
                  name: 'district',
                  id: 'districtSelector',
                }}
              >
                {districts && districts.map((districtName, index) => 
                  <MenuItem value={districtName} key={index}>
                    {districtName}
                  </MenuItem>
                )}
              </Select>
              <FormHelperText>Select a district</FormHelperText>
            </FormControl>
          </div>
          <div className='pwdRegistrationContainer'>
              {this.renderRegistrationContainer()}
          </div>
          </div>
        </Modal>
    )
  }

  render() {
    const { pwdUsers } = this.state
    return (
      <DamContainer>
        {pwdUsers && <ReactTable
          data={pwdUsers}
          columns={tableColumn}
          defaultPageSize={10}
          className="-striped -highlight"
        />}
        {this.renderModal()}
        <Button 
          onClick={this.handleModal}
          variant="fab" style={styles.fabIcon} color={'secondary'}>
          <AddIcon />
        </Button>
      </DamContainer>
    )
  }
}

const styles = {
  fabIcon: {
    position: 'absolute',
    bottom: 50,
    right: 20
  }
}

const mapStateToProps = state => {
  return {
    user: state.User
  }
}

const mapDispatchToProps = dispatch => {
  return {
    saveUser: user => {
      dispatch(saveUser(user))
    },
    collectPwdUsers: () => {
      dispatch(collectPwdUsers())
    }
  }
}

const PeopleWrapper = connect(
  mapStateToProps,
  mapDispatchToProps
)(People)

export default PeopleWrapper