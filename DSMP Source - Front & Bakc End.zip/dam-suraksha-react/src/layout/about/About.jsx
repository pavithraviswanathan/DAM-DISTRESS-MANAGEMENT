import React, { Component } from 'react';
import { ReactMic } from 'react-mic';
import Button from 'material-ui/Button';
import { withRouter } from 'react-router-dom';

import './About.css';

let context = new AudioContext();
let source;
let chunks = [];

class About extends Component {

  constructor(props) {
    super(props)

    this.state = {
      recordState: false
    }
  }

  toggleRecordState() {
    this.setState({recordState: !this.state.recordState})
  }

  onRecord(data) {

  }

  onRecordingStopped(recordedBlob) {
    // source.stopRecording()
    // context.suspend();
    // console.log('stopped')
    // const blob = new Blob(chunks, { 'type' : mediaOptions.mimeType });
    // chunks = [];

    // const blobObject =  {
    //   blob      : blob,
    //   startTime : startTime,
    //   stopTime  : Date.now(),
    //   options   : mediaOptions,
    //   blobURL   : window.URL.createObjectURL(blob)
    // }
    console.log('recordedBlob is: ', recordedBlob);
    this.audioControl.src = recordedBlob.blobURL;
  }

  navigateToWelcome() {
    this.props.history.push('/')
  }

  render() {
    const { recordState } = this.state

    return (
      <div className="w3-content" id="about">
        <header className={'welcomeHeader'}>
          <div className={'headerTitle'}>{'Dam Surveillance & Monitoring Project'}</div>
          <Button variant="raised" color="primary" 
          onClick={this.navigateToWelcome.bind(this)}>
            Lets login!
        </Button>
        </header>
        <h3 className="w3-center">ABOUT US</h3>
        <p>Dam Surveillance & Reporting Project has been designed for both individuals and organisations at State and Central level.At present,there are about 5,000 dams in India and many dams are in distress condition.So it is difficult to find the distress and register manual complaints of these problems to take corresponding actions.Our Dam Surveillance & Reporting Project provides digitalized solution to the curent problems.The complaint can be registered either by the public or by the auditor of the dam.Some public users may be illiterate,so they can register their complaints in the form of voice note.Finally these complaints will be notified to the state and central government based on the categorization of the defects.</p>
        <div className="w3-row">
          <div className="w3-col m6 w3-center w3-padding-large">
            <p><b><i className="w3-margin-right"></i>Distress Conditions</b></p><br />
            <img src={require("Asset/image/image.jpg")} className="" alt="distress dams" width="300" height="300" />
            <p><b>“Quality is never an accident; it is always the result of high intention, sincere effort, intelligent direction and skillful execution; it represent the wise choice of many alternatives!” –William A Foster</b></p>
          </div>
          <div className="w3-col m6 w3-hide-small w3-padding-large">
            <p>Presently, India ranks third globally with 5254 large dams in operation and about 447 are under construction. In addition, there are several thousand smaller dams. These dams are vital for ensuring the water security of the Country and these also constitute a major responsibility in terms of asset management and safety. 
            With approximately 5254 dams in India, they are undoubtedly an integral part of our nation’s infrastructure. These dams serve numerous purposes which include, but are not limited to: flood control, water and power to cities, irrigation for agriculture, fire protection and recreation. Avoiding catastrophic dam failures is imperative to protect and sustain these benefits. Some dams retain thousands of acre-feet of water, rise high above ground, and span great lengths.  Dam failures can release uncontrollable water flows which can result in severe consequences to downstream areas. When a dam breach occurs, the flooding can cause enormous economic losses, residential and agricultural damages, and even more importantly, loss of life.  
            </p>
            <p>
          Dam infrastructure has become an increasingly larger crisis in India.  Many  dams pose a serious threat to people and property because of factors that include: deficiencies and deterioration from aging; older dams constructed prior to improved modern construction standards; and  an increase in the number of high hazard level dams. A high hazard dam is  briefly defined as dam whose failure would result in the probable loss of life along with large economic consequences downstream.  
          The overall goal of this tool was to strengthen the safety of dam infrastructure in India and decrease the number of avoidable dam failures in India. To accomplish this task this tool will provide inspection form and evaluation to determine the safety of dams and allied structures. Finally, this tool send notifications to state water resource departments as well as Central Water Commission and it also generate reports based on priority, state, facility etc.
          <br/>
        </p>
          </div>
          
        </div>
        
      </div>


      // <div>
      //   {/* <input type="file" accept="audio/*" capture /> */}
      //   <ReactMic
      //     record={recordState}     
      //     className={'hideVisualizer'}    
      //     onData={this.onRecord.bind(this)}       
      //     onStop={this.onRecordingStopped.bind(this)}        
      //     strokeColor={'red'}     
      //     backgroundColor={'blue'} 
      //   />
      //   <div style={{color: 'red'}} onClick={this.toggleRecordState.bind(this)}>
      //     {recordState ? 'STOP' : 'RECORD'}
      //   </div>
      //   <audio ref={(ref)=>this.audioControl = ref} controls />
      // </div>

    )
  }
}

export default withRouter(About)