import React, { Component } from 'react';
import Button from 'material-ui/Button';
import List, { ListItem, ListItemSecondaryAction, ListItemText } from 'material-ui/List';
import { withRouter } from 'react-router-dom';

import Tabs, { TabPane } from 'rc-tabs';
import TabContent from 'rc-tabs/lib/TabContent';
import ScrollableInkTabBar from 'rc-tabs/lib/ScrollableInkTabBar';

import './Contact.css';

const DAM_CONTACTs = [
  {
    label: 'Madhya Pradesh Water Resource Department', value: 0,
    contact: {
      'Chief Engineer': 'Shri Bharat Gosavi',
      'Address': 'Chief Engineer (Bodhi),Water Resources Department, Jal Sansadhan Bhawan, Tulsi Nagar,Bhopal-462 003',
      'Mobile': '0755-2424785',
      'Fax': '0755-2424791',
      'Email Id': 'dsdrip@gmail.com / encbodhi@gmail.com'
    }
  },
  {
    label: 'Uttarakhand Jal Vidyut Nigam Ltd', value: 1,
    contact:{
      'Chief Engineer': ' Sandeep Singhal',
      'Address': 'Director (Projects), UJVNL, Maharani Bag, GMS Road, Dehradun-248006',
      'Fax': ' 0135-2762245 & 2761549',
      'Email Id': ' sandysinghal14@hotmail.com / dgm.pcmgv@gmail.com'  
    }
  },
  {
    label: 'Kerala Electricity Board', value: 2,
    contact:{
      'Chief Engineer': 'Anil Kumar R ',
      'Address': 'Chief Engineer, Dam Safety, KSEB, POTTAM, Thiruvananthapuram –695004',
      'Mobile': '09446008005',
      'Fax': '0471-2448972',
      'Email Id': 'ceipds@ksebnet.com'
    },
  },
  {
    label: 'Orissa Water Resource Department', value: 3,
    contact:{
      'Chief Engineer': 'Er. Bibhuti Bhusan Panda',
			'Address': 'Chief engineer, Dam Safety Secha Sadan Complex, Keshari Nagar Unit V, Bhubaneswar 751 001',
			'Mobile': '0674-2531934',
			'Fax': '0674-2531934',
			'Email Id': 'cedamsafety.odisha@gmail.com'
    },
  },
  {
    label: 'Tamilnadu Water Resource Department', value: 4,
    contact:{
      'Chief Engineer': 'T. Asokan',
			'Address': 'Chief Engineer (O&M) PWD, WRD, Chepauk, Chennai 600005',
			'Mobile': '044-28551919',
			'Fax': ' 044-28517261',
			'Email Id': 'ceomwro@gmail.com'
    },
  },
  {
    label: 'Kerala Water Resource Department', value: 5,
    contact:{
      'Chief Engineer': ' Mr. T G Sen',
			'Address': 'Chief Engineer (I&D), IDRB, III floor, Vikas Bhavanam, Thiruvananthapuram – 695 033',
			'Mobile': '09447780159',
			'Fax': '0471-2304094',
			'Email Id': 'idrbtvm@gmail.com'  
    },
  },
  {
    label: 'Karnataka Water Resource Department', value: 6,
    contact:{
      'Chief Engineer': ' M Shiva Swamy',
			'Address': 'Chief Engineer, WRDO, Anandrao Circle, Bangalore-9, Karanataka',
			'Fax': '080-2255306',
			'Email Id': 'superengrmande@yahoo.co.in'
    },
  },
  {
    label: 'Tamilnadu Generation and Distribution Corporation', value: 7,
    contact:{
      'Chief Engineer': 'C Ramesh',
			'Address': 'Chief Engineer, Civil Designs TNEB, 3rd Floor Eastern Wing, 144 Anna Salai, N P KRR Marg, Maligai, Chennai 600002',
			'Fax': '044-28521208',
			'Email Id': 'cecd@tnebnet.org / cecdtangedco@gmail.com'
    },
  },
  {
    label: 'Damodar Valley Corporation', value: 8,
    contact:{
      'Chief Engineer': ' Samir Sinha',
			'Address': 'Superintending Engineer(C), Tech P.A. to Chief Engineer (C), Nodal officer (DRIP) DVC,Maithon',
			'Mobile': '9431553962',
			'Fax': '0755-2424791',
			'Email Id': 'samir.sinha04@gmail.com / anjani_dubey@dvcindia.org'
    },
  },
  {
    label: 'Kerala Electricity Board', value: 9,
    contact:{
      'Chief Engineer': 'Anil Kumar R',
			'Address': ' Chief Engineer, Dam Safety, KSEB, POTTAM, Thiruvananthapuram –695004',
			'Mobile': '9446008005',
			'Fax': ' 0471-2448972',
			'Email Id': 'ceipds@ksebnet.com'
    },
  },
  {
    label: 'Central Water Commission', value: 10,
    contact:{
      'Chief Engineer': 'Shri Bharat Gosavi',
			'Address': 'Chief Engineer (Bodhi),Water Resources Department, Jal Sansadhan Bhawan, Tulsi Nagar,Bhopal-462 003',
			'Mobile': '0755-2424785',
			'Fax': '0755-2424791',
			'Email Id': 'dsdrip@gmail.com / encbodhi@gmail.com' 
    },
  },
  {
    label: 'Central Project Management Unit', value: 11,
    contact:{
      'Chief Engineer': 'Pramod Narayan',
			'Address': 'Central Water Commission, 3rd Floor, CWC New Library Building, Near Sewa Bhawan, R.K.Puram, New Delhi-110066',
			'Mobile': '011-29583480',
			'Fax': ' 011-29583399 ',
			'Email Id': ' dir-drip-cwc@nic.in' 
    },
  },
  {
    label: 'Ministry Of Water Resource', value: 12,
    contact:{
      'Address': ' MoWR, Krishi Bhawan, New Delhi - 110 001',
			'Email Id': 'commcadwm-mowr@nic.in'
    },
  },
]
class Contact extends Component {

  constructor(props) {
    super(props);

    this.state = {
      contact: DAM_CONTACTs[0].contact,
    }
  }

  handleTabChange(tabIndex) {
    console.log(tabIndex)
    this.setState({tabIndex})
  }

  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value });
  };

  handleToggle = value => () => {

    this.setState({
      contact: DAM_CONTACTs[value].contact,
    });
  };

  navigateToWelcome() {
    this.props.history.push('/')
  }

  render() {
    const { contact, tabIndex, checked } = this.state
    return (
      <div className='contactWrapper'>
      <header className={'welcomeHeader'}>
        <div className={'headerTitle'}>{'Dam Surveillance & Monitoring Project'}</div>
        <Button variant="raised" color="primary" 
        onClick={this.navigateToWelcome.bind(this)}>
          Lets login!
        </Button>
      </header>
      <div className='contactContainer'>
        <div className='contactList'>
          <List>
            {DAM_CONTACTs.map((value, index) => (
              <ListItem key={index} dense 
                button onClick={this.handleToggle(index)}>
                <ListItemText style={{fontSize: 18}} primary={value.label} />
              </ListItem>
            ))}
          </List>
        </div>
        <div className='contactInformation'>
            <h1>Contact Details</h1>
          <table >
          {
            Object.keys(contact).map((contactIndex, index)=>
              <tr className='' key={index}>
                <td>{contactIndex}</td><td>{contact[contactIndex]}</td>
              </tr>
            )
          }
          </table>
        </div>
      </div>
      </div>


      // <Tabs
      //   defaultActiveKey={(tabIndex + '')}
      //   onChange={this.handleTabChange.bind(this)}
      //   renderTabBar={()=><ScrollableInkTabBar />}
      //   renderTabContent={()=><TabContent />}
      //   style={{border: '1px solid red'}}
      // >
      //   <TabPane tab='tab 1' key="1">
      //     <div style={{border: '1px solid grey'}}> first</div>
      //   </TabPane>
      //   <TabPane tab='tab 2' key="2">
      //     second
      //   </TabPane>
      //   <TabPane tab='tab 3' key="3">
      //     third
      //   </TabPane>
      // </Tabs>
      //   {/* <FormControl className={'contactSelectorFormCtrl'}>
      //     <InputLabel htmlFor="contactSelector">Select a contact</InputLabel>
      //     <Select
      //       value={contact}
      //       onChange={this.handleChange}
      //       inputProps={{
      //         name: 'contact',
      //         id: 'contactSelector',
      //       }}
      //     >
      //       {DAM_CONTACTs.map((contact, index) => 
      //           <MenuItem key={index} value={contact.value}>{contact.label}</MenuItem>
      //       )}
      //     </Select>
      //   </FormControl> */}
      // </div>
    )
  }
}

export default withRouter(Contact)