import React, { Component } from 'react';
import Modal from 'react-responsive-modal';

import MyMapComponent from 'Component/google-map/GoogleMap';

import './Map.css';

const TEMP_DATA = {
  'label': 'New Delhi',
  'location': 'New Delhi, New Delhi, IN'
}

export default class Map extends Component {
  constructor(props) {
    super(props)

    this.state = {
      modal: false
    }
  }

  onOpenModal = () => {
    this.setState({ modal: true });
  };

  onCloseModal = () => {
    this.setState({ modal: false });
  };

  renderModal(data) {
    
    return (
      <Modal 
        open={this.state.modal} 
        onClose={this.onCloseModal} 
        little
        classNames={{
          overlay: 'geoModal',
          transitionEnter: 'transition-enter',
          transitionEnterActive: 'transition-enter-active',
          transitionExit: 'transition-exit-active',
          transitionExitActive: 'transition-exit-active',
        }}
        animationDuration={1000}>
          <div className='geoModalContainer'>
            <h1>{data.label}</h1>
            <div className='damLocation'>Location: {data.location}</div>
          </div>
      </Modal>
    )
  }

  render() {
    return (
      <div className="mapContainer">
        <MyMapComponent isMarkerShown onMarkerClick={this.onOpenModal.bind(this)}/>
        {this.renderModal(TEMP_DATA)}
      </div>
    )
  }
}
