import React, { Component } from 'react';
import AddIcon from 'material-ui-icons/Add';
import Button from 'material-ui/Button';
import ReactTable from 'react-table';
import Modal from "react-responsive-modal";
import { connect } from 'react-redux';
import TextField from 'material-ui/TextField';

import { addAlert, sendAlert } from 'Action/User';

import DamContainer from 'Component/dam-container/DamContainer';
import DamSelector from 'Component/dam-selector/DamSelector';

class Alert extends Component {

  constructor(props) {
    super(props)

    this.state = {
      newAuditModal: false,
      state: '',
      districts: [],
      district: '',
      dams: [],
      dam: '',
      damDetail: null,
      audit: null,
      audits: [],
      auditFormType: 'ADD',
      alertContent: ''
    }
  }

  componentWillReceiveProps(nextProps) {
    const { type } = nextProps.mainUser
    if(type == 'ADD_ALERT_SUCCESS') {
      alert('Alert added to DB. Now u\'ll receive all alerts regarding this dam')
      this.setState({newAuditModal: false})
      // this.refreshAudits()
    }
    if(type == 'SEND_ALERT_SUCCESS') {
      alert('Alert transferred to all following users')
      this.setState({alertContent: ''})
    }
  }

  handleFabModal = () => {
    this.setState({newAuditModal: !this.state.newAuditModal})
  }

  handleDescriptionChange = event => {
    this.setState({alertContent: event.target.value})
  }

  handleAddAlert = () => {
    const {  user, addAlert } = this.props
    const { dam, state, district } = this.state
    const alert = {dam, user}
    addAlert(alert)
  }

  handleSendAlert = () => {
    const {  user, sendAlert } = this.props
    const { alertContent, dam } = this.state
    const alert = {alertContent, dam}
    sendAlert(alert)
  }

  renderModal = () => {
    const { 
      newAuditModal, state, districts, district, dams, dam,
      audit, auditFormType
    } = this.state
    return (
      <Modal
        open={newAuditModal}
        onClose={this.handleFabModal}
        little
        classNames={{
          overlay: 'addAuditOverlay',
          modal: "addAuditModal",
          transitionEnter: 'transition-enter',
          transitionEnterActive: 'transition-enter-active',
          transitionExit: 'transition-exit-active',
          transitionExitActive: 'transition-exit-active',
        }}
        animationDuration={1000}
      >
        <div className='addAuditContainer'>
          <DamSelector 
            state={state}
            district={district}
            districts={districts}
            dam={dam}
            dams={dams}
            onChangeState={(state, districts)=>this.setState({state, districts})}
            onChangeDistrict={(district, dams)=> this.setState({district, dams})}
            onChangeDam={(dam, damDetail)=>this.setState({dam, damDetail})}
            onSubmit={()=>console.log('TODO')}
          />
          <Button variant="raised"  color={'secondary'} onClick={this.handleAddAlert}>
          Add Alert
        </Button>
        </div>
      </Modal>
    )
  }

  render() {
    const { 
      newAuditModal, state, districts, district, dams, dam,
      audit, auditFormType
    } = this.state
    const { user } = this.props
    debugger
    return (
      <DamContainer className="homeContainer">
         {user.userType == 'AUDITOR_1' && <div className='sendAlertContainer'>
          <DamSelector 
            state={state}
            district={district}
            districts={districts}
            dam={dam}
            dams={dams}
            onChangeState={(state, districts)=>this.setState({state, districts})}
            onChangeDistrict={(district, dams)=> this.setState({district, dams})}
            onChangeDam={(dam, damDetail)=>this.setState({dam, damDetail})}
            onSubmit={()=>console.log('TODO')}
          />
          <TextField
              id="alertContentId"
              label="Alert Content"
              palceholder="Make ur alerts"
              value={this.state.alertContent}
              multiline
              rows="4"
              className={'loginTxtFld'}
              style={{margin: '0 10px'}}
              onChange={this.handleDescriptionChange}
              helperText="Complete alert to following users "
              fullWidth
            />
          <Button variant="raised"  color={'secondary'} onClick={this.handleSendAlert}>
          Send Alert
        </Button>
    </div>  }
        {this.renderModal()}
        <Button variant="fab" style={styles.fabIcon} color={'secondary'} onClick={this.handleFabModal}>
          <AddIcon />
        </Button>
      </DamContainer>
    )
  }
}

const styles = {
  fabIcon: {
    position: 'absolute',
    bottom: 50,
    right: 20
  }
}

const mapStateToProps = state => {
  return {
    user: state.User.user,
    audit: state.Audit,
    mainUser: state.User
  }
}

const mapDispatchToProps = dispatch => {
  return {
    addAlert: (alert) => {
      dispatch(addAlert(alert))
    },
    sendAlert: (alert) => {
      dispatch(sendAlert(alert))
    }
  }
}

const AlertWrapper = connect(
  mapStateToProps,
  mapDispatchToProps
)(Alert)

export default AlertWrapper