import React, { Component } from 'react';
import AddIcon from 'material-ui-icons/Add';
import Button from 'material-ui/Button';

import DamContainer from 'Component/dam-container/DamContainer';

import './Home.css';

export default class Home extends Component {
  render() {
    return (
      <DamContainer className="homeContainer">
        <Button variant="fab" style={styles.fabIcon} color={'secondary'}>
          <AddIcon />
        </Button>
      </DamContainer>
    )
  }
}

const styles = {
  fabIcon: {
    position: 'absolute',
    bottom: 50,
    right: 20
  }
}