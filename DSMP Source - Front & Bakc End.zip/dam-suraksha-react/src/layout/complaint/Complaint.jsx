import React, { Component } from 'react';
import AppBar from 'material-ui/AppBar';
import { withStyles } from 'material-ui/styles';
import AddIcon from 'material-ui-icons/Add';
import TextField from 'material-ui/TextField';
import Button from 'material-ui/Button';
import Input, { InputLabel } from 'material-ui/Input';
import { MenuItem } from 'material-ui/Menu';
import { FormControl, FormHelperText, FormControlLabel } from 'material-ui/Form';

import Radio, { RadioGroup } from 'material-ui/Radio';

import Checkbox from 'material-ui/Checkbox';
import CheckBoxOutlineBlankIcon from 'material-ui-icons/CheckBoxOutlineBlank';
import CheckBoxIcon from 'material-ui-icons/CheckBox';
import Select from 'material-ui/Select';
import List, { ListItem, ListItemText } from 'material-ui/List';
import Tabs, { Tab } from 'material-ui/Tabs';
import SwipeableViews from 'react-swipeable-views';
import Typography from 'material-ui/Typography';
import ReactTable from 'react-table';
import Modal from "react-responsive-modal";
import { connect } from 'react-redux';
import Dropzone from 'react-dropzone';
import FormData from 'form-data';
import Card, { CardActions, CardContent, CardMedia } from 'material-ui/Card';

import { saveComplaint, collectComplaint, updateComplaint } from 'Action/Complaint';
import { saveAudit, collectAudits, getAudit } from 'Action/Audit';

import DamContainer from 'Component/dam-container/DamContainer';
import DamSelector from 'Component/dam-selector/DamSelector';
import AuditForm from 'Component/audit-form/AuditForm';
var Dropbox = require('dropbox').Dropbox;
// const axios = require('axios');
const ACCESS_TOKEN = '****'
var dbx = new Dropbox({ accessToken: ACCESS_TOKEN });

import { getStateList, getDistrictList, getDamList } from 'Util/CountryDataUtil';
import { getDamDetail } from 'Util/DamDetail';
import { convertToString } from 'Util/DateUtil';

import './Complaint.css';
import "react-table/react-table.css";

const tableData = [{
  id: 'COMPLAINT001',
  stateName: 'Rajasthan',
  districtName: 'Bhilwara',
  damName: 'Meja Dam',
  description: '',
  status: 'FILED',
  addedBy: {
    name: 'Mohan',
    type: 'STANDARD'
  },
  addedDate: convertToString(new Date()),
  auditedDate: null,
  auditedBy: null
},{
  id: 'COMPLAINT002',
  stateName: 'Rajasthan',
  districtName: 'Bhilwara',
  damName: 'Meja Dam',
  description: '',
  status: 'AUDITED',
  addedBy: {
    name: 'Mohan',
    type: 'STANDARD'
  },
  addedDate: convertToString(new Date()),
  auditedDate: convertToString(new Date()),
  auditedBy: {
    name: 'ram',
    type: 'STATE_AUDITOR'
  }
}]

const STATEs = getStateList();

function TabContainer({ children, dir }) {
  return (
    <Typography component="div" dir={dir} style={{ padding: 8 * 3 }}>
      {children}
    </Typography>
  );
}

class Complaint extends Component {

  constructor(props) {
    super(props);

    this.state = {
      dropbox: null,
      state: '',
      districts: [],
      district: '',
      dams: [],
      dam: '',
      damDetail: null,
      tabValue: 0,
      modalFlag: false,
      description: '',
      complaints: [],
      newAuditModal: false,
      selectedComplaint: null,
      audit: null,
      defects: {
        sand: false,
        leakage: false,
        detoriation: false,
        eroation: false,
        animalBurrows: false,
        others: false
      }
    }
    this.handleCheckBox=this.handleCheckBox.bind(this);
  }

  componentWillMount() {
    const state = 'Rajasthan'
    const district = 'Bhilwara'
    const dam = 'Meja Dam'
    this.setState({
      state,
      district,
      dam,
      districts: getDistrictList(state), 
      dams: getDamList(district, state),
      damDetail: getDamDetail(dam)})
    this.refreshComplaints()
  }

  componentWillReceiveProps(nextProps) {
    const { type, complaints } = nextProps.complaint
    const { type: auditType, audits, audit } = nextProps.audit
    if(type == 'ADD_COMPLAINT_SUCCESS') {
      alert('Complaint added to DB')
      this.setState({description: '', modalFlag: false})
      this.refreshComplaints()
    }
    if(type == 'COLLECT_COMPLAINT_SUCCESS') {
      this.setState({complaints})
    }
    if(type == 'ADD_AUDIT_SUCCESS') {
      alert('Complaint added to DB')
      this.setState({newAuditModal: false})
      this.refreshComplaints()
    }
    if(type == 'GET_AUDIT_SUCCESS') {
      this.setState({audit, state: audit.state, district: audit.district, dam:audit.dam})
      
      setTimeout(()=>{
        // this.updateDamSelector()
        this.getDistrictList(audit.state)
        this.getDamList(audit.district)
        this.handleViewAuditBtnClick()
      }, 1000)
    }
  }

  // updateDamSelector() {
  //   const { audit } = this.state
  //   this.setState({state: audit.state, district: audit.district, dam:audit.dam})
  // }

  getDistrictList(stateName) {
    const districts = getDistrictList(stateName)
    this.setState({districts})
  }

  getDamList(districtName, stateOpt) {
    const { state } = this.state
    const dams = getDamList(districtName, state)
    this.setState({dams})
  }

  getDamDetail(damName) {
    this.setState({damDetail: getDamDetail(damName) })
    this.refreshComplaints()
  }

  refreshComplaints() {
    const {
      state,
      district,
      dam } = this.state
    if(state != '' && district != '' && dam != '') {
      this.props.collectComplaint({state, district, dam})
    }
  }

  createComplaint = () => {
    const { state, district, dam, description, dropbox } = this.state
    const { user } = this.props.user
    this.props.saveComplaint({
      state,
      district,
      dam, description,
      'auditId': null,
      'status': 'FILED',
      'addedBy': user,
      addedDate: convertToString(new Date()),
      dropbox: dropbox,
      'auditedBy': null,
      'auditedDate': null
    })

  }

  handleModal = () => {
    this.setState({modalFlag: !this.state.modalFlag})
  }

  handleDescriptionChange = event => {
    this.setState({description: event.target.value})
  }

  handleCheckBox = name => event => {
    let { defects } = this.state
    defects[name] = event.target.checked
    this.setState({ defects });
  };


  handleChange = event => {
    const eventValue = event.target.value;
    const eventName = event.target.name
    if(eventName == 'state' && eventValue != '') {
      this.getDistrictList(eventValue)
    } else if(eventName == 'district' && eventValue != '') {
      this.getDamList(eventValue)
    } else if(eventName == 'dam' && eventValue != '') {
      this.getDamDetail(eventValue)
    }
    this.setState({ [eventName]: eventValue });
  };

  handleTabChange = (event, tabValue) => {
    if(tabValue == 1) {
      this.refreshComplaints()
    }
    this.setState({ tabValue });
  };

  handleTabChangeIndex = index => {
    if(index == 1) {
      this.refreshComplaints()
    }
    this.setState({ tabValue: index });
  };

  createAudit = (audit) => {
    const { saveAudit, user } = this.props
    const { dam, state, district, selectedComplaint } = this.state
    audit.user = user.user
    audit.dam = dam
    audit.state = state
    audit.district = district
    audit.complaintId = selectedComplaint._id
    saveAudit(audit)

    // let complatin = Object.assign({}, selectedComplaint)
    // complatin.status = 'AUDITED'
    // updateComplaint(complatin)
  }

  handleAuditBtnClick = (value, original) => {
    debugger
    const { getAudit } = this.props
    if(value == 'FILED') {
      this.setState({selectedComplaint: original})
      this.handleFabModal()
    } else {
      getAudit(original._id)
    }
  }

  handleFabModal = () => {
    this.setState({newAuditModal: !this.state.newAuditModal, auditFormType: 'ADD'})
  }

  handleViewAuditBtnClick = () => {
    this.setState({ auditFormType: 'VIEW', newAuditModal: true})
  }

  renderAuditModal = () => {
    const { 
      newAuditModal, state, districts, district, dams, dam,
      audit, auditFormType
    } = this.state
    const { user: { userType } } = this.props
    // const userType = 'AUDITOR_3'
    return (
      <Modal
        open={newAuditModal}
        onClose={this.handleFabModal}
        little
        classNames={{
          overlay: 'addAuditOverlay',
          modal: "addAuditModal",
          transitionEnter: 'transition-enter',
          transitionEnterActive: 'transition-enter-active',
          transitionExit: 'transition-exit-active',
          transitionExitActive: 'transition-exit-active',
        }}
        animationDuration={1000}
      >
        <div className='addAuditContainer'>
          <DamSelector 
            viewType={auditFormType}
            state={state}
            district={district}
            districts={districts}
            dam={dam}
            dams={dams}
            onChangeState={(state, districts)=>this.setState({state, districts})}
            onChangeDistrict={(district, dams)=> this.setState({district, dams})}
            onChangeDam={(dam, damDetail)=>this.setState({dam, damDetail})}
            onSubmit={()=>console.log('TODO')}
          />
          <AuditForm 
            audit={audit}
            viewType={auditFormType}
            userType={userType}
            handleAuditSubmit={this.createAudit.bind(this)} 
            handleAuditCancel={this.handleFabModal.bind(this)} />
        </div>
      </Modal>
    )
  }

  renderDetail(damDetail) {
    const { classes, theme, user } = this.props;
    const { complaints } = this.state

    let tableColumn = [{
      Header: 'ID',
      accessor: '_id'
    }, {
      Header: 'Description',
      accessor: 'description'
    },{
      Header: 'Status',
      accessor: 'status'
    }, {
      Header: 'Complained Date',
      accessor: 'addedDate', // Custom value accessors!
      Cell: props => <span>{props.value != null ? props.value : '-'}</span> // Custom cell components!
    }, {
      Header: 'Added By',
      accessor: 'addedBy', // Custom value accessors!
      Cell: props => <span>{props.value != null && props.value.name ? props.value.name : '-'}</span> // Custom cell components!
    }, {
      Header: 'Audited Date',
      accessor: 'auditedDate',
      Cell: props => <span>{props.value != null ? props.value : '-'}</span> // Custom cell components!
    }, {
      Header: 'Audited By',
      accessor: 'auditedBy',
      Cell: props => <span>{props.value != null && props.value.name ? props.value.name : '-'}</span> // Custom cell components!
    }]

    if(user && user.user && user.user.userType && 
      (user.user.userType == 'AUDITOR_1' || user.user.userType == 'AUDITOR_2' || user.user.userType == 'AUDITOR_3')) {
      tableColumn.push({Header: 'Action', 
        accessor: 'status',
        Cell: ({ value, row, original }) => <Button 
          variant="raised" 
          color={value != null && value == 'AUDITED' ? 'primary' : 'secondary'}
          style={{padding: '10px'}} 
          onClick={()=>this.handleAuditBtnClick(value, original)}>
            {value != null && value == 'AUDITED' ? 'VIEW' : 'AUDIT'}
          </Button>
      })
    }

    return (
      <div className='damDetailContainer'>
        <div className='damDetailActionWrapper'>
          <Button 
            variant="raised" 
            color="secondary"
            style={{margin: '0 10px'}} 
            onClick={this.handleModal}>
            File complaint
          </Button>
        </div>
        <AppBar position="static" color="default">
          <Tabs
            value={this.state.tabValue}
            onChange={this.handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            fullWidth
            centered
          >
            <Tab label="Dam Detail" />
            <Tab label="View Complaints" />
          </Tabs>
        </AppBar>
        <SwipeableViews
          axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
          index={this.state.tabValue}
          onChangeIndex={this.handleTabChangeIndex}
        >
        <TabContainer 
          dir={theme.direction}>
            {damDetail ? <List>
            {Object.keys(damDetail).map((key, index)=><ListItem key={index}>
              <ListItemText primary={key.replace(new RegExp('_', 'g'), ' ')} secondary={damDetail[key]} />
            </ListItem>)
            }
            </List> : <span>{'No details found. Sorry. We\'ll update sooner than you thin'}</span>}
          </TabContainer>
          <TabContainer dir={theme.direction}>
          <ReactTable
            data={complaints}
            columns={tableColumn}
            defaultPageSize={10}
            className="-striped -highlight"
          />
          </TabContainer>
        </SwipeableViews>
      </div>
    )
  }

  getHeaders = (form) => {
    return new Promise((resolve, reject) => {
        form.getLength((err, length) => {
            if(err) { reject(err); }
            let headers = Object.assign({'Content-Length': length}, form.getHeaders());
            resolve(headers);
         });
    });
}

handleFileChange = (acceptedFiles) =>
  {
      // console.log(acceptedFiles);
      const file = acceptedFiles[0]
      // var formData = new FormData();
      //           console.log( acceptedFiles[0])
      //           formData.append('name', acceptedFiles[0])
      // axios.post('http://localhost:3000/image', formData, {
      //             headers: {
      //               'accept': 'application/json',
      //               'Accept-Language': 'en-US,en;q=0.8',
      //               // 'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
      //               'Content-Type': formData.type
      //             }
      //             //formData.getHeaders(),
      //           }).then(result => {
      //             console.log(result.data);
      //           }).catch((err)=>{
      //             console.log('axios push')
      //             console.log(err)
      //           });

                dbx.filesUpload({path: '/' + file.name, contents: file})
        .then(function(response) {
          // var results = document.getElementById('results');
          // results.appendChild(document.createTextNode('File uploaded!'));
          console.log(response);
          console.log('file saved')
          this.setState({dropbox: response})
        })
        .catch(function(error) {
          console.error(error);
        });
  }


  renderModal() {
    const { modalFlag, defects: {
      sand,
      leakage,
      detoriation,
      eroation,
      animalBurrows,
      others
    } } = this.state
    
    return (
      <Modal
          open={modalFlag}
          onClose={this.handleModal}
          little
          classNames={{
            transitionEnter: 'transition-enter',
            transitionEnterActive: 'transition-enter-active',
            transitionExit: 'transition-exit-active',
            transitionExitActive: 'transition-exit-active',
          }}
          animationDuration={1000}
        >
          <div className='addComplaintContainer'>
            <h1>Lets' file a complaint</h1>
            <div className='defectGroup'>
            <Card style={{
                maxWidth: 345,
              }}>
              <CardMedia
                style={{
                  height: 200,
                }}
                image={require("../../asset/image/defect3.jpg")}
                title="Contemplative Reptile"
              />
              <CardContent>
                <Typography gutterBottom variant="headline" component="h2">
                  SAND BOIL
                </Typography>
                <Typography component="p">
                A bubbling spring sometimes several feet in diameter that bursts through the ground at the back of a river levee
                </Typography>
              </CardContent>
            </Card>
            <Card style={{
                maxWidth: 345,
              }}>
              <CardMedia
                style={{
                  height: 200,
                }}
                image={require("../../asset/image/defect4.jpg")}
                title="Contemplative Reptile"
              />
              <CardContent>
                <Typography gutterBottom variant="headline" component="h2">
                LEAKAGE
                </Typography>
                <Typography component="p">
                The accidental admission or escape of liquid or gas through a hole or crack.
                </Typography>
              </CardContent>
            </Card>
            <Card style={{
                maxWidth: 345,
              }}>
              <CardMedia
                style={{
                  height: 200,
                }}
                image={require("../../asset/image/defect6.jpg")}
                title="Contemplative Reptile"
              />
              <CardContent>
                <Typography gutterBottom variant="headline" component="h2">
                DETERIORATION OF CONCRETE SURFACE
                </Typography>
                <Typography component="p">
                Deterioration in any adverse change of normal mechanical, physical and chemical properties either on the surface or in the whole body of concrete generally through separation of its components.
                </Typography>
              </CardContent>
            </Card>
            <Card style={{
                maxWidth: 345,
              }}>
              <CardMedia
                style={{
                  height: 200,
                }}
                image={require("../../asset/image/defect9.jpg")}
                title="Contemplative Reptile"
              />
              <CardContent>
                <Typography gutterBottom variant="headline" component="h2">
                EROSION IN EMBANKMENT
                </Typography>
                <Typography component="p">
                The process of eroding or being eroded by wind, water, or other natural agents.
                </Typography>
              </CardContent>
            </Card>
            <Card style={{
                maxWidth: 345,
              }}>
              <CardMedia
                style={{
                  height: 200,
                }}
                image={require("../../asset/image/defect13.jpg")}
                title="Contemplative Reptile"
              />
              <CardContent>
                <Typography gutterBottom variant="headline" component="h2">
                ANIMAL BURROWS
                </Typography>
                <Typography component="p">
                A burrow is a hole or tunnel excavated into the ground by an animal to create a space suitable for habitation, temporary refuge, or as a byproduct of locomotion
                </Typography>
              </CardContent>
            </Card>
              <div className='checkboxSelector'>
              <FormControlLabel
                  control={
                    <Checkbox
                      checked={sand}
                      onChange={this.handleCheckBox('sand')}
                      value="sand"
                    />
                  }
                  label="Sand Boil"
                />
              <FormControlLabel
                  control={
                    <Checkbox
                      checked={leakage}
                      onChange={this.handleCheckBox('leakage')}
                      value="leakage"
                    />
                  }
                  label="Leakage"
                />
              <FormControlLabel
                  control={
                    <Checkbox
                      checked={detoriation}
                      onChange={this.handleCheckBox('detoriation')}
                      value="detoriation"
                    />
                  }
                  label="Detoriation"
                />
              <FormControlLabel
                  control={
                    <Checkbox
                      checked={eroation}
                      onChange={this.handleCheckBox('eroation')}
                      value="eroation"
                    />
                  }
                  label="Erosion"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={animalBurrows}
                      onChange={this.handleCheckBox('animalBurrows')}
                      value="animalBurrows"
                    />
                  }
                  label="Animal Burrows"
                />
                <FormControlLabel value={true} control={<Radio />} label="Other" />
              </div>
            </div>
            <TextField
              id="complaintDescription"
              label="Description"
              palceholder="Use your thoughts here..."
              value={this.state.description}
              multiline
              rows="4"
              className={'loginTxtFld'}
              style={{margin: '0 10px'}}
              onChange={this.handleDescriptionChange}
              helperText="Complete description about dam defects"
              fullWidth
            />
            {/* <Dropzone
              accept="image/jpeg, image/png"
              onDrop={(acceptedFiles, rejected) => { 
                // SRC: https://github.com/react-dropzone/react-dropzone
                // https://react-dropzone.js.org/
                debugger
                var formData = new FormData();
                console.log( acceptedFiles[0])
                formData.append('name', acceptedFiles[0])
                // this.getHeaders(formData)
                // .then((headers) => {
                //     return axios.post(url, formData, {headers:headers}).then(res=>{

                //     }).catch((err)=>{
                //       console.log('err in axios')
                //     })
                // })
                // .then((response)=>{
                //     console.log(response.data)
                // })
                // .catch(e=>{console.log(e)})
                axios.post('http://localhost:3000/image', formData, {
                  headers: {
                    'accept': 'application/json',
                    'Accept-Language': 'en-US,en;q=0.8',
                    // 'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
                    'Content-Type': formData.type
                  }
                  //formData.getHeaders(),
                }).then(result => {
                  console.log(result.data);
                }).catch((err)=>{
                  console.log('axios push')
                  console.log(err)
                });



                acceptedFiles.forEach(file => {
                  const reader = new FileReader();
                  
                  reader.onload = () => {
                    
                    const fileAsBinaryString = reader.result;
                    axios.post('http://localhost:3000/image', {fileAsBinaryString}, {
                      // headers: {
                      //   'accept': 'application/json',
                      //   'Accept-Language': 'en-US,en;q=0.8',
                      //   // 'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
                      //   'Content-Type': formData.type
                      // }
                      //formData.getHeaders(),
                    }).then(result => {
                      console.log(result.data);
                    }).catch((err)=>{
                      console.log('axios push')
                      console.log(err)
                    });
                    // console.log('imageBinaryData')
                    
                    // console.log(fileAsBinaryString)
                    // let data = new FormData();
                    // data.append('name', files[0])
                    // form.append('field', 'a,b,c');
                    // axios.post('http://example.org/endpoint', form, {
                    //   headers: form.getHeaders(),
                    // }).then(result => {
                    //   // Handle result…
                    //   console.log(result.data);
                    // });
                  };
                  reader.onabort = () => console.log('file reading was aborted');
                  reader.onerror = () => console.log('file reading has failed');
          
                  reader.readAsBinaryString(file);
              });
                this.setState({ acceptedFiles, rejected }); 
              }}
            >
              <p>Try dropping some files here, or click to select files to upload.</p>
              <p>Only *.jpeg and *.png images will be accepted</p>
            </Dropzone> */}
            <input type='file' name='file' onChange={ (e) => this.handleFileChange(e.target.files) }/>
            <div className='complaintBtnWrapper'>
              <Button 
                variant="raised" 
                color="primary"
                style={{margin: '0 10px'}} 
                onClick={this.createComplaint}>
                File complaint
              </Button>
              <Button 
                variant="raised" 
                color="secondary"
                style={{margin: '0 10px'}} 
                onClick={this.handleModal}>
                Cancel
              </Button>
            </div>
          </div>
        </Modal>
    )
  }

  render() {
    const { state, districts, district, dams, dam, damDetail } = this.state
    return (
      <DamContainer className="complaintContainer">
        <div className='deleteLate'>WORKING SAMPLE->RAJASTHAN->Bhilwara->MEJA DAM</div>
        <div className='damSelector'>
          <FormControl>
            <InputLabel htmlFor="stateSelector">State</InputLabel>
            <Select
              style={{width: 200}}
              value={state}
              onChange={this.handleChange}
              inputProps={{
                name: 'state',
                id: 'stateSelector',
              }}
            >
              {STATEs && STATEs.map((stateName, index) => 
                  <MenuItem value={stateName} key={index}>
                    {stateName}
                  </MenuItem>
              )}
            </Select>
            <FormHelperText>Select a state</FormHelperText>
          </FormControl>
          <FormControl>
            <InputLabel htmlFor="districtSelector">District</InputLabel>
            <Select
              style={{width: 200}}
              value={district}
              onChange={this.handleChange}
              inputProps={{
                name: 'district',
                id: 'districtSelector',
              }}
            >
              {districts && districts.map((districtName, index) => 
                <MenuItem value={districtName} key={index}>
                  {districtName}
                </MenuItem>
              )}
            </Select>
            <FormHelperText>Select a district</FormHelperText>
          </FormControl>
          <FormControl>
            <InputLabel htmlFor="damSelector">Dam</InputLabel>
            <Select
              style={{width: 200}}
              value={dam}
              onChange={this.handleChange}
              inputProps={{
                name: 'dam',
                id: 'damSelector',
              }}
            >
              {dams && dams.map((damName, index) => 
                <MenuItem value={damName} key={index}>
                  {damName}
                </MenuItem>
              )}
            </Select>
            <FormHelperText>Select a dam</FormHelperText>
          </FormControl>
        </div>
        <div className='damDetailContainer'>
          {
            damDetail ? this.renderDetail(damDetail) : null
          }
        </div>
        {this.renderModal()}
        {this.renderAuditModal()}
      </DamContainer>
    )
  }
}

const styles = theme => ({
})

const mapStateToProps = state => {
  return {
    user: state.User,
    complaint: state.Complaint,
    audit: state.Audit
  }
}

const mapDispatchToProps = dispatch => {
  return {
    saveComplaint: complaint => {
      dispatch(saveComplaint(complaint))
    },
    collectComplaint: complaint => {
      dispatch(collectComplaint(complaint))
    },
    updateComplaint: complaint => {
      dispatch(updateComplaint(complaint))
    },
    saveAudit: audit => {
      dispatch(saveAudit(audit))
    },
    getAudit: complaintId => {
      dispatch(getAudit(complaintId))
    }
  }
}

const ComplaintWrapper = connect(
  mapStateToProps,
  mapDispatchToProps
)(Complaint)

export default withStyles(styles, { withTheme: true })(ComplaintWrapper)
