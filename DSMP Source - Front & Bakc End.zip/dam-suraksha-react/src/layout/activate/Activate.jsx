import React, { Component } from 'react';
import DoneIcon from 'material-ui-icons/Done'
import ErrorIcon from 'material-ui-icons/Error';
import { CircularProgress } from 'material-ui/Progress';
import { connect } from 'react-redux';
import Button from 'material-ui/Button';
import { withRouter } from 'react-router-dom';

import { activateUser } from 'Action/User';

import './Activate.css';

class Activate extends Component {

  constructor(props) {
    super(props)

    this.state = {
      activated: null
    }
  }

  componentWillReceiveProps(nextProps) {
    const { user: { type } } = nextProps
    if(type == 'USER_ACTIVATION_SUCCESS') {
      this.setState({activated: true})
    } else if(type == 'USER_ACTIVATION_FAILED') {
      this.setState({activated: false})
    }
  }

  componentWillMount() {
    const { match: { params }, activateUser } = this.props;
    activateUser(params.emailId)
  }

  navigateToWelcome() {
    this.props.history.push('/')
  }

  render() {
    const { activated } = this.state
    let activatedIcon = <CircularProgress className={'activeIcon'} size={200} />
    if(activated) {
      activatedIcon = <DoneIcon className={'activeIcon'} size={200} />
    } else if(activated == false) {
      activatedIcon = <ErrorIcon className={'activeIcon'} size={200} />
    }
    return (
      <div className='activateContainer'>
        Your accound has {activated ? '' : 'not'} been activated
        {activatedIcon}
        {activated == true ? <Button variant="raised" color="primary" 
          onClick={this.navigateToWelcome.bind(this)}>
            Lets login!
        </Button> : null}
      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
    user: state.User
  }
}

const mapDispatchToProps = dispatch => {
  return {
    activateUser: emailId => {
      dispatch(activateUser(emailId))
    },
  }
}

const ActivateWrapper = connect(
  mapStateToProps,
  mapDispatchToProps
)(Activate)

export default withRouter(ActivateWrapper);
