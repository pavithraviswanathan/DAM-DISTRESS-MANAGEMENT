import React, { Component } from 'react';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import Button from 'material-ui/Button';
import { FormGroup, FormControlLabel } from 'material-ui/Form';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import Input, { InputLabel } from 'material-ui/Input';
import { MenuItem } from 'material-ui/Menu';
import { FormControl, FormHelperText } from 'material-ui/Form';
import Select from 'material-ui/Select';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { authenticateUser, saveUser } from 'Action/User';
import { sendMail } from 'Action/Mail';

import './Welcome.css';

const DEPARTMENTs = [
  "Andamanand Nicobar Islands Water Resources Department",
  "Andhra Pradesh Power Generation Corporation ",
  "Andhra Pradesh Water Resources Department",
  "Arunachal Pradesh Water Resources Department ",
  "Assam Water Resources Department ",
  "Bihar Water Resources Department ",
  "Central Dam Safety Organisation ",
  "Chhattisgarh Water Resources Department ",
  "Damodar Valley Corporation ",
  "Goa Water Resources Department ",
  "Gujarat Water Resources Department  ",
  "Himachal Pradesh Water Resources Department ",
  "Jammu and Kashmir Water Resources Department ",
  "Jharkhand Water Resources Department ",
  "Karnataka Water Resources Department ",
  "Kerala State Electricity Board ",
  "Kerala Water Authority ",
  "Kerala Water Resources Department ",
  "Madhya Pradesh State Electricity Board ",
  "Madhya Pradesh Water Resources Department ",
  "Maharashtra Water Resources Department ",
  "Manipur Water Resources Department ",
  "Meghalaya Power Generation Corporation Limited ",
  "Meghalaya Water Resources Department ",
  "Narmada Valley Development Authority ",
  "National Hydroelectric Power Corporation ",
  "Odisha Water Resources Department ",
  "Punjab Water Resources Department ",
  "Rajasthan Water Resources Department ",
  "Sikkim Water Resources Department ",
  "TamilNadu Electricity Generation and Distribution Corporation ",
  "TamilNadu Water Resources Department ",
  "Tehri Hydro Development Corporation ",
  "Tripura Water Resources Department ",
  "UttarPradesh Irrigation and Water ResourcesDepartment ",
  "Uttarakhand Irrigation Department ",
  "Uttarakhand Power Corporation ",
  "WestBengalWaterResources Department"
]

const DESIGNATIONs = [
  {name: "Dam Safety Engineer", value: "AUDITOR_1"},
  {name: "Experienced Engineer", value: "AUDITOR_2"},
  {name: "Dam Safety Experts", value: "AUDITOR_3"},
]

class Welcome extends Component {
  
  constructor(props) {
    super(props);

    this.state = {
      login: {
        emailId: '',
        password: '',
        activated: true
      },
      register: {
        emailId: '',
        password: '',
        confirmPassword: '',
        mobile: '',
        error: '',
        userType: '',
        activated: false
      },
      auditorSignUp: false,
      auditor: {
        govtId: '',
        department: '',
        designation: ''
      },
      loader: true
    }
  }

  componentWillReceiveProps(nextProps) {
    const { user: { type } } = nextProps
    const { loader } = this.state
    if(type == 'USER_AUTHENTICATION_SUCCESS' && loader) {
      this.props.history.push('/home')
    }
    if(type == 'ADD_USER_SUCCESS' || type == 'ADD_USER_FAILED') {
      this.setState({loader: true})
    }
  }

  navigateToContactPage() {
    this.props.history.push('/contact')
  }

  navigateToAboutPage() {
    this.props.history.push('/about')
  }

  toggleAuditorSignUp() {
    this.setState({auditorSignUp: !this.state.auditorSignUp})
  }

  handleRegister() {
    const { register, register: { 
      emailId, password, confirmPassword, mobile, error }, 
      auditor: {govtId, department, designation}, 
      auditorSignUp } = this.state
    if(password !== confirmPassword) {
      register['error'] = 'PASSWORD MISMATCH'
      this.setState({register})
      return;
    }
    let newUser = Object.assign({}, this.state.register)
    if(auditorSignUp && (govtId == ''  || department == '' || designation == '')) {
      register['error'] = 'ALL FIELDS REQUIRED'
      this.setState({register})
      return
    } else {
      newUser.govtId = govtId;
      newUser.department = department;
      newUser.userType = designation;
    }
    this.setState({loader: false})
    // const mailObj = {
    //   from: 'vrnarencse@gmail.com', // Remains constant
    //   to: emailId, // Just udate to mail address
    //   subject: 'DSMP Authentication', // Subject which needs to be included in mail
    //   text: 'Select the following link to activate your account\n\nhttp://localhost:8010/activate' // main content in the body
    // }
    // this.props.sendMail(mailObj)
    delete newUser.confirmPassword;
    delete newUser.error;
    this.props.saveUser(newUser)

    console.log('uncomment save user to save in mongodb')
  }

  handleLogin() {
    this.props.authenticateUser(this.state.login)
  }

  // Handles both register and login
  handleChange = (name, type) => event => {
    const stateObje = this.state[type]
    stateObje[name] = event.target.value
    this.setState({
      [type]: stateObje,
    });
  };

  handleSelectorChange = event => {
    const eventValue = event.target.value;
    const eventName = event.target.name
    const { auditor } = this.state
    auditor[eventName] = eventValue
    this.setState({ auditor });
  };

  navigateToContact() {
    this.props.history.push('/contact')
  }

  navigateToAbout() {
    this.props.history.push('/about')
  }

  renderAuditorSignUp() {
    const { auditor } = this.state
    return (
      <div className="auditorRegisterContainer">
        <TextField
          id="auditorGovtId"
          label="Govt ID"
          value={auditor['govtId']}
          className={'auditorRegTxtFld'}
          style={{margin: '0 10px'}}
          onChange={this.handleChange('govtId', 'auditor')}
        />
        <FormControl>
          <InputLabel htmlFor="departmentSelector">Department</InputLabel>
          <Select
            value={auditor['department']}
            onChange={this.handleSelectorChange}
            inputProps={{
              name: 'department',
              id: 'departmentSelector',
            }}
          >
            {DEPARTMENTs && DEPARTMENTs.map((department, index) => 
                <MenuItem value={department} key={index}>
                  {department}
                </MenuItem>
            )}
          </Select>
        </FormControl>
        <FormControl>
          <InputLabel htmlFor="designationSelector">Designation</InputLabel>
          <Select
            value={auditor['designation']}
            onChange={this.handleSelectorChange}
            inputProps={{
              name: 'designation',
              id: 'designationSelector',
            }}
          >
            {DESIGNATIONs && DESIGNATIONs.map((designation, index) => 
                <MenuItem value={designation.value} key={index}>
                  {designation.name}
                </MenuItem>
            )}
          </Select>
        </FormControl>
      </div>
    )
  }

  renderRegisterContainer() {
    const { register, register: { error }, auditorSignUp } = this.state
    
    return (
      <div className='registerContainer'>
        <h2>Register an account</h2>
        {
          error != '' && <span className='error'>{error}</span>
        }
        <TextField
          id="registerEmailId"
          label="Email ID"
          value={register['emailId']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('emailId', 'register')}
        />
        <TextField
          id="registerPassword"
          label="Password"
          type="password"
          value={register['password']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('password', 'register')}
        />
        <TextField
          id="registerConfirmPassword"
          label="Confirm Password"
          type="password"
          value={register['confirmPassword']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('confirmPassword', 'register')}
        />
        <TextField
          id="registerMobile"
          label="Mobile"
          value={register['mobile']}
          className={'registerTxtFld'}
          style={{margin: '10px 0'}}
          onChange={this.handleChange('mobile', 'register')}
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={this.state.auditorSignUp}
              onChange={this.toggleAuditorSignUp.bind(this)}
              value="AuditorSignUp"
              color="primary"
            />
          }
          label="Register as Auditor"
        />
        {
          auditorSignUp && this.renderAuditorSignUp()
        }
        <Button variant="raised" color="primary" 
          onClick={this.handleRegister.bind(this)}>
            Register
        </Button>
      </div>
    )
  }

  render() {
    const { login } = this.state

    return (
      <div className={'welcomeContainer'}>
        <header className={'welcomeHeader'}>
          <div className={'headerTitle'}>{'Dam Surveillance & Monitoring Project'}</div>
          <div className={'loginContainer'}>
            <TextField
              id="loginEmailId"
              label="Email ID"
              value={login['emailId']}
              className={'loginTxtFld'}
              style={{margin: '0 10px'}}
              onChange={this.handleChange('emailId', 'login')}
            />
            <TextField
              id="loginPassword"
              label="Password"
              type="password"
              value={login['password']}
              className={'loginTxtFld'}
              style={{margin: '0 10px'}}
              onChange={this.handleChange('password', 'login')}
            />
            <Button variant="raised" color="primary" 
            onClick={this.handleLogin.bind(this)}>
              Login
            </Button>
          </div>
        </header>
        <main className={"welcomeMain"}>
          {this.renderRegisterContainer()}
        </main>
        <footer className="welcomeFooter">
        <Button color="secondary" className={''} onClick={this.navigateToAbout.bind(this)}>
          ABOUT US
        </Button>
        <Button color="secondary" className={''}  onClick={this.navigateToContact.bind(this)}>
          CONTACT US
        </Button>
          {/* <div className="copyrightContent">COPYRIGHT holds CheerUP Souls</div> */}
        </footer>
      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
    user: state.User
  }
}

const mapDispatchToProps = dispatch => {
  return {
    saveUser: user => {
      dispatch(saveUser(user))
    },
    authenticateUser: user => {
      dispatch(authenticateUser(user))
    },
    sendMail: mail => {
      dispatch(sendMail(mail))
    }
  }
}

const WelcomeWrapper = connect(
  mapStateToProps,
  mapDispatchToProps
)(Welcome)

export default withRouter(WelcomeWrapper)