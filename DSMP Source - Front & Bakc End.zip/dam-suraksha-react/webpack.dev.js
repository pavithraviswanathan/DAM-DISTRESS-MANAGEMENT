const merge = require('webpack-merge');
const common = require('./webpack.common.js');

 module.exports = merge(common, {
   devtool: 'inline-source-map',
   devServer: {
     contentBase: './dist',
     hot: true,
     historyApiFallback: true,
     port: process.env.PORT || 8010
   }
 });


 /**
  
 SRC: https://stackoverflow.com/a/39968984/4067157
 
 devServer: {
    contentBase: 'app/ui/www',
    devtool: 'eval',
    hot: true,
    inline: true,
    port: 3000,
    outputPath: buildPath,
    historyApiFallback: true,
},

  */