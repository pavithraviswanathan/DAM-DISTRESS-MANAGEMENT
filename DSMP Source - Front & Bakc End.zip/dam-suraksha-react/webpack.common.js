const path = require('path');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');
// const CleanWebpackPlugin = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const webpack = require('webpack');

const PATHS = {
	react : path.join(__dirname, 'node_modules/react/dist/react.min.js'),
	app   : path.join(__dirname, 'src'),
	build : path.join(__dirname, './dist')
};

module.exports = {
	entry   : './src/index.js',
	plugins : [
		// new CleanWebpackPlugin(['dist']),
		new HtmlWebpackPlugin({
			title    : 'RMT',
			filename : 'index.html',
			template : 'src/index.html'
		}),
		new webpack.NamedModulesPlugin(),
		new webpack.HotModuleReplacementPlugin(),
		new webpack.optimize.CommonsChunkPlugin({
			name: 'common' // Specify the common bundle's name.
		})
	],
	module: {
		rules: [
			{
				test : /\.css$/,
				use  : [
					'style-loader',
					'css-loader'
				]
			},
			{ 
				test    : /\.(js|jsx)$/, 
				exclude : /node_modules/, 
				loader  : "babel-loader",  include: path.resolve(__dirname, "src") 
			},
			{
				test : /\.(png|jp(e*)g|svg|ttf|eot|woff|woff2)$/,  
				use  : [{
					loader  : 'url-loader',
					options : { 
						limit : 8000, // Convert images < 8kb to base64 strings
						name  : 'images/[hash]-[name].[ext]'
					} 
				}]
			}
		]
	},
	resolve: {
		extensions : ['.js', '.jsx'],
		alias      : {
			'Layout'    : path.resolve(__dirname, 'src/layout'),
			'Component' : path.resolve(__dirname, 'src/component'),
			'Util'      : path.resolve(__dirname, 'src/util'),
			'Asset'     : path.resolve(__dirname, 'src/asset'),
			'Action'    : path.resolve(__dirname, 'src/action'),
			'Reducer'   : path.resolve(__dirname, 'src/reducer'),
			'Config'    : path.resolve(__dirname, 'src/config'),
		}
	},
	output: {
			filename   : '[name].bundle.js',
			path       : path.resolve(__dirname, 'dist'),
			publicPath : '/'
	}
};